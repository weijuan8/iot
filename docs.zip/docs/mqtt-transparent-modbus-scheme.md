# MQTT 透传 Modbus 开发文档

> **目标**：新建 `iot-component-mqtt-transparent-modbus` 模块，支持通过 MQTT 透传模式主动轮询 Modbus 子设备。
>
> **适用网关**：GE100D（或其他支持 MQTT 透传 + 注册包功能的网关）
>
> **核心原则**：
> - 不修改现有 `ModbusComponent` 等任何已有代码
> - 完全独立的新模块，复用现有物模型、设备 API 等基础设施
> - 参考现有 `DataEncoder/Decoder`、`VertxModbusClient` 的设计模式

---

## 一、需求概述

### 1.1 业务场景

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  GE100D 网关通过 RS485 挂载多个 Modbus 子设备（温湿度传感器、继电器等）        │
│  网关配置为 MQTT 透传模式，平台主动发 Modbus 请求 → 网关透传给子设备          │
│                                                                              │
│  网关（GE100D）                    平台（Enjoy-IoT）                          │
│  ┌──────────────────┐             ┌──────────────────────────────┐          │
│  │ MQTT 透传模式     │  ◄──────►  │ MqttTransparentModbusComponent│          │
│  │ 注册包: {dn}_{pk} │             │ - MQTT Client 连接网关         │          │
│  │                  │             │ - 定时轮询子设备寄存器          │          │
│  │ RS485 ─┬────────  │             │ - 下发控制命令（写寄存器）      │          │
│  │        │ slaveId=1│             │ - 设备注册 + 子设备管理        │          │
│  │        │ slaveId=2│             └──────────────────────────────┘          │
│  │        │ slaveId=3│                                                        │
│  └──────────────────┘                                                        │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.2 功能清单

| 功能 | 说明 | 优先级 |
|------|------|--------|
| MQTT 连接管理 | 平台通过 MQTT Client 连接网关，支持重连 | P0 |
| 设备注册 | 收到注册包后自动识别/验证网关设备 | P0 |
| 子设备管理 | 管理网关下多个 Modbus 从机（slaveId 映射） | P0 |
| 定时轮询 | 按物模型属性定义，定时读取子设备寄存器 | P0 |
| 属性上报 | 解析 Modbus 响应 → 业务值 → 上报规则引擎 | P0 |
| 属性设置 | 接收 propertySet 命令 → 写寄存器 → 返回结果 | P1 |
| 离线检测 | MQTT 断开/心跳超时检测 + 重连 | P1 |
| 服务调用 | 自定义 Modbus 指令下发 | P2 |

### 1.3 与现有 ModbusComponent 的差异

| 维度 | 现有 ModbusComponent | 新组件（本模块） |
|------|---------------------|-----------------|
| 通信协议 | TCP 直连 | MQTT（Vert.x MQTT Client） |
| 网关连接 | 网关主动 TCP 连接平台 | 平台主动 MQTT 连接网关 |
| 注册方式 | `r_{pk}_{dn}_{slaveId}` 自定义协议 | MQTT payload 前缀 `{dn}_{pk}` |
| 心跳 | 5 字节 ASCII 自定义心跳 | MQTT PINGREQ/PINGRESP 协议自带 |
| 子设备 | 1:1（一个连接一个设备） | 1:N（一个网关多个 slaveId） |
| 下行控制 | 空实现 | 完整实现 propertySet/propertyGet |

---

## 二、模块结构

### 2.1 目录结构

```
module-eiot/iot-components/iot-component-mqtt-transparent-modbus/
├── pom.xml
└── src/
    ├── main/java/com/enjoyiot/eiot/component/mqttTransparentModbus/
    │   ├── MqttTransparentStarter.java              // @PostConstruct 启动器
    │   ├── MqttTransparentModbusComponent.java      // 核心组件（继承 ThingComponent）
    │   ├── MqttTransparentVerticle.java             // Vert.x MQTT Client 生命周期管理
    │   ├── config/
    │   │   └── MqttTransparentConfig.java           // 配置模型（JSON → Java）
    │   ├── session/
    │   │   └── GatewaySession.java                  // 网关会话对象
    │   ├── command/
    │   │   ├── ModbusCommand.java                   // Modbus 功能码枚举
    │   │   └── ModbusCommandEncoder.java            // Modbus TCP 帧编码 + MQTT payload 拼接
    │   └── parser/
    │       └── MqttMessageParser.java               // MQTT payload 解析（注册包 + Modbus 帧分离）
    └── test/
        └── java/com/enjoyiot/eiot/component/mqttTransparentModbus/
            ├── ModbusCommandTest.java               // 命令编解码单测
            └── MqttMessageParserTest.java           // 消息解析单测
```

### 2.2 依赖关系

```xml
<!-- pom.xml 关键依赖 -->
<dependencies>
    <!-- 项目内部 -->
    <dependency>iot-component-core</dependency>        <!-- Component/ThingComponent/AbstractComponent -->
    <dependency>module-eiot-api</dependency>           <!-- ModbusThingModel, DeviceApi -->
    
    <!-- Vert.x MQTT -->
    <dependency>
        <groupId>io.vertx</groupId>
        <artifactId>vertx-mqtt</artifactId>
    </dependency>
    
    <!-- 工具 -->
    <dependency>hutool-core</dependency>
    <dependency>lombok</dependency>
</dependencies>
```

---

## 三、Phase 1：基础框架搭建

### 3.1 任务清单

| 序号 | 任务 | 产出文件 | 验收标准 |
|------|------|---------|---------|
| 1 | 创建 Maven 模块 | `pom.xml` | 编译通过 |
| 2 | 配置模型 | `MqttTransparentConfig.java` | JSON 反序列化正确 |
| 3 | Modbus 命令枚举 | `ModbusCommand.java` | 全部 8 种功能码可编码 |
| 4 | 命令编解码器 | `ModbusCommandEncoder.java` | 编码结果与 Modbus 协议规范一致 |
| 5 | 消息解析器 | `MqttMessageParser.java` | 能正确分离注册包和 Modbus 帧 |
| 6 | 网关会话对象 | `GatewaySession.java` | 字段完整，事务 ID 生成正确 |
| 7 | 启动器 | `MqttTransparentStarter.java` | 应用启动时自动初始化 |

### 3.2 MqttTransparentConfig（配置模型）

```java
/**
 * JSON 配置示例（存储在组件配置中）：
 * {
 *   "brokerHost": "192.168.1.100",
 *   "brokerPort": 1883,
 *   "clientIdTemplate": "{dn}_{pk}",
 *   "username": "admin",
 *   "password": "password",
 *   "pubTopicTemplate": "/eiot/{pk}/{dn}/up",
 *   "subTopicTemplate": "/eiot/{pk}/{dn}/down",
 *   "qos": 1,
 *   "keepAlive": 60,
 *   "registerPrefixTemplate": "{dn}_{pk}",
 *   "registerSeparator": "\n",
 *   "pollInterval": 10,
 *   "commandInterval": 200,
 *   "cleanSession": true,
 *   "autoReconnect": true,
 *   "reconnectInterval": 5
 * }
 */
@Data
public class MqttTransparentConfig {
    // MQTT 连接
    private String brokerHost;
    private int brokerPort = 1883;
    private String clientIdTemplate;       // 模板，如 "{dn}_{pk}"
    private String username;
    private String password;
    
    // Topic
    private String pubTopicTemplate;       // 上行 Topic 模板
    private String subTopicTemplate;       // 下行 Topic 模板
    private int qos = 1;
    private int keepAlive = 60;
    
    // 注册包
    private String registerPrefixTemplate; // 如 "{dn}_{pk}"
    private String registerSeparator = "\n"; // 注册包与 Modbus 帧的分隔符
    
    // 轮询
    private int pollInterval = 10;         // 轮询间隔（秒）
    private int commandInterval = 200;     // 命令间隔（毫秒），RS485 半双工需要
    
    // 重连
    private boolean cleanSession = true;
    private boolean autoReconnect = true;
    private int reconnectInterval = 5;     // 重连间隔（秒）
    
    /**
     * 根据设备信息填充模板变量
     * 例：clientIdTemplate="{dn}_{pk}" + dn="A001", pk="prod" → "A001_prod"
     */
    public String renderClientId(String dn, String pk) {
        return clientIdTemplate.replace("{dn}", dn).replace("{pk}", pk);
    }
    public String renderPubTopic(String dn, String pk) { /* 同理 */ }
    public String renderSubTopic(String dn, String pk) { /* 同理 */ }
    public String renderRegisterPrefix(String dn, String pk) { /* 同理 */ }
}
```

### 3.3 ModbusCommand（命令枚举）

```java
/**
 * Modbus 标准功能码枚举。
 * 
 * 设计要点：
 *   - 每个枚举值自带 encodeRequest() 方法，直接输出 Modbus TCP 帧字节
 *   - 读写命令用 isWrite 区分，编码逻辑不同
 *   - dataUnitBytes: 线圈=1位，寄存器=2字节，影响数据长度计算
 * 
 * 使用示例：
 *   byte[] frame = READ_HOLDING_REGISTERS.encodeRequest(
 *       (short) 5, (byte) 1, (short) 0x0000, (short) 2, null
 *   );
 *   // → [00 05] [00 00] [00 06] [01] [03] [00 00] [00 02]
 */
public enum ModbusCommand {
    
    // ===== 读命令 =====
    READ_COILS(                (byte) 0x01, "读线圈",             false, 1),
    READ_DISCRETE_INPUTS(      (byte) 0x02, "读离散输入",          false, 1),
    READ_HOLDING_REGISTERS(    (byte) 0x03, "读保持寄存器",        false, 2),
    READ_INPUT_REGISTERS(      (byte) 0x04, "读输入寄存器",        false, 2),
    
    // ===== 写命令 =====
    WRITE_SINGLE_COIL(         (byte) 0x05, "写单线圈",           true,  1),
    WRITE_SINGLE_REGISTER(     (byte) 0x06, "写单寄存器",          true,  2),
    WRITE_MULTIPLE_COILS(      (byte) 0x0F, "写多线圈",           true,  1),
    WRITE_MULTIPLE_REGISTERS(  (byte) 0x10, "写多寄存器",          true,  2),
    ;
    
    private final byte functionCode;
    private final String description;
    private final boolean isWrite;
    private final int dataUnitBytes; // 1=线圈(位), 2=寄存器(字节)
    
    /**
     * 根据物模型 regType 字符串获取命令枚举
     * regType "03" → READ_HOLDING_REGISTERS
     */
    public static ModbusCommand fromRegType(String regType) {
        int code = Integer.parseInt(regType);
        for (ModbusCommand cmd : values()) {
            if ((cmd.functionCode & 0xFF) == code) return cmd;
        }
        return null;
    }
    
    /**
     * 编码 Modbus TCP 请求帧
     * @param transactionId  事务 ID（2 字节）
     * @param slaveId        从机地址（1 字节）
     * @param address        寄存器起始地址（2 字节）
     * @param quantity       寄存器数量（2 字节）
     * @param writeData      写数据（读命令传 null）
     * @return 完整 Modbus TCP 帧
     */
    public byte[] encodeRequest(short transactionId, byte slaveId,
                                 short address, short quantity, byte[] writeData) {
        // 计算 PDU 长度
        int pduLength = 1 + 2 + 2;  // funcCode(1) + addr(2) + qty(2)
        if (isWrite && writeData != null) {
            pduLength += 1 + writeData.length; // byteCount(1) + data(N)
        }
        
        ByteBuffer buf = ByteBuffer.allocate(7 + pduLength); // MBAP(7) + PDU
        
        // MBAP Header（7 字节）
        buf.putShort(transactionId);     // 0-1: Transaction ID
        buf.putShort((short) 0x0000);    // 2-3: Protocol ID
        buf.putShort((short) pduLength); // 4-5: Length
        buf.put(slaveId);                // 6: Unit ID
        
        // PDU
        buf.put(functionCode);           // 7: Function Code
        buf.putShort(address);           // 8-9: Starting Address
        buf.putShort(quantity);          // 10-11: Quantity
        
        if (isWrite && writeData != null) {
            buf.put((byte) writeData.length); // Byte Count
            buf.put(writeData);                // Data
        }
        
        return buf.array();
    }
}
```

### 3.4 ModbusCommandEncoder（MQTT payload 拼接）

```java
/**
 * 负责将 Modbus TCP 帧包装为 MQTT payload（注册包前缀 + Modbus 帧）
 */
public class ModbusCommandEncoder {
    
    /**
     * 构造下行 MQTT 消息 payload
     * 
     * @param registerPrefix  注册包前缀，如 "A001_prod_001"
     * @param separator       分隔符，如 "\n"
     * @param modbusFrame     Modbus TCP 帧字节数组
     * @return 完整 payload: "{prefix}{separator}{frame}"
     */
    public static byte[] buildMqttPayload(String registerPrefix, String separator, 
                                           byte[] modbusFrame) {
        byte[] prefixBytes = (registerPrefix + separator).getBytes(StandardCharsets.US_ASCII);
        byte[] result = new byte[prefixBytes.length + modbusFrame.length];
        System.arraycopy(prefixBytes, 0, result, 0, prefixBytes.length);
        System.arraycopy(modbusFrame, 0, result, prefixBytes.length, modbusFrame.length);
        return result;
    }
}
```

### 3.5 MqttMessageParser（上行消息解析）

```java
/**
 * 解析上行 MQTT 消息 payload，分离注册包前缀和 Modbus TCP 帧。
 * 
 * 输入：DAT_A001_prod\n[00 05][00 00][00 05][01][03][04][42 48 00 00]
 * 输出：ParseResult { dn:"A001", pk:"prod", txId:5, unitId:1, modbusFrame:... }
 */
public class MqttMessageParser {
    
    /**
     * @param payload      MQTT 消息完整 payload
     * @param separator    注册包分隔符，如 "\n"
     * @return ParseResult，success=false 时需打日志并跳过
     */
    public static ParseResult parse(byte[] payload, String separator) {
        byte[] sepBytes = separator.getBytes(StandardCharsets.US_ASCII);
        
        // 1. 查找分隔符
        int sepIdx = indexOf(payload, sepBytes);
        if (sepIdx < 0) return ParseResult.fail("未找到分隔符");
        
        // 2. 提取注册包：{dn}_{pk}
        String registerInfo = new String(payload, 0, sepIdx, StandardCharsets.US_ASCII);
        String[] parts = registerInfo.split("_");
        if (parts.length < 2) return ParseResult.fail("注册包格式错误: " + registerInfo);
        String dn = parts[0];
        String pk = parts[1];
        
        // 3. 提取 Modbus TCP 帧
        int frameStart = sepIdx + sepBytes.length;
        byte[] modbusFrame = Arrays.copyOfRange(payload, frameStart, payload.length);
        if (modbusFrame.length < 7) return ParseResult.fail("Modbus 帧太短");
        
        // 4. 解析 MBAP Header
        ByteBuffer buf = ByteBuffer.wrap(modbusFrame);
        short txId = buf.getShort();      // Transaction ID
        buf.getShort();                    // Protocol ID (忽略)
        buf.getShort();                    // Length (忽略)
        byte unitId = buf.get();           // slaveId
        
        return ParseResult.success(dn, pk, txId, unitId, modbusFrame);
    }
    
    @Data
    @Builder
    public static class ParseResult {
        private boolean success;
        private String errorMsg;
        private String dn;           // 网关设备名
        private String pk;           // 网关产品 Key
        private short transactionId; // Modbus 事务 ID
        private byte unitId;         // 子设备 slaveId
        private byte[] modbusFrame;  // 完整 Modbus TCP 帧（含 MBAP Header）
        
        public static ParseResult fail(String msg) {
            return ParseResult.builder().success(false).errorMsg(msg).build();
        }
        public static ParseResult success(String dn, String pk, short txId, 
                                           byte unitId, byte[] frame) {
            return ParseResult.builder().success(true)
                .dn(dn).pk(pk).transactionId(txId).unitId(unitId).modbusFrame(frame).build();
        }
    }
    
    private static int indexOf(byte[] source, byte[] target) { /* 字节数组查找 */ }
}
```

### 3.6 GatewaySession（网关会话）

```java
/**
 * 封装一个网关的 MQTT 连接状态。
 * 每个网关一个 GatewaySession 实例，存储在 Component 的 sessionMap 中。
 */
@Data
public class GatewaySession {
    private String dn;                          // 网关设备名
    private String productKey;                  // 网关产品 Key
    private String mqttClientId;                // MQTT Client ID
    private boolean registered;                 // 是否已收到注册包
    private long registerTime;                  // 注册时间戳
    private long lastActiveTime;                // 最后活跃时间（收到任何消息时更新）
    
    /** 子设备列表（slaveId → 子设备信息） */
    private Map<Byte, SubDeviceInfo> subDevices = new ConcurrentHashMap<>();
    
    /** 事务映射（transactionId → 物模型 Property），用于响应匹配 */
    private Map<Short, ModbusThingModel.Property> transactionMap = new ConcurrentHashMap<>();
    
    /** Transaction ID 生成器（1~65535 循环） */
    private AtomicInteger txIdGen = new AtomicInteger(0);
    
    public short nextTransactionId() {
        return (short) (txIdGen.updateAndGet(i -> (i % 65535) + 1));
    }
}

/**
 * 子设备信息
 */
@Data
public class SubDeviceInfo {
    private String dn;           // 子设备名
    private String productKey;   // 子设备产品 Key
    private byte slaveId;        // Modbus 从机地址
    private String gatewayDn;    // 所属网关设备名
}
```

### 3.7 MqttTransparentStarter（启动器）

```java
/**
 * 应用启动时自动初始化，参考现有 MqttStarter 的设计。
 */
@Component
@Slf4j
public class MqttTransparentStarter {
    
    @Resource
    private ComponentServices componentServices;
    
    @PostConstruct
    public void init() {
        // 注册 MqttTransparentVerticle 到 Vert.x
        // 扫描配置中的网关设备，启动 MQTT 连接
    }
}
```

---

## 四、Phase 2：核心业务逻辑

### 4.1 任务清单

| 序号 | 任务 | 产出 | 验收标准 |
|------|------|------|---------|
| 1 | MQTT 连接管理 | `MqttTransparentVerticle.java` | 连接成功、断线重连正常 |
| 2 | 设备注册/验证 | Component 的 `onRegisterMessage()` | 新设备自动注册，已有设备验证通过 |
| 3 | 子设备加载 | Component 的 `loadSubDevices()` | 从映射表加载子设备列表 |
| 4 | 物模型缓存 | Component 的 `thingModelCache` | 按 productKey 缓存物模型 |
| 5 | 定时轮询 | Component 的 `readTask()` | 按配置间隔轮询所有子设备属性 |
| 6 | 响应处理 | Component 的 `onModbusResponse()` | 正确解析响应并上报属性 |

### 4.2 MqttTransparentVerticle（MQTT 连接管理）

```java
/**
 * 管理单个网关的 MQTT 连接生命周期。
 * 参考现有 MqttVerticle 的设计，但针对透传 Modbus 场景定制。
 * 
 * 职责：
 *   1. 建立/断开 MQTT 连接
 *   2. 订阅下行 Topic，监听上行 Topic
 *   3. 将收到的消息回调给 Component.handle()
 *   4. 断线重连（指数退避）
 */
public class MqttTransparentVerticle extends AbstractVerticle {
    
    private MqttClient mqttClient;
    private MqttTransparentConfig config;
    private String dn;
    private String pk;
    private MqttTransparentModbusComponent component;
    
    @Override
    public void start() {
        String clientId = config.renderClientId(dn, pk);
        MqttClientOptions options = new MqttClientOptions()
            .setClientId(clientId)
            .setUsername(config.getUsername())
            .setPassword(config.getPassword())
            .setKeepAliveInterval(config.getKeepAlive())
            .setCleanSession(config.isCleanSession())
            .setAutoKeepAlive(true);
        
        mqttClient = MqttClient.create(vertx, options);
        
        mqttClient.connect(config.getBrokerPort(), config.getBrokerHost(), ar -> {
            if (ar.succeeded()) {
                log.info("MQTT 连接成功: {}:{}", config.getBrokerHost(), config.getBrokerPort());
                subscribeDownTopic();
            } else {
                log.error("MQTT 连接失败", ar.cause());
                scheduleReconnect();
            }
        });
        
        // 监听上行消息
        mqttClient.publishHandler(message -> {
            component.handle(message.payload().getBytes());
        });
        
        // 断线回调
        mqttClient.closeHandler(v -> {
            log.warn("MQTT 连接断开: {}", dn);
            scheduleReconnect();
        });
    }
    
    private void subscribeDownTopic() {
        String subTopic = config.renderSubTopic(dn, pk);
        mqttClient.subscribe(subTopic, config.getQos());
    }
    
    public void publish(byte[] payload) {
        String pubTopic = config.renderPubTopic(dn, pk);
        mqttClient.publish(pubTopic, 
            Buffer.buffer(payload), 
            MqttQoS.valueOf(config.getQos()), 
            false, false);
    }
    
    private void scheduleReconnect() {
        if (!config.isAutoReconnect()) return;
        vertx.setTimer(config.getReconnectInterval() * 1000L, id -> start());
    }
}
```

### 4.3 MqttTransparentModbusComponent（核心组件）

```java
/**
 * 核心组件，继承 ThingComponent，实现 Handler<byte[]> 处理 MQTT 消息。
 * 
 * 继承链：Component → AbstractComponent → ThingComponent → 本类
 * 
 * 核心数据结构：
 *   sessionMap:        Map<dn, GatewaySession>        网关会话
 *   thingModelCache:   Map<productKey, ModbusThingModel> 物模型缓存
 *   subDeviceMapping:  Map<gatewayDn, Map<slaveId, SubDeviceInfo>> 子设备映射
 */
@Component
public class MqttTransparentModbusComponent extends ThingComponent 
        implements Handler<byte[]> {
    
    // ===== 核心数据结构 =====
    private final Map<String, GatewaySession> sessionMap = new ConcurrentHashMap<>();
    private final Map<String, ModbusThingModel> thingModelCache = new ConcurrentHashMap<>();
    private final Map<String, Map<Byte, SubDeviceInfo>> subDeviceMapping = new ConcurrentHashMap<>();
    
    @Resource private DeviceApi deviceApi;
    @Resource private ModbusThingModelApi thingModelApi;
    @Resource private ModbusSubDeviceMappingMapper mappingMapper; // 新建的 Mapper
    
    private ScheduledFuture<?> readTaskFuture;
    private MqttTransparentConfig config;
    
    // ===== 生命周期 =====
    
    @Override
    public String getType() {
        return "mqtt-transparent-modbus";
    }
    
    /**
     * 配置变更时调用
     */
    public void stateChange(boolean enable, String configJson) {
        this.config = JSONUtil.toBean(configJson, MqttTransparentConfig.class);
        if (enable) {
            startAllGateways();
            startReadTask();
        } else {
            stopReadTask();
            closeAllGateways();
        }
    }
    
    // ===== MQTT 消息入口 =====
    
    @Override
    public void handle(byte[] payload) {
        // 1. 解析消息
        MqttMessageParser.ParseResult result = 
            MqttMessageParser.parse(payload, config.getRegisterSeparator());
        if (!result.isSuccess()) {
            log.warn("消息解析失败: {}", result.getErrorMsg());
            return;
        }
        
        String dn = result.getDn();
        String pk = result.getPk();
        
        // 2. 获取或创建网关会话
        GatewaySession session = sessionMap.computeIfAbsent(dn, 
            k -> new GatewaySession());
        session.setLastActiveTime(System.currentTimeMillis());
        
        // 3. 判断消息类型（是否首次注册）
        if (!session.isRegistered()) {
            onRegisterMessage(dn, pk, session);
        }
        
        // 4. 处理 Modbus 响应
        onModbusResponse(session, result);
    }
    
    // ===== 设备注册 =====
    
    private void onRegisterMessage(String dn, String pk, GatewaySession session) {
        // 查设备表：设备是否存在？
        Device device = deviceApi.findByDn(dn);
        if (device == null) {
            // 自动注册
            deviceApi.registerDevice(pk, dn);
            log.info("自动注册新设备: dn={}, pk={}", dn, pk);
            // TODO: 发送告警通知管理员配置子设备和物模型
        } else {
            // 验证 pk 是否匹配
            if (!Objects.equals(device.getProductKey(), pk)) {
                log.error("设备 pk 不匹配: dn={}, expect={}, actual={}", 
                    dn, device.getProductKey(), pk);
                return;
            }
        }
        
        session.setDn(dn);
        session.setProductKey(pk);
        session.setRegistered(true);
        session.setRegisterTime(System.currentTimeMillis());
        
        // 加载子设备列表
        loadSubDevices(dn);
    }
    
    // ===== 子设备加载 =====
    
    private void loadSubDevices(String gatewayDn) {
        // 从 eiot_modbus_sub_device_mapping 表查询
        List<ModbusSubDeviceMapping> mappings = mappingMapper.findByGatewayDn(gatewayDn);
        
        Map<Byte, SubDeviceInfo> subMap = new HashMap<>();
        for (ModbusSubDeviceMapping m : mappings) {
            SubDeviceInfo info = new SubDeviceInfo();
            info.setDn(m.getSubDn());
            info.setProductKey(m.getSubPk());
            info.setSlaveId((byte) m.getSlaveId().intValue());
            info.setGatewayDn(gatewayDn);
            subMap.put(info.getSlaveId(), info);
            
            // 预热物模型缓存
            if (!thingModelCache.containsKey(m.getSubPk())) {
                ModbusThingModel model = thingModelApi.findByProductKey(m.getSubPk());
                if (model != null) {
                    thingModelCache.put(m.getSubPk(), model);
                }
            }
        }
        
        subDeviceMapping.put(gatewayDn, subMap);
        sessionMap.get(gatewayDn).setSubDevices(subMap);
        log.info("加载子设备: gateway={}, count={}", gatewayDn, subMap.size());
    }
    
    // ===== Modbus 响应处理 =====
    
    private void onModbusResponse(GatewaySession session, 
                                   MqttMessageParser.ParseResult result) {
        short txId = result.getTransactionId();
        ModbusThingModel.Property property = session.getTransactionMap().remove(txId);
        
        if (property == null) {
            log.warn("未找到事务映射: txId={}", txId);
            return;
        }
        
        // 提取响应数据（跳过 MBAP 7 字节 + 功能码 1 字节 + 字节计数 1 字节）
        byte[] modbusFrame = result.getModbusFrame();
        byte funcCode = modbusFrame[7];
        
        // 检查异常响应（功能码最高位 = 1）
        if ((funcCode & 0x80) != 0) {
            byte exceptionCode = modbusFrame[8];
            log.error("Modbus 异常响应: funcCode={}, exceptionCode={}", funcCode, exceptionCode);
            return;
        }
        
        // 读响应：byte[8]=字节计数, byte[9..]=数据
        byte byteCount = modbusFrame[8];
        byte[] data = Arrays.copyOfRange(modbusFrame, 9, 9 + byteCount);
        
        // 解析业务值
        Object value = property.parse(data);
        
        // 构造属性上报
        PropertyReport report = PropertyReport.builder()
            .productKey(session.getProductKey())
            .deviceName(session.getDn())
            .propertyId(property.getIdentifier())
            .value(value)
            .timestamp(System.currentTimeMillis())
            .build();
        
        report(report);
    }
    
    // ===== 定时轮询 =====
    
    private void startReadTask() {
        int interval = config.getPollInterval() * 1000; // 秒 → 毫秒
        readTaskFuture = Executors.newSingleThreadScheduledExecutor()
            .scheduleWithFixedDelay(this::readTask, interval, interval, 
                TimeUnit.MILLISECONDS);
    }
    
    private void readTask() {
        for (GatewaySession session : sessionMap.values()) {
            if (!session.isRegistered()) continue;
            
            Map<Byte, SubDeviceInfo> subDevices = subDeviceMapping.get(session.getDn());
            if (subDevices == null) continue;
            
            for (SubDeviceInfo sub : subDevices.values()) {
                ModbusThingModel model = thingModelCache.get(sub.getProductKey());
                if (model == null || model.getModel() == null) continue;
                
                for (ModbusThingModel.Property prop : model.getModel().getProperties()) {
                    // 只读属性才参与轮询
                    if (!"r".equals(prop.getAccessMode()) && !"rw".equals(prop.getAccessMode())) 
                        continue;
                    
                    try {
                        ModbusCommand cmd = ModbusCommand.fromRegType(prop.getRegType());
                        if (cmd == null || cmd.isWrite()) continue;
                        
                        short txId = session.nextTransactionId();
                        byte[] frame = cmd.encodeRequest(txId, sub.getSlaveId(),
                            prop.getRegAddr().shortValue(), prop.getRegNum().shortValue(), null);
                        
                        session.getTransactionMap().put(txId, prop);
                        
                        byte[] payload = ModbusCommandEncoder.buildMqttPayload(
                            config.renderRegisterPrefix(session.getDn(), session.getProductKey()),
                            config.getRegisterSeparator(), frame);
                        
                        // 通过 Verticle 发送
                        publishToGateway(session.getDn(), payload);
                        
                        // RS485 半双工，命令间需要间隔
                        Thread.sleep(config.getCommandInterval());
                    } catch (Exception e) {
                        log.error("轮询异常: sub={}, prop={}", sub.getDn(), prop.getIdentifier(), e);
                    }
                }
            }
        }
    }
    
    // ===== 属性设置（Phase 3 实现）=====
    
    @Override
    public ServiceReply propertySet(Action action) {
        // Phase 3 实现，见第五章
        return ServiceReply.notSupported();
    }
    
    @Override
    public ServiceReply propertyGet(Action action) {
        // Phase 3 实现
        return ServiceReply.notSupported();
    }
    
    // ===== 工具方法 =====
    
    private void publishToGateway(String gatewayDn, byte[] payload) {
        // 通过 Vert.x EventBus 或直接调用 Verticle 的 publish 方法
    }
    
    private void stopReadTask() {
        if (readTaskFuture != null) readTaskFuture.cancel(false);
    }
    
    private void startAllGateways() { /* 遍历配置的网关列表，启动 MqttTransparentVerticle */ }
    private void closeAllGateways() { /* 关闭所有 MQTT 连接 */ }
}
```

---

## 五、Phase 3：控制功能

### 5.1 任务清单

| 序号 | 任务 | 说明 |
|------|------|------|
| 1 | propertySet | 属性设置 → 写寄存器 → 等待 ACK → 返回结果 |
| 2 | propertyGet | 即时读取单个属性 |
| 3 | 离线检测 | MQTT 断开/超时检测 + 上报 OFFLINE + 重连 |
| 4 | serviceInvoke | 自定义 Modbus 指令下发 |

### 5.2 propertySet 实现

```
propertySet(action) 执行流程：

  入参：Action { productKey, deviceName, params: { "relay_status": true } }
  
  ① 查子设备信息
     SubDeviceInfo sub = findSubDevice(dn)
     if (sub == null) → 返回错误 "子设备不存在"
  
  ② 查网关会话
     GatewaySession session = sessionMap.get(sub.getGatewayDn())
     if (session == null) → 返回错误 "网关不在线"
  
  ③ 查物模型属性
     ModbusThingModel model = thingModelCache.get(sub.getProductKey())
     Property prop = model.findProperty("relay_status")
     if (prop == null) → 返回错误 "属性未定义"
  
  ④ 选择写命令
     if (prop.getRegType() == "01" || prop.getRegType() == "05")
         cmd = WRITE_SINGLE_COIL
     else if (prop.getRegType() == "03" || prop.getRegType() == "06")
         cmd = WRITE_SINGLE_REGISTER
  
  ⑤ 编码写值
     byte[] writeData = encodeValue(prop, params.get("relay_status"))
     // bool true → 线圈 ON: [0xFF, 0x00]
     // int 100  → 寄存器值: [0x00, 0x64]
  
  ⑥ 编码 Modbus 帧
     txId = session.nextTransactionId()
     frame = cmd.encodeRequest(txId, sub.getSlaveId(), 
                                prop.getRegAddr().shortValue(), (short) 1, writeData)
  
  ⑦ 建立事务映射
     session.getTransactionMap().put(txId, prop)
  
  ⑧ 发送 MQTT 消息
     payload = buildMqttPayload(prefix, separator, frame)
     publishToGateway(sub.getGatewayDn(), payload)
  
  ⑨ 等待响应（超时 3 秒）
     收到响应 → 确认成功 → reply(ServiceReply.success())
     超时    → reply(ServiceReply.error("写入超时"))
```

### 5.3 离线检测

```
offlineCheckTask() 逻辑：

  定时（每 30 秒）检查所有网关会话：
    for each session in sessionMap:
      now = System.currentTimeMillis()
      
      // 条件 1：MQTT 连接是否断开？
      if (!vertxClient.isConnected(session.getDn())):
          → 上报 DeviceStateChange { OFFLINE }
          → 触发重连
      
      // 条件 2：超时（keepAlive * 1.5 无消息）？
      if (now - session.getLastActiveTime() > keepAlive * 1500):
          → 上报 DeviceStateChange { OFFLINE }
```

---

## 六、数据库设计

### 6.1 新增表：子设备映射表

```sql
-- 子设备 Modbus 地址映射表
-- 记录网关下每个子设备的 slaveId 绑定关系

CREATE TABLE eiot_modbus_sub_device_mapping (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    gateway_dn  VARCHAR(64)  NOT NULL COMMENT '网关设备 DN',
    slave_id    INT          NOT NULL COMMENT 'Modbus 从机地址（1~247）',
    sub_pk      VARCHAR(64)  NOT NULL COMMENT '子设备产品 Key',
    sub_dn      VARCHAR(64)  NOT NULL COMMENT '子设备名称（DeviceName）',
    enabled     TINYINT(1)   NOT NULL DEFAULT 1 COMMENT '是否启用',
    tenant_id   BIGINT       NOT NULL COMMENT '租户 ID',
    create_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    UNIQUE KEY uk_gateway_slave (gateway_dn, slave_id),
    UNIQUE KEY uk_gateway_sub   (gateway_dn, sub_dn),
    INDEX idx_tenant (tenant_id)
) COMMENT 'Modbus 子设备地址映射表';
```

### 6.2 复用已有表

| 表名 | 用途 | 备注 |
|------|------|------|
| `eiot_modbus_thing_model` | 物模型定义（属性模板） | 不修改，完全复用 |
| `eiot_device` | 设备信息 | 不修改，存网关和子设备 |
| `eiot_product` | 产品信息 | 不修改 |

---

## 七、物模型设计（透传模式）

### 7.1 核心设计

```
透传模式物模型 = 功能模板 + 设备地址

  ┌─────────────────────┐     ┌─────────────────────────┐
  │ 物模型（功能模板）     │     │ 映射表（设备地址）        │
  │                     │     │                         │
  │ Property:           │     │ gateway_dn: "gw01"      │
  │   regType: "03"     │     │ slave_id: 1             │
  │   regAddr: 40001    │     │ sub_pk: "pk_temp"       │
  │   regNum: 2         │     └───────────┬─────────────┘
  │   dataType: float   │                 │
  │   sort: "CD AB"     │                 │ slaveId
  └──────────┬──────────┘                 │
             │                            │
             └──────── 拼接 ──────────────┘
                          │
                          ▼
  encodeRequest(txId, slaveId=1, regAddr=40001, regNum=2)
  → [00 01][00 00][00 06][01][03][9C 41][00 02]
```

### 7.2 regType ↔ 功能码映射

物模型 Property 的 `regType` 字段直接对应 Modbus 功能码，无需额外转换：

| regType | 功能码 | 含义 | 操作 |
|---------|--------|------|------|
| "01" | 0x01 | 读线圈 | 读 |
| "02" | 0x02 | 读离散输入 | 读 |
| "03" | 0x03 | 读保持寄存器 | 读写 |
| "04" | 0x04 | 读输入寄存器 | 读 |
| "05" | 0x05 | 写单线圈 | 写 |
| "06" | 0x06 | 写单寄存器 | 写 |
| "10" | 0x10 | 写多寄存器 | 写 |

### 7.3 完整物模型 JSON 示例

```json
{
  "properties": [
    {
      "identifier": "temperature",
      "name": "温度",
      "regType": "03",
      "regAddr": 40001,
      "regNum": 2,
      "sort": "CD AB",
      "dataType": { "type": "float", "specs": { "precision": 1 } },
      "processor": "x*0.1",
      "unit": "℃",
      "accessMode": "r"
    },
    {
      "identifier": "humidity",
      "name": "湿度",
      "regType": "03",
      "regAddr": 40003,
      "regNum": 1,
      "sort": "AB",
      "dataType": { "type": "int" },
      "unit": "%RH",
      "accessMode": "r"
    },
    {
      "identifier": "relay_status",
      "name": "继电器",
      "regType": "05",
      "regAddr": 0,
      "regNum": 1,
      "dataType": { "type": "bool", "specs": { "0": "关", "1": "开" } },
      "accessMode": "rw"
    }
  ]
}
```

### 7.4 与现有 ModbusComponent 物模型的关系

完全复用 `ModbusThingModel.Property`，不需要新建物模型表或类。现有 Property 的所有字段都适用：

| Property 字段 | 透传模式用途 |
|--------------|-------------|
| `identifier` | 属性上报标识 |
| `regType` | 功能码（构造请求的核心） |
| `regAddr` | 寄存器起始地址 |
| `regNum` | 寄存器数量 |
| `sort` | 字节序（响应解析用） |
| `dataType` | 数据类型（响应解析用） |
| `processor` | 处理公式 |
| `unit` | 单位 |
| `accessMode` | 访问模式（r=只读轮询，rw=可读写） |

---

## 八、协议通信规范

### 8.1 MQTT Topic 设计

```
上行 Topic（网关 → 平台）:  /eiot/{gatewayPk}/{gatewayDn}/up
下行 Topic（平台 → 网关）:  /eiot/{gatewayPk}/{gatewayDn}/down

说明：
  - 每个网关独立 Topic，天然隔离
  - GE100D 只支持 1 订阅 + 1 发布，通过注册包区分消息类型
```

### 8.2 消息格式

```
上行消息（网关 → 平台）：
┌──────────────────────┬─────────────────────────┐
│ 注册包前缀（ASCII）    │ Modbus TCP 帧（二进制）   │
│ "A001_prod_001\n"    │ MBAP(7B) + PDU(N bytes) │
└──────────────────────┴─────────────────────────┘

下行消息（平台 → 网关）：
┌──────────────────────┬─────────────────────────┐
│ 注册包前缀（ASCII）    │ Modbus TCP 帧（二进制）   │
│ "A001_prod_001\n"    │ MBAP(7B) + PDU(N bytes) │
└──────────────────────┴─────────────────────────┘

解析步骤：
  1. 按分隔符 \n 分割注册包前缀和 Modbus 帧
  2. 注册包格式：{dn}_{pk}
  3. Modbus 帧：标准 MBAP Header(7B) + PDU
```

### 8.3 Modbus TCP 帧格式

```
请求帧（12 字节）：
  [TransactionID(2B)] [ProtocolID(2B)=0x0000] [Length(2B)] [UnitID(1B)=slaveId]
  [FuncCode(1B)] [StartAddr(2B)] [Quantity(2B)]

响应帧（可变长度）：
  [TransactionID(2B)] [ProtocolID(2B)=0x0000] [Length(2B)] [UnitID(1B)=slaveId]
  [FuncCode(1B)] [ByteCount(1B)] [Data(N bytes)]
```

### 8.4 通信流程

```
网关首次上线：
  网关 → PUBLISH /eiot/{pk}/{dn}/up, payload="A001_prod_001\n"
  平台 → 解析注册包 → 验证/注册设备 → 加载子设备列表 → 启动轮询

定时轮询：
  平台 → PUBLISH /eiot/{pk}/{dn}/down, payload="A001_prod_001\n<读寄存器帧>"
  网关 → 透传给 RS485 子设备 → 收到响应
  网关 → PUBLISH /eiot/{pk}/{dn}/up, payload="A001_prod_001\n<响应帧>"
  平台 → 匹配 txId → 解析数据 → 上报属性

属性设置：
  平台 → PUBLISH /eiot/{pk}/{dn}/down, payload="A001_prod_001\n<写寄存器帧>"
  网关 → 透传给 RS485 子设备 → 返回 ACK
  平台 → 确认成功 → 返回调用方
```

---

## 九、配置与部署

### 9.1 网关配置（GE100D 后台）

```
MQTT 配置：
  Broker 地址：  平台 IP:1883
  Client ID：    {dn}_{pk}（如 A001_gateway_prod）
  用户名/密码：   按平台分配
  
  发布 Topic：   /eiot/{productKey}/{deviceName}/up
  订阅 Topic：   /eiot/{productKey}/{deviceName}/down
  QoS：         1
  
  注册包功能：   启用
  注册包内容：   {dn}_{pk}（如 A001_gateway_prod）
  
  工作模式：     透传模式（Transparent Transmission）
```

### 9.2 平台侧配置步骤

```
1. 创建网关产品（如 gateway_prod）
2. 创建网关设备（dn=A001, pk=gateway_prod）
3. 创建子设备产品（如 temp_sensor_pk, relay_pk）
4. 创建子设备（dn=A001_temp, dn=A001_relay）
5. 为子设备配置物模型（properties JSON）
6. 配置子设备映射（eiot_modbus_sub_device_mapping 表）：
     gateway_dn=A001, slave_id=1, sub_pk=temp_sensor_pk, sub_dn=A001_temp
     gateway_dn=A001, slave_id=2, sub_pk=relay_pk, sub_dn=A001_relay
7. 配置组件参数（MqttTransparentConfig JSON）
```

---

## 十、开发注意事项

### 10.1 关键约束

1. **不修改现有代码**：新组件完全独立，不碰 `ModbusComponent`、`DataEncoder` 等
2. **RS485 半双工**：同一子设备的命令必须串行，命令间隔 ≥ 200ms
3. **并发安全**：`transactionMap` 用 `ConcurrentHashMap`，txId 用 `AtomicInteger`
4. **事务超时**：发送命令后 3 秒未收到响应视为超时，清理 `transactionMap`
5. **异常响应**：功能码最高位 = 1 表示异常，byte[8] 为异常码，需记录日志

### 10.2 参考代码

| 参考 | 文件路径 | 参考内容 |
|------|---------|---------|
| DataEncoder/Decoder | `iot-component-core/.../modbus/` | Modbus 帧编解码逻辑 |
| VertxModbusClient | `iot-component-core/.../modbus/` | Transaction ID + transactionMap 模式 |
| MqttComponent | `iot-components/iot-component-mqtt/` | MQTT 连接管理 |
| MqttVerticle | `iot-components/iot-component-mqtt/` | Vert.x MQTT 配置 |
| ThingComponent | `iot-component-core/.../core/` | 轮询任务 + 物模型消息分发 |
| ModbusThingModel | `module-eiot-api/.../modbus/dto/` | Property.parse() 数据解析 |

### 10.3 常见问题

| 问题 | 原因 | 处理方式 |
|------|------|---------|
| 未找到分隔符 | GE100D 注册包配置不对 | 检查分隔符是否与配置一致 |
| txId 匹配失败 | 响应超时或 txId 溢出 | 增加超时时间，检查 txId 生成逻辑 |
| 异常码 0x02 | 寄存器地址不存在 | 检查物模型 regAddr 是否正确 |
| 异常码 0x03 | 寄存器值超出范围 | 检查 writeData 编码是否正确 |
| 设备反复上下线 | MQTT 心跳间隔配置不对 | keepAlive 建议 60s，检测间隔 90s |

---

## 十一、实施计划

| 阶段 | 内容 | 预计工时 |
|------|------|---------|
| Phase 1 | 基础框架（模块、配置、枚举、编解码器、解析器、会话、启动器） | 2 天 |
| Phase 2 | 核心业务（MQTT 连接、设备注册、子设备加载、定时轮询、响应处理） | 3 天 |
| Phase 3 | 控制功能（propertySet、propertyGet、离线检测、serviceInvoke） | 2 天 |
| Phase 4 | 测试与优化（单元测试、集成联调、性能优化） | 2 天 |
| **合计** | | **9 天** |

---

> **本文档为开发规格说明，所有代码示例可直接作为开发参考。**
>
> 生成时间：2026-07-15
