# 规则引擎模块完整测试报告

> 测试日期: 2026-08-05
> 测试范围: 前端(enjoy-web) + 后端(module-eiot/iot-rule-engine)
> 测试方式: 代码静态审查 + 数据流分析

---

## 已修复问题（本轮修复记录）

| # | 问题 | 严重度 | 状态 |
|---|------|--------|------|
| 1 | output.vue 双向 watcher 形成递归更新死循环 | 🔴 严重 | ✅ 已修复 (isUpdatingFromParent flag) |
| 2 | structuredClone 无法克隆 Vue Proxy 对象 | 🔴 严重 | ✅ 已修复 (改用 JSON.parse/stringify) |
| 3 | AlertAction services 为空时 IndexOutOfBoundsException | 🔴 严重 | ✅ 已修复 (后端加空判 + 前端初始化) |
| 4 | 编辑时监听器物模型参数不下拉回显 | 🟡 中等 | ✅ 已修复 (nextTick 中加载 pk) |
| 5 | lsnCond 执行条件不持久化 | 🟡 中等 | ✅ 已修复 (TriggerOptions 加字段 + 前后端同步) |

---

## 一、仍存在的 Bug（按优先级排列）

### 🔴 严重：Bug #1 — filtera.vue 每个过滤器的「条件组合」(cond) 未持久化

**现象**: 用户为过滤器设置了"任意满足(OR)"或"全部不满足(NOT)"，保存后重新打开变为"全部满足(AND)"。

**根因**: `index.vue` 的 `onSave` 方法中，filter 配置的 `mObj` 对象缺少 `cond` 字段。
```typescript
// index.vue:364-372 - 缺 cond 字段
const mObj = {
  type: 'device',
  pk: m.pk,
  dn: m.dn,
  conditions: (m.conditions || []).map(...),
  deviceRadio: m.deviceRadio,
  // ❌ 缺少 cond: m.cond
}
```

**影响**: 过滤器级别的条件组合逻辑与 `lsnCond`(全局执行条件)不同，这个字段表示每个过滤器内部多个 condition 之间的 AND/OR/NOT 关系。保存后丢失，导致过滤器行为与用户设置不一致。

**修复文件**: `index.vue` 第 364-378 行

---

### 🔴 严重：Bug #2 — filtera.vue 的 initThingModel 调用 handleEmits 导致潜在重复 emit

**现象**: 选择设备后，物模型 API 返回时 `initThingModel` 内部调用 `handleEmits()`，可能与用户操作触发的 emit 产生竞态条件。

**根因**: `filtera.vue:432` 行 `initThingModel` 结尾调用 `handleEmits()`，但 `handleEmits` 的 emit 可能触发父组件 `v-model:filters` 更新，再次调用 `getProductObjectModel`。

**影响**: 可能触发多次不必要的 API 请求和父组件更新，极端情况下可能引发递归警告。

**修复方案**: 
1. 移除 `initThingModel` 中的 `handleEmits()` 调用
2. 或加防抖/标志位避免循环

**修复文件**: `filtera.vue` 第 428-432 行

---

### 🔴 严重：Bug #3 — listener.vue 同样存在 initThingModel → handleEmits 循环

**现象**: 与 Bug #2 相同，`listener.vue:522` 的 `initThingModel` 也调用 `handleEmits()`。

**影响**: 同上。

**修复文件**: `listener.vue` 第 520-522 行

---

### 🟡 中等：Bug #4 — filtera.vue 「使用当前设备」模式下 getPk 可能返回 null

**现象**: 用户在未配置监听器的情况下先添加过滤器，选择"使用当前设备"，物模型加载失败。

**根因**: `filtera.vue:440-449`
```typescript
const getPk = (item) => {
  if (item.deviceRadio === '指定设备') return item.pk
  if (props.listeners && props.listeners.length > 0) {
    const l = props.listeners.find(x => x.type === 'device' && x.pk)
    return l ? l.pk : null
  }
  return null
}
```
当 `props.listeners` 为空数组时直接返回 null。

**影响**: 过滤器条件的属性/事件选项下拉为空，用户无法配置过滤条件。

---

### 🟡 中等：Bug #5 — listener.vue 参数验证中 `!param.value` 对于 0/false 值误判

**现象**: 用户输入比较值 `0` 或选择布尔值 `0` 时，验证提示"请输入比较值"。

**根因**: `listener.vue:1030`
```typescript
if (!param.value) {
  ElMessage.error('请输入比较值')
  return false
}
```
`!0` 和 `!"0"` 为 `true`，导致合法值被拦截。

**影响**: 数值 `0` 和布尔 `false`(0) 无法通过监听器参数验证。

---

### 🟡 中等：Bug #6 — filtera.vue 编辑时条件类型(type)未自动回填

**现象**: 编辑已有规则时，filter 的 conditions 可能缺少 `type` 字段（property/state/tag），导致比较方式选择器和工作不正常。

**根因**: `filtera.vue:471-485` handleEmits 中尝试从 stateMap 回填 type，但编辑时数据是从 `normalizeFilterItem` 处理的 config JSON 来的，如果原始 config 没存 `type`，回填可能在 stateMap 还没加载完成时执行。

**影响**: 部分条件下拉选项可能不正确。

---

### 🟢 低优先级：Bug #7 — 列表页 `triggerOptions` 和 `lsnCond` 未在列表刷新时同步

**现象**: `getData()` 中只对列表数据的 `triggerOptions` 做了 normalize，但没有还原 `lsnCond`。

**根因**: `index.vue:416-421`
```typescript
data.value = (res.list || []).map((item) => ({
  ...item,
  triggerOptions: normalizeTriggerOptions(item.triggerOptions),
  // ❌ 缺少 lsnCond 还原
}))
```

**影响**: 列表页不需要 lsnCond（不渲染表单），影响较小。但定义上不一致。

---

### 🟢 低优先级：Bug #8 — listener.vue handleEmits 未过滤 internal 字段

**现象**: 与 output.vue/filtera.vue 不同，listener.vue 的 `handleEmits` 没有 stripUiField 逻辑。

**根因**: `listener.vue:538-551` 直接 emit 展开后的 config 对象。

**影响**: 当前 listener 条件对象不包含 __uiKey 等内部字段，所以目前不影响功能。但未来如果添加内部字段会有隐患。

---

### 🟢 低优先级：Bug #9 — filtera.vue 新增过滤器时默认 deviceRadio 为"指定设备"但无 pk

**现象**: 新增过滤器后，条件区域不显示。

**根因**: `filtera.vue:502-511` handleAdd 设置了 `deviceRadio: '指定设备'` 但没有默认 pk。条件区域 `v-if="item.pk || item.deviceRadio === '使用当前设备'"` 要求有 pk 或是"使用当前设备"。刚创建时 pk 为空且 mode 是指定设备，条件区域不显示。

**影响**: 用户体验：点了新增后需要选择设备才能看到条件配置区。这可能是有意设计，因为不选设备无法配置条件。

---

### 🟢 建议：优化建议 #1 — filtera.vue/listener.vue 重复代码大量存在

`buildNestedPathTree`, `buildNestedPathOptions`, `getAvailableComparators`, `getPropertyDataType`, 布尔/枚举/日期判断等逻辑在 `filtera.vue` 和 `listener.vue` 中完全重复。

**建议**: 提取为共享 composable (useFilterLogic.ts)。

---

### 🟢 建议：优化建议 #2 — onSave 中 listeners 配置缺少 `deviceRadio` 支持

当前 listener 的 `deviceRadio` 只支持单一设备选择（通过 select-product + select-device）。如果需要支持"使用当前设备"模式（如 filter 中的 radio-button），listener 的 save 逻辑需要扩展。

---

## 二、数据流完整性检查

### 保存流程 (create)
```
[用户填表] → onSave() → JSON.parse(JSON.stringify(toRaw(data)))
  → listeners: 提取 type/pk/dn/conditions，序列化为 config JSON 字符串
  → filters: 提取 type(device)/pk/dn/conditions/deviceRadio，序列化为 config JSON 字符串
  → actions: 标记 saved=true，设置 config JSON 字符串
  → triggerOptions: 合并 lsnCond，序列化
  → saveRule(API) → EiotRuleInfoServiceImpl.saveRule()
  → RuleInfoConvert.edit2Info() → EiotRuleInfoDO → DB
  → RuleManager.add() → parseRule() → 注册到内存索引
```

### 编辑流程 (edit)
```
[点击编辑] → handleOpenBeforeFun → normalizeRuleDetailData
  → normalizeConfigArray: 解析 config JSON 字符串，展开到 item 上
  → normalizeTriggerOptions: 合并默认值
  → lsnCond 还原
  → [output/filter/listener 子组件接收 props]
    → watch props → normalize → 回显数据
```

### 执行流程 (execute)
```
[设备消息] → RuleMessageHandler.match() → 找到匹配的 Rule[]
  → RuleExecutor.execute(rule, message)
    → doListeners: OR 匹配
    → doFilters: 根据 lsnCond 匹配
    → RateLimit: 限频检查
    → executeActions: 执行所有 Action
```

**检查结论**: 数据流闭合，但存在上述 Bug 需要修复。

---

## 三、修复计划

| 序号 | Bug | 优先级 | 修复文件 | 状态 |
|------|-----|--------|----------|------|
| 1 | filtera.vue cond 字段不持久化 | 🔴 | index.vue | ✅ 已修复 |
| 2 | filtera.vue initThingModel → handleEmits 循环 | 🔴 | filtera.vue | ✅ 已修复 |
| 3 | listener.vue initThingModel → handleEmits 循环 | 🔴 | listener.vue | ✅ 已修复 |
| 4 | filtera.vue getPk 对"使用当前设备"模式处理 | 🟡 | 无需修改 | ✅ 预期行为 |
| 5 | listener.vue 参数验证 0/false 误判 | 🟡 | listener.vue + filtera.vue | ✅ 已修复 |
| 6 | filtera.vue 编辑时 condition type 回填 | 🟡 | filtera.vue | ✅ 跟随 #2 修复 |

## 四、本轮修复详情

### 修复 #1: cond 字段持久化 (index.vue:367)
- 在 filter 的 `mObj` 中增加 `cond: m.cond !== undefined ? m.cond : 2`
- 确保保存时每个过滤器的条件组合逻辑(AND/OR/NOT)随 config JSON 一起持久化

### 修复 #2-#3: 消除 initThingModel → handleEmits 循环 (filtera.vue, listener.vue)
- 新增 `refreshConditionTypes()` 函数，物模型加载完成后直接更新 condition type 字段
- 替换 `initThingModel` 末尾的 `handleEmits()` 调用
- handleEmits 仍然从 watch(list) 触发（用户操作），不再从异步 API 回调触发

### 修复 #5: 0/false 值验证 (listener.vue:967, 1065; filtera.vue:783)
- `!param.value` → `param.value === undefined || param.value === null || param.value === ''`
- 数值 0 和布尔值 0/false 不再被误判为空值

### 未修改 #4: getPk 行为
- `getPk` 在"使用当前设备"模式下返回 null（当无监听器时）属于预期行为
- watch(props.listeners) 会在监听器配置后自动加载对应 pk 的物模型

## 五、第二轮修复（2026-08-05 下午）

### Bug #10: 告警触发脚本（CodeEditor）无法输入

**现象**: 告警动作的「告警触发脚本」「告警解除脚本」CodeEditor 无法正常输入文字。

**根因**: 三个问题叠加导致：

| 问题点 | 文件 | 说明 |
|--------|------|------|
| `v-if="isLoad"` 延迟渲染 | CodeEditor/index.vue | `isLoad` 初始 false → `onMounted` 后 true，codemirror 在第二个 tick 才创建 DOM，与父组件响应式链条冲突导致焦点丢失 |
| `configRef + deep:true watcher` | AlertAction/HttpAction/MqttAction/KafkaAction/TcpAction | 用户每次输入 → `service.script` 变化 → deep watcher 触发（因为深层属性变了）→ 不必要的重渲染 → CodeEditor 失焦 |
| 两处 CodeEditor 同时存在 | AlertAction | 触发脚本 + 解除脚本两个编辑器，双向的 deep watch 响应式链条加剧干扰 |

**修复**:
1. **CodeEditor/index.vue**: 删除 `v-if="isLoad"` 和 `isLoad` ref，codemirror 直接渲染，由库自行处理初始化
2. **所有 5 个 Action 组件** (AlertAction, HttpAction, MqttAction, KafkaAction, TcpAction): 删除 `configRef`、`init()`、`deep:true watcher`，改为组件初始化时一次性 `ensureServices()`
3. 对链路上所有 action 组件统一处理，避免同类问题在其他组件上复现
