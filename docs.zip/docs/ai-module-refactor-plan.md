# AI 模块数据瘦身重构方案

> 目标：**首页正常显示 + 回填数据/逻辑不变 + 砍掉冗余数据**。
> 范围：`module-ai` 的 AI 分析链路（输入 `YPondAnalysisInput` → 大模型 → 输出 `YAiOutput` → 落库/回填/首页）。
> 参考文档：`docs/home-page-api.md`、`docs/home-page-data-source.md`、小程序 `enjoy-mini-ten/docs/home-page-api.md`、`enjoy-mini-ten/src/pages/index/index.vue`。

---

## 一、现状：数据流全景

```
                    ┌─────────────────────────────────────────────────┐
  输入(input)         │  YPondAnalysisInput（给 AI 看的数据）            │
  ─────────────       │  基本信息 / alertThresholds / fixedParams /      │
                      │  rules / habits / yesterdayResult / devices /    │
                      │  reportSummary                                   │
                      └─────────────────────────────────────────────────┘
                                        │ DeepSeek
                                        ▼
                    ┌─────────────────────────────────────────────────┐
  输出(output)        │  YAiOutput（AI 返回的结构化 JSON）               │
  ─────────────       │  riskSummary / feedingAdvice / oxygenAdvice /    │
                      │  waterAdvice / adviceList / review /             │
                      │  portraitUpdate / adviceCredibility / homePage   │
                      └─────────────────────────────────────────────────┘
                                        │
        ┌───────────────────────────────┼───────────────────────────────┐
        ▼                               ▼                               ▼
  回填复盘(昨日记录)             落库(今日记录)                  首页读取
  review.executed/effective      advice_content                    analysis_output
  → 昨日 user_executed/          advice_credibility               .homePage
    execute_effective/           analysis_output                  → YHomePageRespVO
    review_conclusion/
    execute_discribe
        │
        └──────────► 画像沉淀 portraitUpdate.rules/habits/fixedParams
                     → y_pond_rule_library / y_farmer_habit_library / y_pond_fixed_params
```

---

## 二、前端实际消费清单（结论：只消费 homePage）

小程序 `enjoy-mini-ten` 只调用了 **2 个接口**（`src/api/analysis.js`）：

| 接口 | 用途 | 返回 |
|---|---|---|
| `GET /ai/analysis/home-page` | 首页七模块渲染 | `YHomePageRespVO`（仅 homePage 结构） |
| `POST /ai/analysis/run` | 手动触发一次分析 | 结果 id |

**没有被调用**（冗余接口）：
- `GET /ai/analysis/latest` → `YPondAnalysisRespVO`（含 riskSummary/feedingAdvice/oxygenAdvice/waterAdvice/adviceList + rules/habits/fixedParams）
- `GET /ai/analysis/recent`

首页 `index/index.vue` 逐字段消费的字段（全部来自 homePage 结构）：

| 模块 | 前端读取的字段 |
|---|---|
| `safety` | `score`、`level` |
| `aiConclusions` | `[].cls`、`[].segments[].text/strong`（固定 3 条） |
| `feed` | `adjust`、`data[].label/val/unit/note/infer/cls`、`ai.summary/detail` |
| `oxy` | `tag.text/cls`、`critical`（后端填）、`cols[].label/val/unit/cls`、`chart.data/labels/min/max/critical`（后端填）、`aeroPlan.start/end/hours`、`ai.summary/detail` |
| `wq` | `tag.text/cls`、`data[].label/val/unit/note/infer/cls`、`ai.summary/detail` |
| `review` | `done`（后端填）、`rate/level`（后端填）、`items[].name/state/status/impact/tag/tagType`、`ai.summary/detail` |
| `profile` | `stats[].num/label`（后端填） |
| `analysisTime` | 时间戳（后端填） |

> 注：小程序目前**没有**「塘口画像详情页」（`pages/profile` 是「我的」个人中心），首页画像卡只展示 `profile.stats` 4 个数字。

---

## 三、输出侧（YAiOutput）冗余分析与裁剪

### 3.1 逐字段用途核对

| 顶层字段 | 实际用途 | 是否冗余 | 结论 |
|---|---|---|---|
| `riskSummary` | 仅 `buildAdviceContent` + `buildSafety` 兜底 + 未用的 `/latest` 接口 | ✅ 冗余 | **删** |
| `feedingAdvice` | `calcFeedAdjust`（adjust 兜底）+ `buildAdviceContent` + 各 `build*` 兜底 + `/latest` | ✅ 冗余（adjust 已在 `homePage.feed.adjust`） | **删** |
| `oxygenAdvice` | 各 `build*` 兜底 + `buildAdviceContent` + `/latest` | ✅ 冗余 | **删** |
| `waterAdvice` | 各 `build*` 兜底 + `buildAdviceContent` + `/latest` | ✅ 冗余 | **删** |
| `adviceList` | `buildAdviceContent` + `/latest` | ✅ 冗余 | **删** |
| `review` | **复盘回填昨日记录**（`backfillReview`） | ❌ 关键回填 | **保留** |
| `portraitUpdate` | **画像沉淀**（规律/习惯/固定参数） | ❌ 关键回填 | **保留** |
| `adviceCredibility` | 落库 `advice_credibility` | ❌ 关键回填 | **保留** |
| `homePage` | 首页展示 | ❌ 必须 | **保留** |

### 3.2 裁剪后新 `YAiOutput` 结构

```json
{
  "homePage": {
    "safety":        { "score": 88, "level": "low|mid|high" },
    "aiConclusions": [ { "cls": "ok|warn|danger", "segments": [ { "text": "…", "strong": false } ] } ],   // 固定 3 条
    "feed": {
      "adjust": 6,
      "data": [ { "label": "水温", "val": "24.8", "unit": "℃", "note": "适宜", "infer": "→ 无碍", "cls": "good|warn|bad" } ],   // 3 项
      "ai": { "summary": [ … ], "detail": [ … ] }
    },
    "oxy": {
      "tag": { "text": "状态良好", "cls": "good|warn|danger" },
      "cols": [ { "label": "临界值", "val": "4.0", "unit": "mg/L", "cls": "good|warn|danger" } ],   // 3 项
      "aeroPlan": { "start": "22:00", "end": "06:00", "hours": "8小时" },
      "ai": { "summary": [ … ], "detail": [ … ] }
    },
    "wq": {
      "tag": { "text": "水质良好", "cls": "good|warn|danger" },
      "data": [ { "label": "pH", "val": "7.6", "unit": "", "note": "稳定", "infer": "→ 无碍", "cls": "good|bad" } ],   // 4 项
      "ai": { "summary": [ … ], "detail": [ … ] }
    },
    "review": {
      "items": [ { "name": "增氧机", "state": "已执行", "status": "done|half|no", "impact": "影响结果", "tag": "有效", "tagType": "good|half|bad" } ],
      "ai": { "summary": [ … ], "detail": [ … ] }
    }
  },
  "review": {
    "executed": "yes|no|partial",
    "effective": "excellent|good|fair|poor",
    "conclusion": "复盘结论",
    "reviewAnalysis": "复盘分析"
  },
  "portraitUpdate": {
    "rules": [ { "ruleTitle": "…", "ruleContent": "…", "credibility": 85 } ],
    "habits": [ { "habitTitle": "…", "habitDetail": "…", "habitTendency": "…", "impact": "…", "impactNote": "…", "credibility": 70 } ],
    "fixedParams": { }
  },
  "adviceCredibility": 85
}
```

> 顶层 `review` 与 `homePage.review` **不是同一回事，都要保留**：
> - 顶层 `review`（executed/effective/conclusion/reviewAnalysis）= 回填昨日记录的「整体判断」；
> - `homePage.review`（items + ai）= 首页展示的「逐条执行明细」。

---

## 四、输入侧（YPondAnalysisInput）冗余分析与裁剪

| 字段 | 现状 | 冗余点 | 方案 |
|---|---|---|---|
| `alertThresholds` | 从 `pond.alert_thresholds` 解析的阈值 Map | 与 `fixedParams` 重叠（溶氧/pH 上下限等） | **删**（只保留 `fixedParams` 作为红线参数唯一来源）⚠️ 需确认告警模块是否独立使用 `alert_thresholds` |
| `fixedParams` | 完整红线参数 DO | 无 | 保留 |
| `rules` | 可信度前 10 条 | 无 | 保留（10 条） |
| `habits` | `selectListByPondId` 全量，无上限 | 会无限膨胀 | **加 cap（可信度前 10 条）** |
| `yesterdayResult` | 完整 `YDailyAnalysisResultDO`（含 id/pondId/analysisDate/createTime/updater/deleted/tenantId 等系统噪声） | AI 复盘只需「昨日建议全文」 | **替换为轻量 DTO**：只含 `adviceContent`（+ 可选 `adviceCredibility`） |
| `devices[].lastProperties` | 最新值 Map | 连续量的尾点 ≈ `propertySeries` 尾点；开关量 ≈ `switchSegments` 尾段 | 低优先级，可后续再评估是否移除 |
| `devices[].dailyStats` | 日聚合 | 投喂前已在 `buildUserPrompt` 剔除 | 保持现状 |
| 基本信息 `pondCode/farmId/farmName` | 上下文 | AI 基本用不到 | 低优先级，可删（保留 pondName/pondType/areaMu/status） |

### 4.1 `yesterdayResult` 轻量化（重点）

- 新 DTO：`YesterdayAdvice { adviceContent; adviceCredibility; }`
- 从 `YDailyAnalysisResultDO` 抽取 `adviceContent` 填入，不再把整个 DO 序列化给 AI。
- 收益：输入更干净，避免系统字段（creator/updater/deleted/时间戳/tenant）泄入 prompt。

---

## 五、回填不变量对照（保证「回填不变」）

裁剪后，以下 5 处回填的**输入来源字段全部保留**，逻辑不动：

| 回填动作 | 依赖的 AI 输出字段 | 裁剪后 |
|---|---|---|
| `backfillReview` → 昨日 `is_reviewed/user_executed/execute_effective/execute_discribe/review_conclusion` | 顶层 `review.executed/effective/conclusion/reviewAnalysis` | ✅ 保留 |
| `backfillAnalysisResult` → 今日 `advice_credibility` | `adviceCredibility` | ✅ 保留 |
| `backfillAnalysisResult` → 今日 `analysis_output` | 整个 `YAiOutput` JSON（缩小后的） | ✅ 保留 |
| `backfillPondRules` → `y_pond_rule_library` | `portraitUpdate.rules[]`（ruleTitle/ruleContent/credibility） | ✅ 保留 |
| `backfillFixedParams` → `y_pond_fixed_params` | `portraitUpdate.fixedParams`（Map） | ✅ 保留 |
| `backfillFarmerHabits` → `y_farmer_habit_library` | `portraitUpdate.habits[]`（habitTitle/habitDetail/habitTendency/impact/impactNote/credibility） | ✅ 保留 |

**唯一需要改写的派生逻辑**：`advice_content`（今日建议全文）目前由 `buildAdviceContent` 从顶层字段（riskSummary/feedingAdvice/…）拼装。裁剪后改为**从 `homePage` 派生**（拼接 `aiConclusions` + `feed/oxy/wq/review.ai.summary` 文本），保持「昨日建议全文」语义不变——因为次日复盘 AI 就是靠它判断「昨天建议了什么」。

---

## 六、提示词改动

### 6.1 system 提示词

- 删除 `riskSummary / feedingAdvice / oxygenAdvice / waterAdvice / adviceList` 五段 schema。
- 保留 `homePage / review / portraitUpdate / adviceCredibility` 的 schema。
- 「特别注意」中与顶层字段相关的描述同步删除（如「水质建议要回答…」这类只服务于 waterAdvice 的说明可并入 homePage 的 wq 约束）。

### 6.2 user 提示词

- 数据说明按新 input 结构更新：
  - 删除 `alertThresholds` 的说明；
  - `yesterdayResult` 说明改为「仅含 adviceContent 昨日建议全文」；
  - `habits` 说明加上「可信度前 N 条」。
- （已完成的 24 小时窗口改动保持不变）

---

## 七、改动文件清单

### 后端 `module-ai`

| 文件 | 改动 |
|---|---|
| `dto/analysis/YAiOutput.java` | 删 `RiskSummary/FeedingAdvice/OxygenAdvice/WaterAdvice/AdviceItem` 五个内部类；`validate()` 同步删对应校验 |
| `dto/analysis/YPondAnalysisInput.java` | 删 `alertThresholds`；`yesterdayResult` 改为轻量 DTO（或新增 `YesterdayAdvice` 字段） |
| `dto/analysis/YesterdayAdvice.java`（新增） | `adviceContent` + `adviceCredibility` |
| `service/analysis/YPondDataCollector.java` | 删 `alertThresholds` 采集；`yesterdayResult` 抽取为轻量 DTO；`habits` 加 cap |
| `service/analysis/YPondAiPromptBuilder.java` | 删顶层 schema；更新数据说明 |
| `service/analysis/YPondAnalysisServiceImpl.java` | 删 `calcFeedAdjust`（及 buildHomeInput 中为 adjust 查昨日记录的逻辑）；重写 `buildAdviceContent`（从 homePage 派生）；删 `buildSafety/buildAiConclusions/buildFeed/buildOxy/buildWq/buildReview` 中依赖顶层字段的兜底分支；`buildHomeInput` 改为构造轻量 yesterdayResult |
| `controller/admin/analysis/vo/YPondAnalysisRespVO.java` | 删 riskSummary/feedingAdvice/oxygenAdvice/waterAdvice/adviceList 字段（`/latest` 接口不再返回这些） |
| `dal/mysql/analysis/YFarmerHabitLibraryMapper` | 新增 `selectTopListByPondId(pondId, limit)`（按 credibility 排序） |

### SQL / 提示词 seed

| 文件 | 改动 |
|---|---|
| `_sql/mysql/upgrade/ai_prompt_system_prompt_config.sql` | 同步删顶层 schema |
| `_sql/postgresql/ai_prompt_config.sql` | 同步 |
| `_sql/mysql/upgrade/ai_prompt_user_prompt_config.sql` | 同步数据说明 |
| `_sql/postgresql/ai_prompt_user_prompt_config.sql` | 同步 |
| `_sql/mysql/system.sql` / `system_mysql5.7.sql` / `postgresql/enjoy-iot.sql` | 同步 901/902 行 |
| 新增迁移 SQL | `UPDATE infra_config` 更新两段提示词 |

### 文档

| 文件 | 改动 |
|---|---|
| `docs/home-page-api.md` | 首页契约不变，但「AI 输出明细」相关段落（7.1 里的 AI 字段来源）需更新为「只含 homePage」 |
| `docs/home-page-data-source.md` | 同步更新「AI 落库」来源表 |

---

## 八、风险与边界

1. **`alertThresholds` 删除前必须确认**：`module-eiot` 的告警模块是否依赖 `pond.alert_thresholds` 字段独立告警。若是，则只从 AI 输入里去掉（不删字段），告警模块照旧读自己的。
2. **`/ai/analysis/latest` 与 `/recent` 接口**：小程序未调用，但若后台 web 端（`enjoy-web`）未来要用详情页，需评估。当前 `enjoy-web` 也未接这两个接口。
3. **历史 `analysis_output` 数据兼容**：已落库的旧 JSON 仍含顶层字段，`parseAiOutput` 用 `@JsonIgnoreProperties(ignoreUnknown=true)` 反序列化不受影响；但 `YAiOutput` 删字段后，旧数据里的顶层字段会被忽略（无害）。
4. **`advice_content` 语义**：改为从 homePage 派生后，文本风格会从「结构化罗列」变为「AI 结论摘要拼接」，需确认不影响次日复盘的判断质量。

---

## 九、实施顺序建议

1. **输入侧**（低风险，先做）：`habits` cap、`yesterdayResult` 轻量化、`alertThresholds` 移除（确认告警归属后）。
2. **输出侧**（大改，收益最大）：删 5 个顶层字段 + 重写 `buildAdviceContent`/删兜底分支/精简 `YAiOutput`/精简 VO。
3. **提示词 + SQL**：同步删 schema、更新数据说明、出新迁移 SQL。
4. **文档**：更新 `home-page-api.md` / `home-page-data-source.md`。
5. **回归验证**：跑一次 `analyzePond` 确认（a）首页 `getHomePage` 七模块正常；（b）`y_daily_analysis_result` 的 `advice_content` / `advice_credibility` / `analysis_output` 落库正确；（c）画像库 rules/habits/fixedParams 正常插入；（d）次日复盘回填 `user_executed/execute_effective` 正常。
