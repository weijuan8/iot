# Enjoy-IOT 物联网平台 · 工作交接文档

> 编制日期：2026-10-27
> 交接范围：**本 Git 仓库（enjoy-iot）自身需要交接的全部内容** —— 源码与 Git 仓库、服务器与部署运维、设备数据链路、AI 模块、功能现状与已知问题、操作演示清单。
>
> ⚠️ 本文档包含服务器 IP、数据库账号密码、API Key 等敏感信息，仅限内部交接使用，请勿外传。

---

## 〇、一页速览

| 项目 | 说明 |
|---|---|
| 系统名称 | Enjoy-IOT 智慧种养物联网平台（基于开源 enjoy-iot 二次开发） |
| 技术栈 | Spring Boot 3 + JDK 21 + MyBatis Plus + MySQL 8 + Redis + TDengine 3.3 + EMQX 5.8 + Vue3 前端 |
| 部署形态 | 单台云服务器，Jar 直启（`nohup java -jar`），无容器化编排、无 CI/CD |
| 环境 | 测试环境（端口 30010 / 测试库 `shihe`）、正式环境（端口 30011 / 正式库 `shihe-prod`），**共用同一台服务器、同一个 Redis 实例** |
| 核心业务 | 设备接入（GEIO / GE100D 网关）→ 传感器采集 → 规则引擎告警 → 塘口/场地管理 → AI 每日分析 |
| 代码规模 | 后端约 1000+ Java 文件；SQL 主库脚本 `shihe0916.sql` 含 81 张表 |

---

## 一、源码与 Git 仓库

### 1.1 仓库清单

| 仓库 | 地址 | 说明 |
|---|---|---|
| **后端主仓（本仓库）** | `https://gitee.com/yuange19960402/shihe.git`（remote 名：`shiheOrigin`） | 实际开发仓库，含全部后端代码 + AI 模块 + 部署脚本 + SQL + 文档 |
| 后端上游开源仓 | `https://gitee.com/open-enjoy/enjoy-iot.git`（remote 名：`origin`） | 上游 enjoy-iot 开源项目，仅用于同步上游更新 |
| **前端仓库** | `https://gitee.com/yuange19960402/shihe.git`（remote 名：`shiheOrigin`） | 目录 `enjoy-web/`，Vue3 管理后台 |
| 前端上游开源仓 | `https://gitee.com/open-enjoy/enjoy-web.git`（remote 名：`origin`） | 上游 enjoy-web 开源项目 |

⚠️ **重要提醒**：`enjoy-web` 的 `shiheOrigin` 远端地址与主仓**完全相同**（都指向 `shihe.git`），这一点需要向交接人核实是否配置有误，还是刻意把前端推到了同一个仓库的其他分支。交接时务必先 `git -C enjoy-web remote -v` 确认，避免推错仓库。

### 1.2 分支

- 当前工作分支：`v1.0.0-jdk21`（本地 + `shiheOrigin` + `origin` 三方同在）
- 其他分支：`dev`、`dev-jdk21`、`dev-jdk21-feature`、`feature-020-xiaozhi`、`v0.1.0`、`v0.2.0`
- **开发约定**：日常在 `v1.0.0-jdk21` 上直接提交，推到 `shiheOrigin`

### 1.3 目录结构（后端主仓）

```
enjoy-iot/
├── framework/        # 自研框架 starter（web/security/mybatis/redis/mq/job/tenant...）
├── module-eiot/      # 物联网核心业务（产品/设备/物模型/规则引擎/告警/时序数据）
│   ├── iot-components/          # 协议组件（见 5.1）
│   ├── module-eiot-api/
│   └── module-eiot-biz/
├── module-ai/        # AI 分析模块（塘口日报、DeepSeek 调用、提示词）
├── server/           # 启动模块：server/target/server.jar 就是部署产物
│   └── src/main/resources/      # application-{local,test,prod,eiot}.yml
├── enjoy-web/        # 前端（独立 Git 仓库）
├── _script/
│   ├── shell/        # 部署脚本（见 3.2）
│   └── docker/       # 本地中间件 docker-compose（见 2.3）
├── _sql/             # 数据库脚本（见 4.3）
├── docs/             # 设计文档 34 篇（见附录 A）
└── log/              # 本地运行日志（gz 归档，勿提交）
```

### 1.4 构建前置条件

- JDK 21、Maven 3.8+
- Node 18+（前端）
- **SSH 私钥**：`_script/shell/id_ed25519`（部署脚本依赖它登录服务器，**必须随代码一并交接，且注意该文件是否在 .gitignore 中**）
- 本地工作目录写死为 `/Users/weitianyuan/yuange/project/shihe/enjoy-iot`，换机器需改脚本中的 `PROJECT_DIR`

---

## 二、服务器与环境信息

### 2.1 云服务器

| 项 | 值 |
|---|---|
| 服务器 IP | `119.45.251.129` |
| 登录方式 | `ssh -i _script/shell/id_ed25519 root@119.45.251.129`（端口 22） |
| 部署根目录 | `/shihe_back/enjoy-iot/` |
| 测试后端 | `/shihe_back/enjoy-iot/server/server.jar`，日志 `app.log`，端口 **30010**，profile `test` |
| 正式后端 | `/shihe_back/enjoy-iot/prod-server/server.jar`，日志 `app-prod.log`，端口 **30011**，profile `prod` |
| 测试前端 | `/shihe_back/enjoy-iot/enjoy-web/`（`--delete` 同步） |
| 正式前端 | `/shihe_back/enjoy-iot/prod-enjoy-web/`（`--delete` 同步） |
| jar 备份目录 | `/shihe_back/backup/`（`enjoy-iot-prod_YYYYmmdd_HHMMSS.jar`，保留最近 10 份） |
| JVM 参数 | `-Xms512m -Xmx1024m -XX:MaxMetaspaceSize=256m -XX:MaxDirectMemorySize=256m -XX:+HeapDumpOnOutOfMemoryError` |

### 2.2 域名与访问入口

| 用途 | 地址 |
|---|---|
| 测试后端 API | `https://test-admin-api.paizhi-ai.com` |
| 正式后端 API | `https://admin-api.paizhi-ai.com` |
| 正式后端监听 | 仅 `127.0.0.1:30011`，**公网不直接开放**，由 nginx 反代 |
| 测试后端直连 | `http://119.45.251.129:30010` |
| 接口文档 | `/v3/api-docs`、Knife4j `/swagger-ui`（doc.html） |
| 健康检查 | `/actuator`（prod 暴露了全部端点，**存在未鉴权风险**，见第 8 节） |
| Druid 监控 | 测试开（`/druid/*`，无账号密码）；正式已关闭 |

⚠️ nginx 配置在服务器上，**不在本仓库**，交接时需单独导出 `/etc/nginx/conf.d/` 下的配置文件。

### 2.3 中间件（服务器上的 docker-compose，`_script/docker/`）

| 容器名 | 镜像 | 端口映射 | 账号 |
|---|---|---|---|
| `iot-mysql` | mysql:8 | 30015 → 3306 | root / `123456`（env `MYSQL_ROOT_PASSWORD`），业务账号见 2.4 |
| `iot-redis` | redis:6-alpine | 6379 | 密码 `DYcyTyuOFRagfyYav5K43sl`（requirepass） |
| `iot-emqx` | emqx/emqx:5.8.0 | 1883/8883/8083/8084/18083 | Dashboard `admin/public`（**默认口令，务必改**） |
| `eiot-server-td` | tdengine/tdengine:3.3.3.0 | 6030/6041/6043-6049 | root / `taosdata` |

未启用（compose 中已注释）：Zookeeper、Kafka、Elasticsearch；另有 `iot-server` 容器段（镜像名 `iot-server`，走 Dockerfile 构建，**当前生产并未用容器启动**）。

另有 `_script/docker/docker-compose-test.yml` 与 `docker.env`，用于本地/测试拉起中间件。

### 2.4 数据库

| 环境 | MySQL | Redis | TDengine |
|---|---|---|---|
| 测试 | `119.45.251.129:30015/shihe`，用户 `shihe` | `localhost:6379` db **8** | `jdbc:TAOS-RS://localhost:6041/eiot`，root/taosdata |
| 正式 | `119.45.251.129:30015/shihe-prod`，用户 `shihe-prod` | `localhost:6379` db **9** | `jdbc:TAOS-RS://localhost:6041/eiot_prod`，root/taosdata |

- MySQL 账号密码见 `server/src/main/resources/application-test.yml` / `application-prod.yml`（明文存储，交接文档外不宜传播）
- **测试与正式共用同一 MySQL 实例、同一 Redis 实例**，靠库名 / db index 隔离 —— 这是最大风险点，误操作会互相影响
- 配置中 JDBC 走公网 IP `119.45.251.129`，而注释写的是 localhost，说明服务在宿主机、MySQL 在 docker 且映射到了公网端口

---

## 三、程序部署、启动、重启、回滚

### 3.1 标准发布流程（必须按顺序）

```
1) 本地改代码 → git commit → git push shiheOrigin v1.0.0-jdk21
2) 测试环境： ./_script/shell/deploy.sh
3) 浏览器验证测试环境（https://test-admin-api.paizhi-ai.com 对应的前端）
4) 正式环境： ./_script/shell/deploy-prod.sh     # 复用测试的 jar，不重新打包
5) 前端（如需）： ./_script/shell/deploy-web.sh  /  deploy-prod-web.sh
```

**关键设计**：正式 jar **不是重新打包的**，而是从测试目录 `cp` 过去的，以保证"测过的包 = 上线的包"。所以**必须先 deploy.sh 再 deploy-prod.sh**，否则脚本会报"测试服务器未找到 server.jar"并退出。

### 3.2 脚本一览

| 脚本 | 作用 | 关键行为 |
|---|---|---|
| `deploy.sh` | 测试部署 | `mvn clean package -DskipTests` → rsync `server.jar` + `application-test.yml` → 重启 |
| `deploy.sh -reload` | 仅重启测试 | 跳过打包上传 |
| `deploy-prod.sh` | 正式部署 | 上传 `application-prod.yml` → 备份正式 jar → 复制测试 jar → 重启 |
| `deploy-prod.sh -reload` | 仅重启正式 | 不做任何复制/备份 |
| `deploy-web.sh` | 前端测试 | `npm run build:test` → rsync `--delete` 到 `enjoy-web/` |
| `deploy-prod-web.sh` | 前端正式 | `npm run build:prod` → rsync `--delete` 到 `prod-enjoy-web/` |
| `deployOld.sh` | 历史遗留版本 | 参考用，勿直接使用 |

⚠️ 停进程用的是 `pkill -f "<绝对路径>/server.jar"`，**必须带全路径**，否则会同时杀掉测试和正式两个服务（脚本注释里已特别标注）。

### 3.3 手工启动 / 停止 / 重启（服务器上直接执行）

```bash
# 启动（测试）
cd /shihe_back/enjoy-iot/server
nohup java -Xms512m -Xmx1024m -XX:MaxMetaspaceSize=256m -XX:MaxDirectMemorySize=256m \
  -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/shihe_back/enjoy-iot/server/ \
  -Djava.security.egd=file:/dev/./urandom \
  -jar server.jar --spring.profiles.active=test > app.log 2>&1 &

# 启动（正式）：同上，目录换 prod-server，profile 换 prod，日志 app-prod.log

# 停止（务必带全路径）
pkill -f "/shihe_back/enjoy-iot/server/server.jar"        # 测试
pkill -f "/shihe_back/enjoy-iot/prod-server/server.jar"   # 正式

# 查看进程
ps -ef | grep server.jar

# 实时日志
tail -f /shihe_back/enjoy-iot/server/app.log
tail -f /shihe_back/enjoy-iot/prod-server/app-prod.log
```

历史上用过 `screen -S enjoy-iot` / `screen -S enjoy-iot-prod` 会话名（脚本里保留 quit 逻辑），现在实际是 nohup 方式。

### 3.4 回滚

```bash
# 1) 列出可用备份
ls -lt /shihe_back/backup/enjoy-iot-prod_*.jar

# 2) 停止正式服务
pkill -f "/shihe_back/enjoy-iot/prod-server/server.jar"; sleep 2

# 3) 还原指定版本
cp /shihe_back/backup/enjoy-iot-prod_20261019_120000.jar \
   /shihe_back/enjoy-iot/prod-server/server.jar

# 4) 启动
cd /shihe_back/enjoy-iot/prod-server && nohup java ... --spring.profiles.active=prod > app-prod.log 2>&1 &
```

注意：
- **只保留最近 10 份 jar 备份**，更老的版本回滚不了
- **测试环境不备份 jar**，回滚只能重新 checkout 旧代码重新打包
- **数据库变更没有回滚脚本**（见第 4 节），结构变更需人工逆向

---

## 四、备份与恢复

### 4.1 现状（重要：这是当前最大的运维短板）

| 对象 | 是否有自动备份 | 现状 |
|---|---|---|
| 正式 jar | ✅ 有 | 每次 deploy-prod 自动备份到 `/shihe_back/backup/`，保留 10 份 |
| 测试 jar | ❌ 无 | 直接覆盖 |
| **MySQL 数据库** | ❌ **无任何自动备份** | 仅有手工导出的零散快照：仓库 `_sql/mysql/back/2026-0825/enjoyiot.sql`、`_sql/mysql/shihe.sql`、`_sql/mysql/shihe0916.sql` |
| **TDengine 时序数据** | ❌ **无任何备份** | 传感器历史数据全在这里，丢了无法恢复 |
| Redis | ❌ 无 | 仅缓存 + 设备最新值，可重建 |
| 前端 dist | ⚠️ 半自动 | 服务器上就是最新一份，覆盖式更新 |
| nginx 配置 | ❌ 无 | 不在仓库，需单独备份 |

**交接时必须口头强调：生产库目前没有定时备份，建议第一周内补上。**

### 4.2 建议立即补上的备份方案（未实现，需交接后落地）

```bash
# MySQL 每日全量备份（放到 crontab，0 3 * * *）
mysqldump -h127.0.0.1 -P30015 -ushihe-prod -p'密码' \
  --single-transaction --routines --triggers --default-character-set=utf8mb4 \
  shihe-prod | gzip > /shihe_back/backup/mysql/shihe-prod_$(date +%F).sql.gz

# 保留 30 天
find /shihe_back/backup/mysql -name "*.sql.gz" -mtime +30 -delete

# TDengine 备份（taosdump）
taosdump -h 127.0.0.1 -P 6030 -u root -p taosdata -D eiot_prod -o /shihe_back/backup/td/$(date +%F)
```

恢复：
```bash
gunzip < shihe-prod_2026-10-27.sql.gz | mysql -h127.0.0.1 -P30015 -ushihe-prod -p'密码' shihe-prod
taosdump -i /shihe_back/backup/td/2026-10-27 -u root -p taosdata
```

### 4.3 数据库脚本资产

| 路径 | 内容 |
|---|---|
| `_sql/mysql/shihe.sql`、`shihe0916.sql` | 主库结构与数据快照（81 张表） |
| `_sql/mysql/ai_analysis.sql`、`aquaculture_report.sql`、`farm_management.sql`、`system.sql` | 分模块建表脚本 |
| `_sql/mysql/upgrade/` | 增量变更脚本（11 个），如 `ai_prompt_system_prompt_config.sql`、`pond_add_ai_analysis_enabled.sql`、`module_device_add_owner_tenant_id.sql`、`visualization_menu_pages.sql` 等 |
| `_sql/mysql/back/` | 历史备份快照 |
| `_sql/migrations/` | 2026-08-28 告警记录表结构修复脚本（4 个，含 MySQL / PostgreSQL 两份） |
| `_sql/postgresql/` | PostgreSQL 版本脚本（当前未使用） |

⚠️ `system.sql` 中的后台账号初始化脚本**不含** `system_users.sql`（账号密码数据），导入后需要单独处理后台登录账号。

---

## 五、设备数据链路（网关协议 / MQTT / 绑定 / 采集 / 下行控制）

### 5.1 协议组件清单

`module-eiot/iot-components/` 下共 11 个组件，采用统一继承体系（设计见 `docs/iot组件框架继承体系设计文档.md`）：

| 组件 | 用途 | 状态 |
|---|---|---|
| `iot-component-core` | 组件抽象基类、生命周期 | 框架 |
| `iot-component-mqtt` | 通用 MQTT 透传 | ✅ |
| `iot-component-emqx` | EMQX 对接（设备上行/下行主通道） | ✅ 在用 |
| `iot-component-geio` | **智嵌物联 GE 系列网关**（主力设备） | ✅ 在用 |
| `iot-component-ge100d` | GE100D 单串口服务器（Modbus RTU 透传） | ✅ 在用 |
| `iot-component-geself` | 自定义 GE 扩展 | 新增，需确认 |
| `iot-component-tcp` / `udp` / `http` / `coap` | 其他接入方式 | 框架自带 |
| `iot-component-modbus-custom` | 自定义 Modbus | ✅ |

设计文档：
- `docs/iot组件框架继承体系设计文档.md`
- `docs/modbus-component-architecture.md`
- `docs/ge100d-modbus-rtu透传架构设计.md`
- `docs/mqtt-transparent-modbus-scheme.md`
- `docs/GE100D-协议完整逻辑说明.md`（协议最完整的说明，必读）

### 5.2 MQTT Topic 规范（GEIO / GE100D）

```
上行： {env}/{productKey}/{deviceName}/{moduleId}/serial/up
下行： {env}/{productKey}/{deviceName}/{moduleId}/serial/down
```
- `{env}`：生产 `geio`，测试 `testgeio`（服务端 `isProd()` 决定）；GE100D 前缀为 `ge100d`
- `{moduleId}`：**6 段式新格式**，对应 `y_module.id` 数字主键，是自动注册的关键
- 示例：`geio/apFx3ja3p3nHiSRW/geio_mlxy_test_01_01/123/serial/up`

⚠️ **旧 5 段固件（无 moduleId）上报会被服务端静默丢弃**，不报错。现场旧设备必须升级固件。详见 `docs/GEIO设备Topic改造指南.md`。

### 5.3 设备接入与绑定

1. 平台侧：创建**产品**（`product_key`）→ 配置**物模型**（ThingModel：属性/事件/服务）→ 创建**设备**（`device_name`），生成设备密钥
2. 设备侧：固件烧录 productKey / deviceName / 密钥 → 连 EMQX（1883）→ 按 5.2 的 Topic 上报
3. 自动注册：`docs/GEIO设备自动注册方案.md` —— 通过 Topic 中的 moduleId 关联到 `y_module`，完成设备与塘口/模块的绑定
4. 设备命名规则：`docs/geio设备命名规则.txt`
5. 设备状态（在线/离线）判定机制：`docs/设备状态管理机制详解.md`

核心接口前缀：`/eiot/device`（同时映射 `/eiot/device-ctrl`）、`/eiot/product`、`/eiot/thing-model`、`/eiot/component`、`/eiot/channel-config`、`/eiot/channel-template`

### 5.4 传感器采集与存储

```
设备 → EMQX → GeioComponent/Ge100DComponent 解析 → 映射物模型属性
     → ① Redis 最新值（设备影子/实时状态）
     → ② TDengine 时序库（按物模型自动建超级表/子表）
     → ③ 规则引擎判定 → 告警记录
```

- 时序库机制详见 `docs/物模型与TDengine自动建表存储机制.md`
- Redis 使用规范详见 `docs/redis存储与治理.md`
- 消息总线：`iot-message-bus`，生产类型由 `eiot.message.producer-type` 控制，正式配为 `spring-event`（进程内事件，**重启即丢，无持久化**）

### 5.5 下行控制（后台/小程序 → 设备）

```
POST /admin-api/eiot/device/service/invoke
Body: { deviceId, service, args: { raw_: "命令字符串" } }
      → DeviceService.invoke → 组件下行 → MQTT 下发 {env}/{pk}/{dn}/{moduleId}/serial/down
      → 网关 RS485/Modbus → 继电器/传感器 → 设备上行回复
```

- 完整链路设计：`docs/GE100D下行控制完整链路设计.md`
- 小程序侧说明：`docs/小程序下行控制方案.md`（文档记录了早期小程序只改前端状态、未调用后端的**历史问题**，现行是否已修需向前端确认）

### 5.6 规则引擎与告警

- 设计：`docs/规则引擎与告警系统设计详解.md`、使用指南 `docs/规则引擎与告警系统使用指南.md`
- 测试报告：`docs/rule-engine-test-report-2026-08-05.md`
- 告警中心逻辑：`docs/告警中心完整逻辑.md`；通用阈值告警：`docs/通用阈值告警设计方案.md`
- 接口前缀：`/eiot/rule_engine`、`/eiot/alert-config`、`/alert`、`/notify`
- 短信通道：`config.alert.sms-provider: aliyun`（阿里云短信，AK/SK 只在服务器 `application-prod.yml` 中，未进 Git）
- 相关表：`eiot_alert_record`（2026-08-28 做过结构修复，`_sql/migrations/`）

---

## 六、AI 模块

### 6.1 定位

对**塘口**做每日 AI 分析，输出水质/环境诊断 + 操作建议，供后台首页与塘口详情页展示。

### 6.2 调用的大模型

| 项 | 值 | 来源 |
|---|---|---|
| 接口 | `https://api.deepseek.com/chat/completions` | `YAiAnalysisConstants.DEEPSEEK_URL` |
| 模型 | `deepseek-chat` | `DEEPSEEK_MODEL` |
| API Key | 代码内默认值 `sk-7774d...`（硬编码） | `DEEPSEEK_API_KEY` |
| 超时 | 120 秒 | `DEEPSEEK_TIMEOUT_SECONDS` |
| 覆盖方式 | 环境变量 `AI_DEEPSEEK_API_KEY` / `AI_DEEPSEEK_URL` / `AI_DEEPSEEK_MODEL` | — |

⚠️ API Key 硬编码在 `module-ai/module-ai-api/.../YAiAnalysisConstants.java`，**不在 yml 中**。换 Key 需改代码重新打包，或设置环境变量。正式环境建议改为环境变量注入。

### 6.3 对外接口

| 前缀 | 路径 | 方法 | 作用 |
|---|---|---|---|
| `/ai/analysis` | `GET /latest?pondId=` | `YPondAnalysisController.getLatest` | 获取塘口最新分析结果 |
| | `GET /recent?pondId=` | `getRecent` | 最近 N 条分析记录 |
| | `GET /home-page?pondId=` | `getHomePage` | 首页聚合数据 |
| | `POST /run?pondId=` | `run` | **手动触发**单个塘口分析，返回记录 ID |
| | `POST /run-all` | `runAll` | **手动触发**全部塘口分析，返回条数 |
| `/ai/algorithm` | `POST /create`、`PUT /update`、`DELETE /delete?id=`、`GET /get?id=`、`GET /page` | `AlgorithmController` | 算法（提示词/规则）CRUD |

（接口走 `/admin-api` 前缀，即完整路径 `/admin-api/ai/analysis/run`）

另有一个旧版 `PondAnalysisController`（`/ai/analysis`），与 `YPondAnalysisController` 并存，**存在新旧两套实现**（见第 8 节）。

### 6.4 数据来源（投喂给 AI 的内容）

`YPondAnalysisServiceImpl` 组装 `YPondAnalysisInput`，包含：

1. **近 24 小时传感器数据**：从 TDengine 读（1 小时一个采样节点），走 `TdTemplate`
2. **农户上报数据**（昨日 + 今日）
3. **塘口规律**：`y_pond_rule_library`，取可信度最高的前 10 条（`RULE_QUERY_LIMIT = 10`）
4. **塘口静态参数**：`y_pond_fixed_params`
5. **塘口基本信息**：`y_pond`、`y_module_device`
6. **农户习惯库**：`y_farmer_habit_library`
7. 设备信息通过 `DeviceApi` 跨模块获取

### 6.5 提示词（Prompt）

- 构建类：`module-ai/.../service/analysis/PondAiPromptBuilder.java`
- 提示词内容可在数据库配置（迁移脚本 `ai_prompt_system_prompt_config.sql`、`ai_prompt_user_prompt_config.sql`、`ai_prompt_simplify_24h.sql` 在 `_sql/mysql/upgrade/`）
- 输出格式有契约，AI 返回 JSON → 解析为 `YAiOutput` → 调用 `validate()` 校验

### 6.6 规则与知识库

| 项 | 现状 |
|---|---|
| 分析规则 | **有**，`y_pond_rule_library`（塘口规律库，带可信度权重），参与提示词组装 |
| 农户习惯库 | **有**，`y_farmer_habit_library` |
| 默认阈值 | **有**，`y_default_threshold` |
| 塘口固定参数 | **有**，`y_pond_fixed_params` |
| **向量知识库 / RAG / embedding** | ❌ **未实现**，代码中无相关实现，也没有向量库 |

### 6.7 结果保存位置

| 表 | 内容 |
|---|---|
| `y_daily_analysis_result` | **主表**：每日分析结果，AI 输出全文以 JSON 字符串存在 `analysis_output` 字段；建议全文存 `advice_content` |
| `y_ai_analysis_output` | 明细/结构化输出（对应 `YAiAnalysisOutputDO`） |
| `y_aquaculture_report` | 养殖报告（另一个业务视角的产物，`/eiot/aquaculture-report`） |

建表脚本：`_sql/mysql/ai_analysis.sql`、`_sql/mysql/aquaculture_report.sql`；2.0 版表设计见 `docs/ai-module-2.0-分析输出表-tables.sql`

### 6.8 触发方式

- **定时**：`module-ai/.../task/YPondDailyAnalysisTask.java`，cron `0 0 6 * * ?`（**每天 06:00**），跑全部塘口
- **手动**：`POST /admin-api/ai/analysis/run`、`/run-all`
- ⚠️ 需确认定时任务在正式环境是否真的生效（`application-prod.yml` 排除了 `QuartzAutoConfiguration`，`@EnableScheduling` 由 `framework/spring-boot-starter-job` 提供，需实际观察每天 6 点后是否产生了 `y_daily_analysis_result` 记录来确认）

### 6.9 AI 模块其他文件

```
module-ai/
├── module-ai-api/enums/YAiAnalysisConstants.java   # 全部常量（cron、模型、阈值、回看天数）
├── module-ai-biz/
│   ├── controller/admin/analysis/YPondAnalysisController.java
│   ├── controller/admin/AlgorithmController.java
│   ├── service/analysis/YDeepSeekClient.java      # DeepSeek HTTP 客户端
│   ├── service/analysis/PondAiPromptBuilder.java  # 提示词构建
│   ├── service/analysis/PondDataCollector.java    # 数据采集
│   ├── service/analysis/PondPortraitUpdater.java  # 塘口画像更新
│   ├── service/analysis/YPondAnalysisServiceImpl.java  # 主流程（1000+ 行）
│   └── task/YPondDailyAnalysisTask.java
```

改造计划（未完成事项）见 `docs/ai-module-refactor-plan.md`。

---

## 七、功能清单

### 7.1 已完成（后端接口前缀，均在 `/admin-api` 下）

| 业务域 | 接口前缀 | 说明 |
|---|---|---|
| 产品 / 品类 | `/eiot/product`、`/eiot/category` | 产品定义、分类 |
| 设备管理 | `/eiot/device`、`/eiot/device-ctrl` | 设备 CRUD、状态、控制 |
| 物模型 | `/eiot/thing-model`、`/eiot/unit`、`/eiot/show-model` | 属性/事件/服务定义、单位 |
| 组件与通道 | `/eiot/component`、`/eiot/channel-config`、`/eiot/channel-template` | 协议组件配置 |
| 规则引擎 | `/eiot/rule_engine` | 规则编排（含 2026-08 测试报告） |
| 告警 | `/eiot/alert-config`、`/alert`、`/notify` | 告警配置、告警记录、通知 |
| 虚拟设备 / Modbus | `/eiot/virtual_device`、`/eiot/modbus` | 模拟设备、Modbus 配置 |
| OTA | `/eiot/ota` | 固件升级 |
| 关系 / 天气 | `/eiot/iot/relation`、`/eiot/weather` | 设备绑定关系、天气数据 |
| 场地 / 塘口 | `/eiot/farm`、`/eiot/pond`、`/eiot/module` | 养殖场、塘口、模块（单元）管理 |
| 数据分析 | `/eiot/y-data-analysis` | 数据统计 |
| 养殖报告 | `/eiot/aquaculture-report` | 报告生成 |
| AI 分析 | `/ai/analysis`、`/ai/algorithm` | 见第六节 |
| 首页/大屏 | 见 `docs/home-page-api.md` | 统计聚合 |

对应的自建业务表（`y_` 前缀，共 10 张）：
```
y_farm                  养殖场
y_pond                  塘口
y_pond_fixed_params     塘口固定参数
y_pond_rule_library     塘口规律库
y_module                模块（单元/设备组）
y_module_device         模块-设备绑定（含 owner_tenant_id）
y_farmer_habit_library  农户习惯库
y_default_threshold     默认阈值
y_aquaculture_report    养殖报告
y_daily_analysis_result AI 每日分析结果
（另有 y_ai_analysis_output，未在 CREATE 脚本中匹配到，需确认）
```

### 7.2 需求/设计已产出但需确认落地情况

- 多商户菜单与功能模块设计：`docs/多商户智慧养殖平台-菜单与功能模块设计方案.md`
- 可视化大屏页面脚本：`_sql/mysql/upgrade/visualization_menu_pages.sql`
- 首页 API 与数据源：`docs/home-page-api.md`、`docs/home-page-data-source.md`
- 告警模板/通用阈值告警：`docs/通用阈值告警设计方案.md`

### 7.3 明确未完成 / 待办

1. **AI 模块 2.0 重构**：`docs/ai-module-refactor-plan.md`（含新输出表设计 `docs/ai-module-2.0-分析输出表-tables.sql`）
2. **数据库自动备份**：完全没有（第 4 节）
3. **TDengine 备份**：完全没有
4. **向量知识库 / RAG**：未实现
5. **GEIO 旧固件升级**：5 段 Topic 的设备会静默丢数据，需现场批量升级固件
6. **小程序下行控制**：文档曾记录前端未真正调用后端（需复核现在是否已修）
7. **geself 组件**：新增组件，用途与联调状态需确认
8. **代码内 TODO/FIXME**：共约 30+ 处，主要集中在 module-eiot 与 server（交接后建议逐个清理）

### 7.4 历史演进（从 commit 记录还原）

```
2026-04  引入 enjoy-iot 开源基座
2026-06  README 更新
2026-07  塘口管理、养殖场前端静态页
2026-08  数据上报切换场地、规则引擎+通知、租户隔离改为部门隔离、AI 首页开发、告警结构修复
2026-09  统计页面完善、连续告警重复问题修复、单元页面优化、AI 提示词优化（支持开关数据）
2026-10  物联网平台测试版+正式版上线（10-13）、AI 优化（10-19）
```

---

## 八、已知问题与注意事项

### 8.1 安全类（优先级最高）

| 级别 | 问题 |
|---|---|
| 🔴 | API Key 硬编码在 Java 常量中（`YAiAnalysisConstants`），且随代码提交到 Git |
| 🔴 | MySQL / Redis / TDengine 密码明文写在 `application-*.yml` 并提交到仓库 |
| 🔴 | 正式环境 `/actuator` 暴露全部端点且无鉴权（`management.endpoints.web.exposure.include: '*'`） |
| 🔴 | EMQX Dashboard 仍是默认口令 `admin/public`（若 18083 映射到了公网） |
| 🟡 | MySQL 30015 端口映射在公网 IP 上（`119.45.251.129:30015`） |
| 🟡 | SSH 私钥 `id_ed25519` 放在仓库 `_script/shell/` 下 |
| 🟡 | 测试环境 Druid 监控台开启且无账号密码 |
| 🟡 | 微信公众号/小程序 AppSecret、腾讯云 LBS Key、钉钉/企微 key 明文在 yml 中 |

### 8.2 架构类

| 级别 | 问题 |
|---|---|
| 🔴 | 测试与正式**共用同一台服务器、同一 MySQL 实例、同一 Redis 实例**，仅靠库名/db index 隔离；MySQL 端口又是公网可达，误连即事故 |
| 🔴 | 停服务用 `pkill -f` 模式匹配，路径写错会误杀另一套环境 |
| 🟡 | 消息总线用 `spring-event`（进程内），**服务重启期间消息丢失**，无持久化队列 |
| 🟡 | 服务以 `nohup` 裸跑，**没有 systemd/supervisor 守护**，进程挂了不会自动拉起，服务器重启后也不会自启 |
| 🟡 | 前端部署用 `rsync --delete`，本地 dist 不完整会直接把线上文件删光 |
| 🟡 | 无 CI/CD、无健康检查告警、无日志轮转（`app.log` 会无限增长） |
| 🟢 | AI 模块新旧两套实现并存（`PondAnalysisController` 与 `YPondAnalysisController`，`DeepSeekClient` 与 `YDeepSeekClient`，DO 也分两套），后续维护容易改错地方 |

### 8.3 数据类

| 级别 | 问题 |
|---|---|
| 🔴 | 生产数据库无备份 |
| 🔴 | TDengine 历史时序数据无备份 |
| 🟡 | 主库快照文件有多个版本（`shihe.sql`、`shihe0916.sql`、`back/2026-0825/enjoyiot.sql`），**哪一份是最新基线未标明** |
| 🟡 | 曾做过"租户隔离 → 部门隔离"改造（`system_tenant_add_parent_id.sql`、`device_info_drop_tenant_id.sql`、`module_device_add_owner_tenant_id.sql`），历史数据可能有遗留脏值 |
| 🟡 | 告警记录表 2026-08-28 做过结构修复，历史告警数据可能不一致 |

### 8.4 其他提醒

- 工作区当前有**大量未提交改动**（deploy 脚本修改、`enjoy-web` 子仓库有未提交内容、`log/` 下大量 gz 日志被删），交接前需先 `git status` 梳理、确认哪些要提交
- 仓库根目录有 `LOG_FILE_IS_UNDEFINED`、`LOG_FILE_IS_UNDEFINED.2026-07-07.0.gz` 两个异常文件，说明某次启动未配置日志变量，可清理
- `application-eiot.yaml` 是开源基座自带的**独立部署**示例配置（指向 `eiot-server-db` 等容器名），**本项目实际并未使用**，不要误改它以为会影响生产

---

## 九、交接演示与录屏清单

建议按下面顺序录屏，每段 3-8 分钟，边操作边讲解：

| # | 演示内容 | 关键步骤 |
|---|---|---|
| 1 | 代码拉取与构建 | clone 两个仓库 → 配 JDK21/Maven → `mvn clean package -DskipTests` → 本地 `profile=local` 启动 |
| 2 | 测试环境部署 | 执行 `deploy.sh` → 看 `app.log` → 访问 `http://119.45.251.129:30010` 与 swagger |
| 3 | 正式环境部署与回滚 | `deploy-prod.sh` → 演示 `/shihe_back/backup/` 生成 → 演示 `pkill` + 还原旧 jar 重启 |
| 4 | 前端部署 | `npm run build:prod` → `deploy-prod-web.sh` → 访问 `admin-api.paizhi-ai.com` 对应后台 |
| 5 | 设备接入 | 后台新建产品/物模型/设备 → 用 MQTT 客户端模拟上报（按 6 段 Topic）→ 看数据落到 TDengine |
| 6 | 下行控制 | 后台/接口 `POST /admin-api/eiot/device/service/invoke` → 观察设备收到 → 上行回复 |
| 7 | 规则引擎与告警 | 配一条阈值规则 → 制造超阈值数据 → 看告警记录与通知 |
| 8 | AI 分析 | `POST /admin-api/ai/analysis/run?pondId=xx` → 查 `y_daily_analysis_result` → 前台展示效果 |
| 9 | 数据库备份与恢复 | mysqldump 备份 → 导入到临时库验证 → 说明当前"无自动备份"的现状 |
| 10 | 常见故障排查 | 服务起不来怎么看日志、端口占用、EMQX 连不上、TDengine 查不到数据 |

---

## 附录 A：关键文档索引（`docs/`）

| 分类 | 文档 |
|---|---|
| 设备协议 | `GE100D-协议完整逻辑说明.md`、`GE100D下行控制完整链路设计.md`、`ge100d-modbus-rtu透传架构设计.md`、`mqtt-transparent-modbus-scheme.md`、`GEIO设备Topic改造指南.md`、`GEIO设备自动注册方案.md`、`geio设备命名规则.txt`、`geself.pdf` |
| 设备手册 | `智嵌物联GE系列单串口服务器使用手册V1.1.pdf`、`智嵌物联4G DTU设备系列使用手册V1.5(1).pdf` |
| 架构 | `iot组件框架继承体系设计文档.md`、`modbus-component-architecture.md`、`物模型与TDengine自动建表存储机制.md`、`redis存储与治理.md`、`设备状态管理机制详解.md` |
| 告警 | `告警中心完整逻辑.md`、`规则引擎与告警系统设计详解.md`、`规则引擎与告警系统使用指南.md`、`rule-engine-test-report-2026-08-05.md`、`通用阈值告警设计方案.md` |
| AI | `ai-module-refactor-plan.md`、`ai-module-2.0-分析输出表-tables.sql` |
| 业务 | `养殖场管理系统开发说明.md`、`多商户智慧养殖平台-菜单与功能模块设计方案.md`、`home-page-api.md`、`home-page-data-source.md`、`小程序下行控制方案.md` |
| 权限 | `多租户实现原理与工作流程.md`、`多租户隔离机制完整解析.md`、`用户-租户-部门关系说明.md` |
| 其他 | `fullblood-thing-model-old-vs-new-chain-2026-04-23.md`、`history_20260822.md`、`history_202608221049.md`、`note.txt` |

## 附录 B：交接当天建议做的确认动作

1. 现场 `git status` + `git log -5`，确认工作区改动归属并决定提交还是丢弃
2. 现场登录服务器，跑 `ps -ef | grep server.jar`、`df -h`、`free -h`、`docker ps` 记录现状
3. 现场 `mysqldump` 一份正式库快照留存（因为目前没有任何数据库备份）
4. 验证 `y_daily_analysis_result` 最近 7 天是否有数据，确认 AI 定时任务真的在跑
5. 确认 EMQX 设备在线数、TDengine 数据条数与业务认知一致
6. 让交接人当场演示一遍 `deploy.sh` → `deploy-prod.sh` 全流程
