# 首页接口数据格式说明（后端返回）

> 目的：后端按本文档返回首页数据。只写后端需要关心的：字段名、类型、取值、业务含义。
> 后端无需关心前端如何渲染，也无需返回任何颜色/图标等样式信息。
> 参考 mock：`src/mock/home-mid.js` / `home-safe.js` / `home-danger.js`（三份对应三种业务状态，结构完全一致）。

---

## 1. 返回结构总览

```
data (object)
├── analysisTime     本次分析时间（number，毫秒时间戳；= 首页所用最新一条分析记录的创建时间，即 AI 分析落库时刻；无分析记录时不返回）
├── safety           安全指数
├── aiConclusions[]  今日结论（3 条，依次对应 饲喂 / 溶氧 / 水质 三个模块）
├── feed             今日饲喂建议
├── oxy              溶氧预警（cols 为参考指标列表，数量不限）
├── wq               昨日水质研判（data 为昨日实测值）
├── review           昨日建议复盘
└── profile          塘口画像
```

## 2. 通用类型

| 类型 | 说明 |
|---|---|
| `number` | 数字 |
| `string` | 字符串 |
| `boolean` | `true` / `false` |
| `enum: a\|b` | 枚举，只能取列出的其中一个值 |
| `array` | 数组 |
| `object` | 对象 |

### 2.1 状态枚举总表

所有枚举字段的取值与业务含义：

| 状态值 | 业务含义 |
|---|---|
| `ok` | 正常 / 良好 |
| `good` | 达标 / 有效 / 正常 |
| `warn` | 预警 / 临界 / 需注意 |
| `half` | 部分执行 / 未达标 |
| `danger` | 危险 / 严重 |
| `bad` | 超标 / 恶化 / 偏高 |
| `done` | 已执行 |
| `no` | 未执行 |
| `low` | 低风险 / 良好（等级类） |
| `mid` | 中风险 / 一般（等级类） |
| `high` | 高风险 / 待改进（等级类） |

### 2.2 富文本片段（`segments[]`）

每个元素是一个对象，多段拼成一段文字：

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `text` | string | 是 | 一段文字 |
| `strong` | boolean | 否（默认 `false`） | `true` = 该段是需要突出的内容（数字、时间、关键结论），可理解为加粗 |

### 2.3 AI 建议（`ai`）

AI 建议统一为对象，分两部分（`feed.ai` / `oxy.ai` / `wq.ai` / `review.ai` 均为此结构）：

| 字段 | 类型 | 必填 | 取值与含义 |
|---|---|---|---|
| `ai.summary` | 富文本片段数组 | ★ | **概要，2-3 行**，展示在首页卡片 |
| `ai.detail` | 富文本片段数组 | ★ | **完整分析，≤500 字**，点击「完整分析」弹窗展示 |

---

## 3. 逐字段说明

> 标记：`★` 必填；`▽` 可选。

### 3.1 `safety` — 安全指数

| 字段 | 类型 | 必填 | 取值与含义 |
|---|---|---|---|
| `safety.score` | number | ★ | 安全指数分值，整数 `0-100` |
| `safety.level` | enum: `low\|mid\|high` | ★ | 安全等级：`low` 低风险 / `mid` 中风险 / `high` 高风险 |

### 3.2 `aiConclusions[]` — 今日结论列表（固定 3 条，依次对应下方三个模块）

| 字段 | 类型 | 必填 | 取值与含义 |
|---|---|---|---|
| `cls` | enum: `ok\|warn\|danger` | ★ | 结论状态：`ok` 正常 / `warn` 预警 / `danger` 危险 |
| `segments[]` | array | ★ | 结论文字，富文本片段（见 2.2） |

> 约定：**3 条结论顺序固定，依次对应页面下方三个模块**：
> 1. 第 1 条 = 饲喂建议（对应 `feed`）
> 2. 第 2 条 = 溶氧建议（对应 `oxy`）
> 3. 第 3 条 = 水质研判（对应 `wq`）
>
> 每条为对应模块的**一句话总结，控制在 10-25 字**，只陈述结论与关键数字，不展开论证（详细论证见各模块 `ai.detail`）。

### 3.3 `feed` — 今日饲喂建议

| 字段 | 类型 | 必填 | 取值与含义 |
|---|---|---|---|
| `adjust` | number | ★ | 较昨日投喂量增减百分比：正数=增加，负数=减少，`0`=不变。如 `-10` 表示减少 10% |
| `data[]` | array | ★ | 指标内容不限制数量（建议三个，前端一行渲染三个）：**只能取自本塘口实际安装的传感器**（如水温、溶氧；未装氨氮则不返回氨氮），与底部 ai 建议相互呼应 |
| `data[].label` | string | ★ | 指标名 |
| `data[].val` | string | ★ | 数值文本 |
| `data[].unit` | string | ▽ | 单位（如 `℃` / `mg/L`），无单位传 `""` |
| `data[].note` | string | ★ | 指标状态备注（如 `代谢偏快`） |
| `data[].infer` | string | ★ | 对投喂的推论（如 `→ 减量防积食`） |
| `data[].cls` | enum: `good\|warn\|bad` | ★ | 指标状态：`good` 正常 / `warn` 预警 / `bad` 超标 |
| `ai` | object | ★ | AI 建议：`{ summary 概要, detail 完整分析 }`（见 2.3） |

### 3.4 `oxy` — 溶氧预警

> 业务口径：`cols[]` 固定为 3 项（临界值、跌破时间、最低溶氧），且**全部由后端依据 24h 溶氧曲线实时计算**，不使用 AI 输出（AI 无法感知实时曲线，易与曲线矛盾）。
> 一致性保证：`临界值` 取自塘口建议的最低溶氧（缺省 4.0），与 `chart.critical` 一致；`最低溶氧` = `chart.data[]` 的最小值；`跌破时间` = 曲线首次跌破临界值的时刻，若曲线全天未跌破则固定返回 `"无"`。

| 字段 | 类型 | 必填 | 取值与含义 |
|---|---|---|---|
| `tag.text` | string | ★ | 状态标签文案（如 `状态良好` / `临界注意` / `严重缺氧`） |
| `tag.cls` | enum: `good\|warn\|danger` | ★ | 溶氧状态：`good` 正常 / `warn` 临界 / `danger` 严重缺氧 |
| `critical` | number | ★ | 溶氧临界值，单位 mg/L（如 `4.0`），低于此值视为缺氧 |
| `cols[]` | array | ★ | 固定 3 项：临界值、跌破时间、最低溶氧，**由后端按 24h 曲线计算**，与 `chart.data[]` 严格一致 |
| `cols[].label` | string | ★ | 指标名 |
| `cols[].val` | string | ★ | 数值文本；跌破时间无跌破传 `"无"` |
| `cols[].unit` | string | ▽ | 单位，可为 `""` |
| `cols[].cls` | enum: `good\|warn\|danger` | ★ | 对应项状态 |
| `chart.data[]` | number[] | ★ | 24 小时溶氧序列，**恰好 25 个点**（0~24 时，每小时 1 个），单位 mg/L |
| `chart.labels[]` | string[] | ▽ | 时间刻度，默认 `["00:00","06:00","12:00","18:00","24:00"]`，可省略 |
| `chart.min` | number | ★ | 曲线 y 轴下限，需小于数据最小值 |
| `chart.max` | number | ★ | 曲线 y 轴上限，需大于数据最大值 |
| `chart.critical` | number | ★ | 临界值，**须与 `oxy.critical` 一致** |
| `aeroPlan.start` | string | ★ | 增氧开始时间，格式 `HH:mm`；无需增氧传 `"—"` |
| `aeroPlan.end` | string | ★ | 增氧结束时间，格式 `HH:mm` |
| `aeroPlan.hours` | string | ★ | 时长文案（如 `5.5 小时`）；无需增氧传 `无需增氧` |
| `ai` | object | ★ | AI 建议：`{ summary 概要, detail 完整分析 }`（见 2.3） |

### 3.5 `wq` — 昨日水质研判

> 业务口径：`data[]` 是**昨日水质实测值**（昨日水质情况）；`tag` / `ai` 是根据历史数据（如近 24 小时趋势）给出的**今日建议**。

| 字段 | 类型 | 必填 | 取值与含义 |
|---|---|---|---|
| `tag.text` | string | ★ | 状态标签文案（如 `水质良好` / `氨氮偏高` / `多项超标`） |
| `tag.cls` | enum: `good\|warn\|danger` | ★ | 水质状态：`good` 正常 / `warn` 单项偏高 / `danger` 多项超标 |
| `data[]` | array | ★ | 昨日水质实测值：仅包含**本塘口实际安装**的传感器指标（如 pH、溶氧、水温；未装氨氮则不返回氨氮） |
| `data[].label` | string | ★ | 指标名 |
| `data[].val` | string | ★ | 数值文本 |
| `data[].unit` | string | ▽ | 单位，可为 `""` |
| `data[].note` | string | ★ | 状态备注（如 `稳定` / `偏高`） |
| `data[].infer` | string | ★ | 建议动作（如 `→ 减料+微流水`） |
| `data[].cls` | enum: `good\|bad` | ★ | 该项状态：`good` 正常 / `bad` 超标 |
| `ai` | object | ★ | AI 建议：`{ summary 概要, detail 完整分析 }`（见 2.3） |

### 3.6 `review` — 昨日建议复盘

| 字段 | 类型 | 必填 | 取值与含义 |
|---|---|---|---|
| `rate` | number | ★ | 执行率，整数 `0-100`（`done / items.length × 100`） |
| `level` | enum: `low\|mid\|high` | ★ | 执行率等级：`low` 执行良好（≥80%）/ `mid` 一般（60-79%）/ `high` 待改进（<60%） |
| `done` | number | ★ | 已执行条数，非负整数，**须 ≤ `items.length`** |
| `items[]` | array | ★ | 逐条明细，数量 = 昨日建议总数 |
| `items[].name` | string | ★ | 动作名（如 `增氧机` / `晚间减料`） |
| `items[].state` | string | ★ | 状态文字（如 `已执行` / `部分执行` / `未执行`） |
| `items[].status` | enum: `done\|half\|no` | ★ | 执行状态：`done` 已执行 / `half` 部分执行 / `no` 未执行 |
| `items[].impact` | string | ★ | 影响结果（如 `溶氧 3.2→4.2`） |
| `items[].tag` | string | ★ | 结果标签文字（如 `有效` / `未达标` / `偏高`） |
| `items[].tagType` | enum: `good\|half\|bad` | ★ | 结果状态：`good` 有效/达标 / `half` 未达标 / `bad` 恶化/超标 |
| `ai` | object | ★ | 复盘结论（AI 建议结构，见 2.3）：`summary` 概要（2-3 行）/ `detail` 完整复盘分析（≤500 字） |

### 3.7 `profile` — 塘口画像

| 字段 | 类型 | 必填 | 取值与含义 |
|---|---|---|---|
| `stats[]` | array | ★ | 4 项核心统计 |
| `stats[].num` | string | ★ | 数字文本（如 `68` / `78%`） |
| `stats[].label` | string | ★ | 统计名（如 `分析天数` / `采纳率`） |

---

## 4. 完整响应示例

三份示例对应三种业务状态，字段结构完全一致，仅状态值/数值不同，照抄结构即可。

### 4.1 低风险 — 安全指数 88、执行率 100%

```json
{
  "safety": { "score": 88, "level": "low" },
  "aiConclusions": [
    { "cls": "ok", "segments": [
      { "text": "今日建议投喂 ", "strong": false },
      { "text": "52 kg", "strong": true },
      { "text": "（较昨日 +6%，早 07:00 18 / 晚 17:00 34）", "strong": false }
    ] },
    { "cls": "ok", "segments": [
      { "text": "溶氧全天 " },
      { "text": "5.2 mg/L", "strong": true },
      { "text": " 以上，夜间无需增氧", "strong": false }
    ] },
    { "cls": "ok", "segments": [
      { "text": "水质各项正常，今日无需干预", "strong": false }
    ] }
  ],
  "feed": {
    "adjust": 6,
    "data": [
      { "label": "水温", "val": "24.8", "unit": "℃", "note": "适宜", "infer": "→ 无碍", "cls": "good" },
      { "label": "溶氧谷值", "val": "5.4", "unit": "mg/L", "note": "良好", "infer": "→ 无需顾虑", "cls": "good" },
      { "label": "氨氮", "val": "0.05", "unit": "mg/L", "note": "正常", "infer": "→ 可放心投喂", "cls": "good" }
    ],
    "ai": {
      "summary": [
        { "text": "水温 " }, { "text": "24.8℃", "strong": true },
        { "text": " 适宜、溶氧谷值 " }, { "text": "5.4", "strong": true },
        { "text": " 良好、氨氮 " }, { "text": "0.05", "strong": true },
        { "text": " 正常 → 建议较昨日 " }, { "text": "增加投喂 6%", "strong": true },
        { "text": "，把握生长黄金期，成本效益最佳。" }
      ],
      "detail": [
        { "text": "水温 " }, { "text": "24.8℃", "strong": true },
        { "text": " 处于快速生长期最适区间、溶氧谷值 " }, { "text": "5.4 mg/L", "strong": true },
        { "text": " 全天高于临界、氨氮 " }, { "text": "0.05", "strong": true },
        { "text": " 极低，三项指标均健康 → 建议较昨日 " }, { "text": "增加投喂 6%", "strong": true },
        { "text": "（52 kg，早 07:00 投 18 kg / 晚 17:00 投 34 kg），抓住生长黄金期提升效益。明日按溶氧走势与残饵情况决定是否继续加量。" }
      ]
    }
  },
  "oxy": {
    "tag": { "text": "状态良好", "cls": "good" },
    "critical": 4.0,
    "cols": [
      { "label": "临界值", "val": "4.0", "unit": "mg/L", "cls": "warn" },
      { "label": "跌破时间", "val": "无", "unit": "", "cls": "good" },
      { "label": "最低溶氧", "val": "5.4", "unit": "mg/L", "cls": "good" }
    ],
    "chart": {
      "data": [5.4, 5.2, 5.1, 5.0, 4.9, 4.8, 4.7, 4.7, 4.8, 5.0, 5.4, 5.9, 6.5, 7.1, 7.6, 8.0, 8.0, 7.7, 7.2, 6.7, 6.2, 5.9, 5.7, 5.5, 5.4],
      "labels": ["00:00", "06:00", "12:00", "18:00", "24:00"],
      "min": 2.0,
      "max": 8.0,
      "critical": 4.0
    },
    "aeroPlan": { "start": "—", "end": "—", "hours": "无需增氧" },
    "ai": {
      "summary": [
        { "text": "近 24 小时溶氧最低 " }, { "text": "5.4 mg/L", "strong": true },
        { "text": "，始终高于临界 " }, { "text": "4.0", "strong": true },
        { "text": "，夜间无需增氧；午后可适当延长停氧时间节电。" }
      ],
      "detail": [
        { "text": "近 24 小时溶氧最低 " }, { "text": "5.4 mg/L", "strong": true },
        { "text": "，始终高于临界 " }, { "text": "4.0", "strong": true },
        { "text": "，全天未跌破临界，夜间无需增氧。白天光合作用充足，午后出现溶氧峰值，可适当延长停氧时间节电。明日重点关注清晨谷值，若连续两日低于 4.5 可提前开增氧机预防。" }
      ]
    }
  },
  "wq": {
    "tag": { "text": "水质良好", "cls": "good" },
    "data": [
      { "label": "pH", "val": "7.6", "unit": "", "note": "稳定", "infer": "→ 无碍", "cls": "good" },
      { "label": "溶氧", "val": "7.2", "unit": "mg/L", "note": "充足", "infer": "→ 良好", "cls": "good" },
      { "label": "水温", "val": "24.8", "unit": "℃", "note": "适宜", "infer": "→ 无碍", "cls": "good" },
      { "label": "氨氮", "val": "0.05", "unit": "mg/L", "note": "正常", "infer": "→ 无需干预", "cls": "good" }
    ],
    "ai": {
      "summary": [
        { "text": "pH、溶氧、水温、氨氮四项指标均处于 " }, { "text": "安全区间", "strong": true },
        { "text": "，水质稳定，今日维持常规管理即可。" }
      ],
      "detail": [
        { "text": "昨日水质四项实测指标全部处于安全区间，结合近 24 小时数据氨氮持续低位、无上升趋势，说明底部有机质分解与投喂量匹配良好。今日无需干预，维持常规投喂与增氧管理，明日重点关注午后水温，若持续高于 " }, { "text": "27℃", "strong": true },
        { "text": " 需适当减量。" }
      ]
    }
  },
  "review": {
    "rate": 100,
    "level": "low",
    "done": 3,
    "items": [
      { "name": "增氧机", "state": "已执行", "status": "done", "impact": "溶氧 5.0→5.8", "tag": "有效", "tagType": "good" },
      { "name": "晚间减料", "state": "已执行", "status": "done", "impact": "实际减 6%", "tag": "达标", "tagType": "good" },
      { "name": "午后微流水", "state": "已执行", "status": "done", "impact": "氨氮 0.08→0.05", "tag": "有效", "tagType": "good" }
    ],
    "ai": {
      "summary": [
        { "text": "昨日三条建议全部执行且效果良好，溶氧/氨氮均改善，今日延续并小幅加量" }
      ],
      "detail": [
        { "text": "昨日 3 条建议全部执行：增氧后溶氧 " }, { "text": "5.0→5.8", "strong": true },
        { "text": "、减料执行到位、微流水使氨氮 " }, { "text": "0.08→0.05", "strong": true },
        { "text": "，三项指标均改善，方案科学有效。今日延续并小幅加量，保持每日监控。" }
      ]
    }
  },
  "profile": {
    "stats": [
      { "num": "92", "label": "分析天数" },
      { "num": "118", "label": "累计建议" },
      { "num": "86%", "label": "采纳率" },
      { "num": "16", "label": "沉淀规律" }
    ]
  }
}
```

### 4.2 中风险 — 安全指数 68、执行率 67%

```json
{
  "safety": { "score": 68, "level": "mid" },
  "aiConclusions": [
    { "cls": "ok", "segments": [
      { "text": "今日建议投喂 ", "strong": false },
      { "text": "42 kg", "strong": true },
      { "text": "（早 07:00 14 / 晚 17:00 28）", "strong": false }
    ] },
    { "cls": "warn", "segments": [
      { "text": "今夜跌破临界 ", "strong": false },
      { "text": "4.0", "strong": true },
      { "text": "，建议 ", "strong": false },
      { "text": "00:30", "strong": true },
      { "text": " 开增氧机", "strong": false }
    ] },
    { "cls": "danger", "segments": [
      { "text": "亚盐略偏高，建议午后微流水（无需换水）", "strong": false }
    ] }
  ],
  "feed": {
    "adjust": -10,
    "data": [
      { "label": "水温", "val": "26.4", "unit": "℃", "note": "代谢偏快", "infer": "→ 减量防积食", "cls": "warn" },
      { "label": "溶氧谷值", "val": "3.2", "unit": "mg/L", "note": "昨夜偏低", "infer": "→ 减料降耗氧", "cls": "warn" },
      { "label": "氨氮", "val": "0.18", "unit": "mg/L", "note": "偏高", "infer": "→ 减料降排泄", "cls": "bad" }
    ],
    "ai": {
      "summary": [
        { "text": "水温 " }, { "text": "26.4℃", "strong": true },
        { "text": " 代谢偏快、氨氮 " }, { "text": "0.18", "strong": true },
        { "text": " 偏高、夜间溶氧 " }, { "text": "3.2", "strong": true },
        { "text": " 偏低 → 建议较昨日 " }, { "text": "减少投喂 10%", "strong": true },
        { "text": "，降低代谢负担与夜间耗氧压力。" }
      ],
      "detail": [
        { "text": "今日三项指标均出现警示：水温 " }, { "text": "26.4℃", "strong": true },
        { "text": " 代谢偏快、氨氮 " }, { "text": "0.18 mg/L", "strong": true },
        { "text": " 接近预警线且连续多日爬升、溶氧谷值 " }, { "text": "3.2", "strong": true },
        { "text": " 昨夜已跌破临界，说明当前投喂量超出水体承载能力 → 建议 " }, { "text": "减少投喂 10%", "strong": true },
        { "text": "（42 kg，早 07:00 投 14 kg / 晚 17:00 投 28 kg）。减量后观察明日氨氮，若回落至 0.15 以下可逐步恢复。" }
      ]
    }
  },
  "oxy": {
    "tag": { "text": "临界注意", "cls": "warn" },
    "critical": 4.0,
    "cols": [
      { "label": "临界值", "val": "4.0", "unit": "mg/L", "cls": "warn" },
      { "label": "跌破时间", "val": "22:00", "unit": "", "cls": "danger" },
      { "label": "最低溶氧", "val": "2.8", "unit": "mg/L", "cls": "danger" }
    ],
    "chart": {
      "data": [3.9, 3.6, 3.4, 3.2, 3.0, 2.9, 2.8, 3.0, 3.3, 3.8, 4.5, 5.3, 6.1, 6.9, 7.5, 8.0, 8.0, 7.6, 7.0, 6.3, 5.6, 4.9, 4.2, 3.5, 2.9],
      "labels": ["00:00", "06:00", "12:00", "18:00", "24:00"],
      "min": 2.0,
      "max": 8.0,
      "critical": 4.0
    },
    "aeroPlan": { "start": "00:30", "end": "06:00", "hours": "5.5 小时" },
    "ai": {
      "summary": [
        { "text": "今夜 " }, { "text": "22:00", "strong": true },
        { "text": " 起溶氧跌破临界 " }, { "text": "4.0", "strong": true },
        { "text": "，凌晨 " }, { "text": "02:00", "strong": true },
        { "text": " 前后最低 " }, { "text": "2.8", "strong": true },
        { "text": "，需增氧干预；昨日同方案执行后谷值回升至 " }, { "text": "4.2", "strong": true },
        { "text": "，今日维持 " }, { "text": "00:30", "strong": true },
        { "text": " 开启增氧机至日出。" }
      ],
      "detail": [
        { "text": "溶氧自昨夜 " }, { "text": "22:00", "strong": true },
        { "text": " 起跌破临界 " }, { "text": "4.0 mg/L", "strong": true },
        { "text": "，凌晨 " }, { "text": "02:00", "strong": true },
        { "text": " 最低 " }, { "text": "2.8", "strong": true },
        { "text": "，持续约 8 小时缺氧。昨日提前增氧方案执行后谷值回升至 " }, { "text": "4.2", "strong": true },
        { "text": "，方案验证有效。今日维持 " }, { "text": "00:30", "strong": true },
        { "text": " 开启增氧机至 " }, { "text": "06:00", "strong": true },
        { "text": "（约 5.5 小时），期间若 03:00 前溶氧仍低于 3.0 需加大增氧功率。" }
      ]
    }
  },
  "wq": {
    "tag": { "text": "氨氮偏高", "cls": "warn" },
    "data": [
      { "label": "pH", "val": "7.8", "unit": "", "note": "稳定", "infer": "→ 无碍", "cls": "good" },
      { "label": "溶氧", "val": "6.8", "unit": "mg/L", "note": "回升", "infer": "→ 好转", "cls": "good" },
      { "label": "水温", "val": "26.4", "unit": "℃", "note": "适宜", "infer": "→ 无碍", "cls": "good" },
      { "label": "氨氮", "val": "0.22", "unit": "mg/L", "note": "偏高", "infer": "→ 减料+微流水", "cls": "bad" }
    ],
    "ai": {
      "summary": [
        { "text": "pH、溶氧、水温均正常，仅氨氮连续 5 日爬升（" },
        { "text": "0.06→0.22", "strong": true },
        { "text": "）逼近预警线 → 建议今日" },
        { "text": "减少投喂 10%", "strong": true },
        { "text": "、" },
        { "text": "午后微流水 2 小时", "strong": true },
        { "text": "，预计明日氨氮回落至 0.15 以下。" }
      ],
      "detail": [
        { "text": "昨日三项实测指标正常，仅氨氮 " }, { "text": "0.22 mg/L", "strong": true },
        { "text": " 超过预警线，且近 5 日持续爬升（0.06→0.08→0.12→0.18→0.22），上升斜率加快，若不干预 2-3 天内将逼近 0.3 危险区间。建议今日 " }, { "text": "减少投喂 10%", "strong": true },
        { "text": " 降低氮输入 + " }, { "text": "午后微流水 2 小时", "strong": true },
        { "text": " 促进氨氮硝化，预计明日回落至 0.15 以下。" }
      ]
    }
  },
  "review": {
    "rate": 67,
    "level": "mid",
    "done": 2,
    "items": [
      { "name": "增氧机", "state": "已执行", "status": "done", "impact": "溶氧 3.2→4.2", "tag": "有效", "tagType": "good" },
      { "name": "晚间减料", "state": "部分执行", "status": "half", "impact": "实际减 12%", "tag": "未达标", "tagType": "half" },
      { "name": "午后微流水", "state": "未执行", "status": "no", "impact": "亚盐 0.18", "tag": "偏高", "tagType": "bad" }
    ],
    "ai": {
      "summary": [
        { "text": "增氧方案有效（溶氧 3.2→4.2）今日延续；微流水未执行致亚盐偏高，今日补足 2 小时；减料执行过重需校准" }
      ],
      "detail": [
        { "text": "昨日 3 条建议执行 2 条：增氧执行后溶氧 " }, { "text": "3.2→4.2", "strong": true },
        { "text": " 脱离临界线、方案有效；减料实际减 12% 略超建议值，今日校准至 10%；微流水未执行致亚盐 " }, { "text": "0.18", "strong": true },
        { "text": "、氨氮维持高位，今日务必补足 2 小时。" }
      ]
    }
  },
  "profile": {
    "stats": [
      { "num": "68", "label": "分析天数" },
      { "num": "86", "label": "累计建议" },
      { "num": "78%", "label": "采纳率" },
      { "num": "16", "label": "沉淀规律" }
    ]
  }
}
```

### 4.3 高风险 — 安全指数 42、执行率 33%

```json
{
  "safety": { "score": 42, "level": "high" },
  "aiConclusions": [
    { "cls": "danger", "segments": [
      { "text": "今日建议投喂 ", "strong": false },
      { "text": "28 kg", "strong": true },
      { "text": "（较昨日 -25%，仅早 07:00 一顿）", "strong": false }
    ] },
    { "cls": "danger", "segments": [
      { "text": "今夜 " }, { "text": "19:30", "strong": true },
      { "text": " 即跌破临界，请立即开增氧机", "strong": false }
    ] },
    { "cls": "danger", "segments": [
      { "text": "氨氮 " }, { "text": "0.45", "strong": true },
      { "text": " 严重超标，今日停料并开足增氧", "strong": false }
    ] }
  ],
  "feed": {
    "adjust": -25,
    "data": [
      { "label": "水温", "val": "28.9", "unit": "℃", "note": "过高", "infer": "→ 必须减量", "cls": "bad" },
      { "label": "溶氧谷值", "val": "1.8", "unit": "mg/L", "note": "严重偏低", "infer": "→ 停料降耗氧", "cls": "bad" },
      { "label": "氨氮", "val": "0.45", "unit": "mg/L", "note": "超标", "infer": "→ 紧急减料", "cls": "bad" }
    ],
    "ai": {
      "summary": [
        { "text": "水温 " }, { "text": "28.9℃", "strong": true },
        { "text": " 过高、溶氧谷值 " }, { "text": "1.8", "strong": true },
        { "text": " 严重偏低、氨氮 " }, { "text": "0.45", "strong": true },
        { "text": " 超标 → 今日必须 " }, { "text": "减少投喂 25%", "strong": true },
        { "text": "，并配合增氧缓解应激，否则有浮头风险。" }
      ],
      "detail": [
        { "text": "今日三项指标全部亮红灯：水温 " }, { "text": "28.9℃", "strong": true },
        { "text": " 超耐受上限、溶氧谷值 " }, { "text": "1.8", "strong": true },
        { "text": " 达浮头风险线、氨氮 " }, { "text": "0.45", "strong": true },
        { "text": " 超预警线 2 倍，高温 + 缺氧 + 高氨氮叠加，随时可能浮头 → 必须 " }, { "text": "减少投喂 25%", "strong": true },
        { "text": "（28 kg，仅早 07:00 一顿），全天开足增氧，午后视情况换水 1/3，风险解除前严禁加量。" }
      ]
    }
  },
  "oxy": {
    "tag": { "text": "严重缺氧", "cls": "danger" },
    "critical": 4.0,
    "cols": [
      { "label": "临界值", "val": "4.0", "unit": "mg/L", "cls": "warn" },
      { "label": "跌破时间", "val": "19:30", "unit": "", "cls": "danger" },
      { "label": "最低溶氧", "val": "1.8", "unit": "mg/L", "cls": "danger" }
    ],
    "chart": {
      "data": [2.6, 2.3, 2.0, 1.8, 1.9, 2.2, 2.8, 3.5, 4.3, 5.2, 6.1, 6.9, 7.4, 7.7, 7.6, 7.0, 6.2, 5.3, 4.5, 3.8, 3.2, 2.7, 2.4, 2.2, 2.0],
      "labels": ["00:00", "06:00", "12:00", "18:00", "24:00"],
      "min": 2.0,
      "max": 8.0,
      "critical": 4.0
    },
    "aeroPlan": { "start": "19:30", "end": "07:30", "hours": "12 小时" },
    "ai": {
      "summary": [
        { "text": "今夜 " }, { "text": "19:30", "strong": true },
        { "text": " 即跌破临界 " }, { "text": "4.0", "strong": true },
        { "text": "，凌晨最低 " }, { "text": "1.8", "strong": true },
        { "text": " 达 " }, { "text": "浮头风险线", "strong": true },
        { "text": "，必须 " }, { "text": "19:30 起全程增氧", "strong": true },
        { "text": "至次日 07:30，并减少投喂降低夜间耗氧。" }
      ],
      "detail": [
        { "text": "溶氧自昨夜 " }, { "text": "19:30", "strong": true },
        { "text": " 即跌破临界 " }, { "text": "4.0 mg/L", "strong": true },
        { "text": "，凌晨最低 " }, { "text": "1.8", "strong": true },
        { "text": " 达浮头风险线，约 10 小时处于临界值以下，连续多日创新低 → 必须 " }, { "text": "19:30 起全程增氧至 07:30", "strong": true },
        { "text": "（约 12 小时），期间不得停机，并减少投喂降低夜间耗氧；若 22:00 前溶氧未回升至 4.0 需考虑换水配合。" }
      ]
    }
  },
  "wq": {
    "tag": { "text": "多项超标", "cls": "danger" },
    "data": [
      { "label": "pH", "val": "9.1", "unit": "", "note": "偏高", "infer": "→ 需换水调节", "cls": "bad" },
      { "label": "溶氧", "val": "3.6", "unit": "mg/L", "note": "偏低", "infer": "→ 加大增氧", "cls": "bad" },
      { "label": "水温", "val": "28.9", "unit": "℃", "note": "过高", "infer": "→ 注意降温", "cls": "bad" },
      { "label": "氨氮", "val": "0.45", "unit": "mg/L", "note": "超标", "infer": "→ 停料+换水", "cls": "bad" }
    ],
    "ai": {
      "summary": [
        { "text": "四项指标全部异常：pH " }, { "text": "9.1", "strong": true },
        { "text": " 偏高、溶氧 " }, { "text": "3.6", "strong": true },
        { "text": " 偏低、水温 " }, { "text": "28.9℃", "strong": true },
        { "text": " 过高、氨氮 " }, { "text": "0.45", "strong": true },
        { "text": " 超标 → 今日停料、换水 1/3 并开足增氧，务必优先处理氨氮。" }
      ],
      "detail": [
        { "text": "昨日四项实测指标全部异常：pH " }, { "text": "9.1", "strong": true },
        { "text": " 碱化、溶氧 " }, { "text": "3.6", "strong": true },
        { "text": " 缺氧、水温 " }, { "text": "28.9℃", "strong": true },
        { "text": " 过高、氨氮 " }, { "text": "0.45", "strong": true },
        { "text": " 超预警线 2 倍，四项同时恶化说明水体已进入恶性循环。今日：① " }, { "text": "立即停料", "strong": true },
        { "text": " 切断氮输入；② " }, { "text": "换水 1/3", "strong": true },
        { "text": " 稀释氨氮降水温；③ " }, { "text": "全天开足增氧", "strong": true },
        { "text": " 维持溶氧 4.0 以上为硝化菌提供条件。处理顺序：先增氧、后换水、再观察。" }
      ]
    }
  },
  "review": {
    "rate": 33,
    "level": "high",
    "done": 1,
    "items": [
      { "name": "增氧机", "state": "未执行", "status": "no", "impact": "溶氧 1.8", "tag": "恶化", "tagType": "bad" },
      { "name": "晚间减料", "state": "未执行", "status": "no", "impact": "仍减 25%", "tag": "未达标", "tagType": "bad" },
      { "name": "午后微流水", "state": "已执行", "status": "done", "impact": "氨氮 0.55→0.45", "tag": "有效", "tagType": "good" }
    ],
    "ai": {
      "summary": [
        { "text": "增氧与减料未执行导致溶氧继续恶化（1.8）、氨氮高位（0.45），今日务必全部执行并配合换水" }
      ],
      "detail": [
        { "text": "昨日 3 条建议仅执行 1 条（执行率 33%）：增氧机与晚间减料未执行，夜间溶氧最低降至 " }, { "text": "1.8 mg/L", "strong": true },
        { "text": "、氨氮维持 " }, { "text": "0.45 mg/L", "strong": true },
        { "text": " 高位，指标继续恶化；微流水已执行，氨氮由 " }, { "text": "0.55→0.45", "strong": true },
        { "text": " 验证了降解效果，但单靠一项不足以扭转。今日必须三条全部执行并视情况换水 1/3，否则明日将进一步恶化。" }
      ]
    }
  },
  "profile": {
    "stats": [
      { "num": "45", "label": "分析天数" },
      { "num": "52", "label": "累计建议" },
      { "num": "42%", "label": "采纳率" },
      { "num": "9", "label": "沉淀规律" }
    ]
  }
}
```

---

## 5. 返回数据注意事项

- 状态/等级字段（`level` / `cls` / `status` / `tagType`）**只填枚举值**，不要返回颜色、图标等样式信息。
- 所有 `segments` 片段必须是 `{ text, strong }` 结构；`ai` 必须是 `{ summary, detail }` 结构（见 2.3）。
- 其余一切前端相关的内容无需关心。

## 7. 数据来源说明（后端实现视角）

首页接口 `/ai/analysis/home-page` 的数据分**两个来源**，互不依赖：

### 7.1 直接读取：AI 分析结果（落库）

AI 分析（`/ai/analysis/run` 或定时任务）把当日结论 JSON 存入主表 `y_daily_analysis_result.analysis_output`。
首页先读取**最新一条**分析结果并解析为 `YAiOutput`，以下字段全部来自 AI 落库（无 AI 结果则整页返回 `null`）：

| 模块 | 来自 AI 的字段 | 说明 |
|---|---|---|
| `safety` | `score` / `level` | 缺失时按风险等级/可信度兜底推导 |
| `aiConclusions` | 3 条结论文案 | 不足 3 条时兜底拼接补齐 |
| `feed` | `adjust`（投喂增减%）、`data[]`（label/val/unit/note/infer/cls）、`ai` | **指标卡含数值，全部 AI 生成** |
| `oxy` | `tag`、`cols`（label/val/unit/cls）、`aeroPlan`、`ai` | 溶氧状态与增氧方案文案 |
| `wq` | `tag`、`data[]`（label/val/unit/note/infer/cls）、`ai` | **指标卡含数值，全部 AI 生成** |
| `review` | `items` 执行状态、`ai` | 首次分析时兜底占位 |

> `feed.data` / `wq.data` 的指标（含数值）是 **AI 在分析过程中总结的"昨日指标"**，非实时数据；
> 指标自选、数量不限，符合格式即可，不限于水温/pH/溶氧/氨氮；`val` 为纯数值、`unit` 单独返回。
> **约束**：后端会按塘口设备真实上报的属性过滤，未安装的传感器指标（如无氨氮传感器时的"氨氮/亚硝酸盐"）不会返回。

### 7.2 单独查询：实时指标（不走 AI）

每次打开首页时**实时查询**的只有以下几项（其余全部来自 AI 落库）：

| 数据 | 存储 | 查询方式 |
|---|---|---|
| 24h 溶氧曲线（25 点） | TDengine | **昨天 0 点 ~ 今天 0 点** 原始点按小时分桶平均（多设备取平均） |
| 溶氧临界值等固定参数 | MySQL | 塘口固定参数表 |
| 投喂增减量基准（昨日投喂量） | MySQL | 昨日分析结果记录 |
| `profile` 画像统计（分析天数/采纳率/规律数） | MySQL | 分析结果/规律库/习惯库 count |

> feed/wq 的日聚合查询仅在 AI 未输出指标时作为兜底使用（默认 3~4 项，回退窗口 3 天）。

### 7.3 为什么这样划分

- **需要 AI 生成的内容**（建议、结论、标签文案、指标数值）→ 直接读 `analysis_output`，不重复计算
- **需要实时准确的值**（昨日 24h 溶氧曲线、画像统计、临界值）→ 单独查库，不依赖 AI 分析时点的历史快照。AI 分析用的 24 小时数据序列只是给 AI 看的输入，不直接用于首页展示

## 6. 拼接自查清单

- [ ] `safety.score` 是 0-100 整数；`safety.level` 只能填 `low`/`mid`/`high`
- [ ] `aiConclusions` 固定 3 条，顺序依次为 饲喂建议 / 溶氧建议 / 水质研判；`cls` 只能填 `ok`/`warn`/`danger`
- [ ] `feed.data` 固定 3 项（水温/溶氧谷值/氨氮），`cls` 只能填 `good`/`warn`/`bad`
- [ ] `oxy.chart.data` 恰好 25 个数（0~24 时），`chart.critical` 与 `oxy.critical` 一致
- [ ] `oxy.cols` 数量不限（每项含 `label`/`val`/`unit`/`cls`），须是 `ai` 建议依据的指标；`cls` 只能填 `good`/`warn`/`danger`
- [ ] `wq.data` 数量不限（AI 自选指标，含 `label`/`val`/`unit`/`note`/`infer`/`cls`），`cls` 只能填 `good`/`bad`
- [ ] `review.rate` 是 0-100 整数，`level` 只能填 `low`/`mid`/`high`；`done` ≤ `items.length`；`items[].status` 只能填 `done`/`half`/`no`；`items[].tagType` 只能填 `good`/`half`/`bad`
- [ ] `profile.stats` 固定 4 项
- [ ] 每个 `ai`（`feed` / `oxy` / `wq` / `review`）都是 `{ summary, detail }`：`summary` 概要 2-3 行、`detail` 完整分析 ≤500 字；片段均为 `{ text, strong }` 对象
