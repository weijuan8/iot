# 智嵌物联 GE100D 串口服务器 — Modbus-RTU 透传架构设计文档

> **版本**: v1.0  
> **日期**: 2025-07-15  
> **适用场景**: GE100D 网关（透传模式）+ EMQX Broker + Enjoy-IoT 平台  
> **核心思路**: EMQX 和 GE100D 只做数据透明传输，不做任何协议解析和校验。所有 Modbus 协议的拼接、解析、物模型映射由 Java 服务端完成。

---

## 目录

1. [整体架构概览](#1-整体架构概览)
2. [MQTT Topic 设计](#2-mqtt-topic-设计)
3. [设备注册与校验方案](#3-设备注册与校验方案)
4. [Modbus 协议帧设计](#4-modbus-协议帧设计)
5. [物模型设计](#5-物模型设计)
6. [Modbus 帧拼接与解析引擎](#6-modbus-帧拼接与解析引擎)
7. [透传组件实现方案](#7-透传组件实现方案)
8. [数据库表设计](#8-数据库表设计)
9. [配置示例](#9-配置示例)
10. [其他关键设计要点](#10-其他关键设计要点)

---

## 1. 整体架构概览

### 1.1 物理拓扑

```
┌──────────────────────────────────────────────────────────────────────┐
│                          Enjoy-IoT 平台 (Java Server)                 │
│                                                                       │
│  ┌──────────────────────────────────────────────────────────────┐    │
│  │  ge100d-transparent 组件 (新开发)                              │    │
│  │  ┌──────────────┐  ┌────────────────┐  ┌──────────────────┐  │    │
│  │  │ ModbusEncoder │  │ ModbusDecoder  │  │ ThingModelMapper │  │    │
│  │  │ (帧拼接引擎)   │  │ (帧解析引擎)    │  │ (物模型映射)      │  │    │
│  │  └──────────────┘  └────────────────┘  └──────────────────┘  │    │
│  └──────────────────────────────────────────────────────────────┘    │
│       ▲ MQTT (上行)            │ MQTT (下行)                          │
└───────┼────────────────────────┼──────────────────────────────────────┘
        │                        │
   ┌────┴────────────────────────▼────────────────────┐
   │                  EMQX Broker                      │
   │            (仅做 MQTT 消息路由，不解析内容)          │
   │     Topic 转发: ge100d/{pk}/{dn}/up               │
   │               ge100d/{pk}/{dn}/down               │
   └────────────────────┬──────────────────────────────┘
                        │ MQTT (TCP/SSL)
   ┌────────────────────▼──────────────────────────────┐
   │           GE100D 串口服务器 (透传模式)               │
   │                                                    │
   │  ┌──────────────────────────────────────────────┐ │
   │  │  配置: 透传模式 (Transparent Transmission)     │ │
   │  │  - 不解析 Modbus 帧                            │ │
   │  │  - 串口数据 → MQTT 直接转发 (二进制)             │ │
   │  │  - MQTT 消息 → 串口直接转发 (二进制)             │ │
   │  └──────────────────────────────────────────────┘ │
   │                                                    │
   │   RS-485 串口 ───┬──────┬──────┬──────             │
   └──────────────────┼──────┼──────┼───────────────────┘
                      │      │      │
              ┌───────▼┐ ┌───▼──┐ ┌─▼──────┐
              │ 温湿度  │ │ 电表  │ │ 继电器  │  ...
              │ 传感器  │ │      │ │ 控制器  │
              │(Addr=1) │ │(Addr=2)│ │(Addr=3)│
              └─────────┘ └──────┘ └────────┘
```

### 1.2 数据流向

```
【上行 - 设备上报】
  Modbus 从机 → RS-485 → GE100D(透传) → MQTT(二进制) → EMQX
    → ge100d-transparent 组件 → ModbusDecoder 解析帧
      → ThingModelMapper 映射为 ThingModelMessage
        → report() 上报平台消息队列 → 规则引擎处理

【下行 - 平台控制】
  平台 Controller → DeviceCtrlServiceImpl.send()
    → ComponentManager.sendToDevice() → {type}_device_thing topic
      → ge100d-transparent 组件 onMessage()
        → ThingModelMapper 转换为 Modbus 指令
          → ModbusEncoder 拼接帧
            → MQTT(二进制) → EMQX → GE100D(透传)
              → RS-485 → Modbus 从机
```

### 1.3 与现有架构的集成点

```
继承链:
  Component (接口)
    → AbstractComponent (消息路由 + 组件发现)
      → ThingComponent (配置轮询 + 物模型消息分发)
        → Ge100dTransparentComponent (新增 - 本方案核心)
```

利用现有基础设施：
- **组件发现**: `publishDiscover()` 自动注册到 ComponentManager
- **消息路由**: `sendMessage()` / `handler()` Redis 路由机制
- **下行指令**: `onMessage()` → `serviceInvoke()` / `propertySet()` / `propertyGet()`
- **上行上报**: `report()` → 规则引擎链

---

## 2. MQTT Topic 设计

### 2.1 Topic 命名规范

由于 GE100D 工作在透传模式，MQTT 消息体中承载的是**二进制 Modbus 帧**，Topic 只用于标识设备和方向。

```
上行 Topic（设备 → 平台）:
  ge100d/{productKey}/{deviceName}/up

下行 Topic（平台 → 设备）:
  ge100d/{productKey}/{deviceName}/down

系统 Topic:
  ge100d/{productKey}/{deviceName}/status    # 网关上下线通知
```

**Topic 设计原则**：

| 原则 | 说明 |
|------|------|
| **前缀隔离** | 使用 `ge100d/` 前缀，与现有 `/sys/` 前缀区分，避免与 EMQX 组件消息混淆 |
| **设备标识** | `{productKey}/{deviceName}` 沿用平台设备标识规范 |
| **方向区分** | `/up` 和 `/down` 简洁明确，比 `/s/` `/c/` 更直观 |
| **避免通配符冲突** | 新组件只订阅 `ge100d/+/+/up` 和 `ge100d/+/+/status` |

### 2.2 EMQX 侧配置

EMQX 不需要做任何数据解析，只需配置 ACL 规则：

```hocon
# EMQX ACL 配置 - 允许 GE100D 网关发布/订阅透传 Topic
## GE100D 网关可以发布上行消息和状态
{allow, {username, "ge100d_*"}, publish, ["ge100d/${username}/up", "ge100d/${username}/status"]}

## GE100D 网关可以订阅下行消息
{allow, {username, "ge100d_*"}, subscribe, ["ge100d/${username}/down"]}

## 平台服务端可以发布下行消息和订阅上行消息
{allow, {username, "server"}, publish, ["ge100d/+/+/down"]}
{allow, {username, "server"}, subscribe, ["ge100d/+/+/up", "ge100d/+/+/status"]}
```

### 2.3 服务端订阅 Topic

新组件在启动时订阅：

```java
// 订阅所有 GE100D 设备的上行消息
String[] topics = {
    "ge100d/+/+/up",      // 上行 Modbus 数据
    "ge100d/+/+/status"   // 网关状态
};
```

### 2.4 MQTT 消息格式

透传模式下，MQTT Payload 为**纯二进制**（Modbus 原始帧）：

```
上行消息（设备上报的 Modbus 响应帧）:
  QoS: 1 (至少一次)
  Payload: byte[] Modbus 响应帧
  示例: [0x01, 0x03, 0x04, 0x00, 0x5A, 0x00, 0x00, 0xXX, 0xXX]  (CRC 校验码)

下行消息（平台下发的 Modbus 请求帧）:
  QoS: 1
  Payload: byte[] Modbus 请求帧
  示例: [0x01, 0x03, 0x00, 0x00, 0x00, 0x02, 0xXX, 0xXX]  (CRC 校验码)
```

**关键点**：
- 透传模式下 GE100D **不关心** payload 内容，只做串口↔MQTT 的字节流映射
- Modbus 帧的 CRC 校验由**平台 Java 端**计算和验证
- 异常帧的识别、重试、超时全部由**平台端**负责

---

## 3. 设备注册与校验方案

### 3.1 核心问题分析

GE100D 在透传模式下**不支持**主动的子设备（Modbus 从机）注册，因为：
- 透传模式下 GE100D 不解析 Modbus 协议，不知道 RS-485 总线上挂了多少设备
- GE100D 只维护一个 MQTT 连接，代表整个网关

### 3.2 解决方案：手动注册 + 自动发现辅助

采用 **"手动后台录入 + 首次通信自动激活"** 的混合方案：

```
阶段1：手动录入（管理员操作）
  ┌─────────────────────────────────────────────┐
  │  后台管理页面                                 │
  │  1. 添加产品: "GE100D网关" (nodeType=GATEWAY)  │
  │  2. 添加设备: "车间1号网关" (pk + dn + secret)  │
  │  3. 添加产品: "温湿度传感器" (nodeType=DEVICE)   │
  │  4. 批量导入子设备:                              │
  │     - 温湿度传感器-1 (slaveAddr=1)               │
  │     - 电表-1 (slaveAddr=2)                      │
  │     - 继电器-1 (slaveAddr=3)                    │
  │     parentId 指向 "车间1号网关"                   │
  └─────────────────────────────────────────────┘

阶段2：自动激活（设备首次通信）
  1. GE100D 网关通过 MQTT 连接 EMQX（携带 pk/dn 作为 clientId）
  2. 网关发送上线消息到 ge100d/{pk}/{dn}/status
  3. 平台收到 → 将网关状态标记为 ONLINE
  4. 网关开始转发 Modbus 帧
  5. 平台解析到某 slaveAddr 的响应帧
     → 查找该网关下 slaveAddr 对应的子设备
       → 找到 → 子设备状态标记为 ONLINE
       → 未找到 → 记录告警日志（可选：自动创建未知设备）
```

### 3.3 后台管理界面设计

```
设备管理 → 产品管理
  ├── 新增产品 "GE100D网关"  (节点类型: 网关设备, 协议: ge100d-transparent)
  ├── 新增产品 "Modbus温湿度传感器" (节点类型: 子设备)
  ├── 新增产品 "Modbus电表" (节点类型: 子设备)
  └── 新增产品 "Modbus继电器" (节点类型: 子设备)

设备管理 → 设备列表
  ├── [网关] 车间1号网关 (pk=prod_ge100d, dn=gateway_01)
  │   ├── [子设备] 温湿度传感器-1 (slaveAddr=1, 寄存器映射配置)
  │   ├── [子设备] 电表-1 (slaveAddr=2, 寄存器映射配置)
  │   └── [子设备] 继电器-1 (slaveAddr=3, 寄存器映射配置)
  └── [网关] 车间2号网关 (pk=prod_ge100d, dn=gateway_02)
      └── ...
```

### 3.4 设备扩展属性（DeviceInfo 新增字段）

在 `DeviceInfo` 或子设备配置表中增加 Modbus 特有属性：

```json
{
  "deviceId": 1001,
  "productKey": "prod_sensor_temp",
  "dn": "temp_01",
  "parentId": 1000,
  "nodeType": "DEVICE",
  "extension": {
    "modbus": {
      "slaveAddr": 1,          // Modbus 从机地址 (1-247)
      "registerMap": [
        {
          "name": "temperature",
          "registerType": "HOLDING_REGISTER",
          "startAddr": 0,
          "quantity": 1,
          "dataType": "INT16",
          "scale": 0.1,
          "unit": "°C"
        },
        {
          "name": "humidity",
          "registerType": "HOLDING_REGISTER",
          "startAddr": 1,
          "quantity": 1,
          "dataType": "UINT16",
          "scale": 0.1,
          "unit": "%RH"
        }
      ],
      "pollInterval": 5000    // 轮询间隔 (ms)
    }
  }
}
```

### 3.5 设备认证

GE100D 网关的 MQTT 连接认证：

```java
// clientId 格式: {productKey}_{deviceName}
// 例如: prod_ge100d_gateway_01

// EMQX HTTP 认证回调 → AuthVerticle
// deviceApi.auth() 验证:
//   - productKey + deviceName 是否存在
//   - secret 是否匹配
//   - deviceInfo.nodeType == GATEWAY
//   - deviceInfo.state != DISABLED

// 认证通过后:
//   1. 记录 clientId → (pk, dn) 映射到 CLIENT_DEVICE_MAP
//   2. 缓存设备路由到 Redis
//   3. 发送设备上线通知
```

---

## 4. Modbus 协议帧设计

### 4.1 Modbus-RTU 帧结构

```
┌─────────┬─────────┬───────────┬─────────┬───────────┐
│ 地址域   │ 功能码   │  数据域    │ CRC低   │  CRC高    │
│ 1 byte  │ 1 byte  │ N bytes   │ 1 byte  │  1 byte   │
└─────────┴─────────┴───────────┴─────────┴───────────┘
```

### 4.2 支持的 Modbus 功能码

| 功能码 | 名称 | 用途 | 示例场景 |
|--------|------|------|----------|
| 0x01 | 读线圈 | 读取开关量输出 | 读取继电器状态 |
| 0x02 | 读离散输入 | 读取开关量输入 | 读取按钮/传感器数字量 |
| 0x03 | 读保持寄存器 | 读取模拟量 | **读取温度/湿度/电压等** |
| 0x04 | 读输入寄存器 | 读取模拟输入 | 读取 ADC 采样值 |
| 0x05 | 写单线圈 | 控制单个开关 | 控制单个继电器开/关 |
| 0x06 | 写单寄存器 | 写入单个参数 | 设置阈值/配置参数 |
| 0x0F | 写多线圈 | 批量控制开关 | 批量控制多个继电器 |
| 0x10 | 写多寄存器 | 批量写入参数 | 批量配置设备参数 |

### 4.3 常见 Modbus 帧示例

#### 读取保持寄存器 (0x03)

```
请求帧:
  [0x01] [0x03] [0x00, 0x00] [0x00, 0x02] [0xC4, 0x0B]
   ↑从机1  ↑功能码 ↑起始地址0  ↑读取2个寄存器 ↑CRC校验

响应帧:
  [0x01] [0x03] [0x04] [0x00, 0x5A] [0x00, 0x46] [0xXX, 0xXX]
   ↑从机1  ↑功能码 ↑4字节 ↑寄存器0=90 ↑寄存器1=70  ↑CRC校验
```

#### 写单寄存器 (0x06)

```
请求帧:
  [0x01] [0x06] [0x00, 0x10] [0x00, 0x01] [0xXX, 0xXX]
   ↑从机1  ↑功能码 ↑寄存器地址16 ↑写入值1      ↑CRC校验
```

#### 写单线圈 (0x05)

```
请求帧:
  [0x01] [0x05] [0x00, 0x00] [0xFF, 0x00] [0xXX, 0xXX]
   ↑从机1  ↑功能码 ↑线圈地址0   ↑ON(FF00)/OFF(0000) ↑CRC
```

### 4.4 CRC-16 校验

```java
/**
 * Modbus CRC-16 校验算法
 */
public class ModbusCRC {
    
    /**
     * 计算 Modbus CRC-16
     * @param data 数据字节数组（不含 CRC 的两字节）
     * @return 16 位 CRC 值（低字节在前）
     */
    public static int calculate(byte[] data) {
        int crc = 0xFFFF;
        for (byte b : data) {
            crc ^= (b & 0xFF);
            for (int i = 0; i < 8; i++) {
                if ((crc & 0x0001) != 0) {
                    crc = (crc >> 1) ^ 0xA001;
                } else {
                    crc = crc >> 1;
                }
            }
        }
        return crc;
    }
    
    /**
     * 验证 CRC 校验
     * @param frame 完整的 Modbus 帧（包含末尾 2 字节 CRC）
     * @return true=校验通过
     */
    public static boolean validate(byte[] frame) {
        if (frame.length < 4) return false;
        int calculated = calculate(Arrays.copyOf(frame, frame.length - 2));
        int received = ((frame[frame.length - 1] & 0xFF) << 8) 
                     | (frame[frame.length - 2] & 0xFF);
        return calculated == received;
    }
    
    /**
     * 为数据帧追加 CRC 校验码
     * @param data 不含 CRC 的数据
     * @return 包含 CRC 的完整帧
     */
    public static byte[] appendCRC(byte[] data) {
        int crc = calculate(data);
        byte[] frame = new byte[data.length + 2];
        System.arraycopy(data, 0, frame, 0, data.length);
        frame[data.length] = (byte) (crc & 0xFF);         // CRC 低字节
        frame[data.length + 1] = (byte) ((crc >> 8) & 0xFF); // CRC 高字节
        return frame;
    }
}
```

---

## 5. 物模型设计

### 5.1 设计原则

透传模式下，Modbus 从机设备没有"智能"，不会主动上报数据。平台需要：
1. **周期性轮询**读取从机数据（属性上报）
2. **按需下发**控制指令（属性设置/服务调用）

物模型的核心作用是将 Modbus 寄存器映射为物联网平台的「属性」和「服务」。

### 5.2 物模型定义（JSON Schema）

为每种 Modbus 设备产品定义一个物模型 JSON：

```json
{
  "productKey": "prod_temp_humidity",
  "productName": "Modbus温湿度传感器",
  "model": "THS-100",
  "protocol": "modbus-rtu",
  
  "properties": [
    {
      "identifier": "temperature",
      "name": "温度",
      "dataType": "float",
      "unit": "°C",
      "access": "r",
      "modbus": {
        "slaveAddr": 1,
        "functionCode": 3,
        "registerType": "HOLDING_REGISTER",
        "startAddr": 0,
        "quantity": 1,
        "dataType": "INT16",
        "byteOrder": "AB",
        "scale": 0.1,
        "offset": 0
      }
    },
    {
      "identifier": "humidity",
      "name": "湿度",
      "dataType": "float",
      "unit": "%RH",
      "access": "r",
      "modbus": {
        "slaveAddr": 1,
        "functionCode": 3,
        "registerType": "HOLDING_REGISTER",
        "startAddr": 1,
        "quantity": 1,
        "dataType": "UINT16",
        "byteOrder": "AB",
        "scale": 0.1,
        "offset": 0
      }
    }
  ],
  
  "services": [
    {
      "identifier": "reboot",
      "name": "重启设备",
      "callType": "async",
      "modbus": {
        "slaveAddr": 1,
        "functionCode": 6,
        "startAddr": 100,
        "value": 1,
        "dataType": "UINT16"
      }
    }
  ],
  
  "polling": {
    "enabled": true,
    "interval": 5000,
    "batchRead": {
      "enabled": true,
      "groups": [
        {
          "startAddr": 0,
          "quantity": 2,
          "functionCode": 3,
          "properties": ["temperature", "humidity"]
        }
      ]
    }
  }
}
```

### 5.3 Modbus 数据类型映射

| Modbus 数据类型 | Java 类型 | 寄存器占用 | 说明 |
|----------------|-----------|-----------|------|
| INT16 | short | 1 个寄存器 | 有符号 16 位整数 |
| UINT16 | int | 1 个寄存器 | 无符号 16 位整数 |
| INT32 | int | 2 个寄存器 | 有符号 32 位整数 |
| UINT32 | long | 2 个寄存器 | 无符号 32 位整数 |
| FLOAT32 | float | 2 个寄存器 | IEEE 754 单精度浮点数 |
| INT64 | long | 4 个寄存器 | 有符号 64 位整数 |
| STRING | String | N 个寄存器 | ASCII 字符串 |
| BITS | boolean[] | 1 个寄存器（16 位） | 位状态 |

### 5.4 字节序配置

```java
public enum ByteOrder {
    AB,  // 大端序 (Big-Endian): 高字节在前 [0x12, 0x34] → 0x1234
    BA,  // 小端序 (Little-Endian): 低字节在前 [0x34, 0x12] → 0x1234
    ABCD, // 双字大端: [0x12, 0x34, 0x56, 0x78] → 0x12345678
    CDAB, // 双字小端: [0x34, 0x12, 0x78, 0x56] → 0x12345678
    BADC, // 字内大端、字间小端
    DCBA  // 完全逆序
}
```

### 5.5 物模型 ↔ Modbus 映射关系图

```
物模型属性                 Modbus 寄存器                   物理量
────────────────────────────────────────────────────────────────
temperature (float)  ←→  HOLDING_REGISTER[0] (INT16)  →  温度传感器值
                           scale=0.1 → 寄存器值 * 0.1 = 实际°C

humidity (float)     ←→  HOLDING_REGISTER[1] (UINT16)  →  湿度传感器值
                           scale=0.1 → 寄存器值 * 0.1 = 实际%RH

switch1 (boolean)    ←→  COIL[0] (BIT)                 →  继电器1 开/关
switch2 (boolean)    ←→  COIL[1] (BIT)                 →  继电器2 开/关

voltage (float)      ←→  INPUT_REGISTER[0..1] (FLOAT32)→  电压值
                           AB 字节序 → 直接映射
```

---

## 6. Modbus 帧拼接与解析引擎

### 6.1 整体类设计

```
┌─────────────────────────────────────────────────────────────────┐
│  ModbusEngine (核心引擎)                                         │
│  ├── ModbusFrameBuilder (帧拼接器 - 下行)                         │
│  │   ├── buildReadHoldingRegisters(slaveAddr, startAddr, qty)   │
│  │   ├── buildWriteSingleRegister(slaveAddr, addr, value)       │
│  │   ├── buildWriteSingleCoil(slaveAddr, addr, state)           │
│  │   ├── buildWriteMultipleRegisters(slaveAddr, startAddr, vals)│
│  │   └── buildWriteMultipleCoils(slaveAddr, startAddr, states)  │
│  │                                                               │
│  ├── ModbusFrameParser (帧解析器 - 上行)                          │
│  │   ├── parse(byte[] frame) → ModbusFrame                      │
│  │   ├── validateCRC(byte[] frame) → boolean                    │
│  │   └── extractData(ModbusFrame, DataType) → Object            │
│  │                                                               │
│  ├── ModbusFrame (帧模型)                                        │
│  │   ├── slaveAddr, functionCode, data, crc                     │
│  │   ├── isException() → boolean                                │
│  │   └── getExceptionCode() → int                               │
│  │                                                               │
│  └── ThingModelMapper (物模型映射器)                              │
│      ├── propertyToModbusFrame(PropertySet) → byte[]            │
│      ├── propertyToModbusFrame(PropertyGet) → byte[]            │
│      ├── serviceToModbusFrame(ServiceInvoke) → byte[]           │
│      ├── modbusFrameToProperty(ModbusFrame, ThingModel) → Map   │
│      └── getPollingFrames(DeviceInfo) → List<byte[]>             │
└─────────────────────────────────────────────────────────────────┘
```

### 6.2 ModbusFrameBuilder（帧拼接器）

```java
/**
 * Modbus 帧拼接器
 * 负责将平台下行指令拼接为 Modbus-RTU 协议帧
 */
public class ModbusFrameBuilder {

    /**
     * 构建「读保持寄存器」请求帧
     * @param slaveAddr Modbus 从机地址 (1-247)
     * @param startAddr 起始寄存器地址
     * @param quantity  读取数量
     * @return Modbus 完整帧 (含 CRC)
     */
    public static byte[] buildReadHoldingRegisters(int slaveAddr, int startAddr, int quantity) {
        byte[] data = new byte[6];
        data[0] = (byte) slaveAddr;
        data[1] = 0x03;  // 功能码: 读保持寄存器
        data[2] = (byte) ((startAddr >> 8) & 0xFF);
        data[3] = (byte) (startAddr & 0xFF);
        data[4] = (byte) ((quantity >> 8) & 0xFF);
        data[5] = (byte) (quantity & 0xFF);
        return ModbusCRC.appendCRC(data);
    }

    /**
     * 构建「读输入寄存器」请求帧
     */
    public static byte[] buildReadInputRegisters(int slaveAddr, int startAddr, int quantity) {
        byte[] data = new byte[6];
        data[0] = (byte) slaveAddr;
        data[1] = 0x04;
        data[2] = (byte) ((startAddr >> 8) & 0xFF);
        data[3] = (byte) (startAddr & 0xFF);
        data[4] = (byte) ((quantity >> 8) & 0xFF);
        data[5] = (byte) (quantity & 0xFF);
        return ModbusCRC.appendCRC(data);
    }

    /**
     * 构建「读线圈」请求帧
     */
    public static byte[] buildReadCoils(int slaveAddr, int startAddr, int quantity) {
        byte[] data = new byte[6];
        data[0] = (byte) slaveAddr;
        data[1] = 0x01;
        data[2] = (byte) ((startAddr >> 8) & 0xFF);
        data[3] = (byte) (startAddr & 0xFF);
        data[4] = (byte) ((quantity >> 8) & 0xFF);
        data[5] = (byte) (quantity & 0xFF);
        return ModbusCRC.appendCRC(data);
    }

    /**
     * 构建「写单寄存器」请求帧
     * @param slaveAddr 从机地址
     * @param registerAddr 寄存器地址
     * @param value 写入值 (16 位)
     */
    public static byte[] buildWriteSingleRegister(int slaveAddr, int registerAddr, int value) {
        byte[] data = new byte[6];
        data[0] = (byte) slaveAddr;
        data[1] = 0x06;
        data[2] = (byte) ((registerAddr >> 8) & 0xFF);
        data[3] = (byte) (registerAddr & 0xFF);
        data[4] = (byte) ((value >> 8) & 0xFF);
        data[5] = (byte) (value & 0xFF);
        return ModbusCRC.appendCRC(data);
    }

    /**
     * 构建「写单线圈」请求帧
     * @param slaveAddr 从机地址
     * @param coilAddr  线圈地址
     * @param state     true=ON(0xFF00), false=OFF(0x0000)
     */
    public static byte[] buildWriteSingleCoil(int slaveAddr, int coilAddr, boolean state) {
        byte[] data = new byte[6];
        data[0] = (byte) slaveAddr;
        data[1] = 0x05;
        data[2] = (byte) ((coilAddr >> 8) & 0xFF);
        data[3] = (byte) (coilAddr & 0xFF);
        data[4] = state ? (byte) 0xFF : (byte) 0x00;
        data[5] = (byte) 0x00;
        return ModbusCRC.appendCRC(data);
    }

    /**
     * 构建「写多寄存器」请求帧
     * @param slaveAddr 从机地址
     * @param startAddr 起始寄存器地址
     * @param values    要写入的值数组（每个元素 16 位）
     */
    public static byte[] buildWriteMultipleRegisters(int slaveAddr, int startAddr, int[] values) {
        int byteCount = values.length * 2;
        byte[] data = new byte[7 + byteCount];
        data[0] = (byte) slaveAddr;
        data[1] = 0x10;
        data[2] = (byte) ((startAddr >> 8) & 0xFF);
        data[3] = (byte) (startAddr & 0xFF);
        data[4] = (byte) ((values.length >> 8) & 0xFF);
        data[5] = (byte) (values.length & 0xFF);
        data[6] = (byte) byteCount;
        for (int i = 0; i < values.length; i++) {
            data[7 + i * 2] = (byte) ((values[i] >> 8) & 0xFF);
            data[7 + i * 2 + 1] = (byte) (values[i] & 0xFF);
        }
        return ModbusCRC.appendCRC(data);
    }

    /**
     * 构建「写多线圈」请求帧
     */
    public static byte[] buildWriteMultipleCoils(int slaveAddr, int startAddr, boolean[] states) {
        int byteCount = (states.length + 7) / 8;
        byte[] data = new byte[7 + byteCount];
        data[0] = (byte) slaveAddr;
        data[1] = 0x0F;
        data[2] = (byte) ((startAddr >> 8) & 0xFF);
        data[3] = (byte) (startAddr & 0xFF);
        data[4] = (byte) ((states.length >> 8) & 0xFF);
        data[5] = (byte) (states.length & 0xFF);
        data[6] = (byte) byteCount;
        for (int i = 0; i < states.length; i++) {
            if (states[i]) {
                data[7 + i / 8] |= (byte) (1 << (i % 8));
            }
        }
        return ModbusCRC.appendCRC(data);
    }
}
```

### 6.3 ModbusFrameParser（帧解析器）

```java
/**
 * Modbus 帧解析器
 * 负责将 Modbus 响应帧解析为结构化数据
 */
public class ModbusFrameParser {

    /**
     * 解析 Modbus 响应帧
     * @param frame 完整的 Modbus 帧字节数组
     * @return ModbusFrame 对象，解析失败返回 null
     */
    public static ModbusFrame parse(byte[] frame) {
        if (frame == null || frame.length < 4) {
            return null;
        }
        // CRC 校验
        if (!ModbusCRC.validate(frame)) {
            log.warn("Modbus CRC check failed, frame discarded");
            return null;
        }

        ModbusFrame result = new ModbusFrame();
        result.setSlaveAddr(frame[0] & 0xFF);
        result.setFunctionCode(frame[1] & 0xFF);

        // 检查异常响应
        if ((result.getFunctionCode() & 0x80) != 0) {
            result.setException(true);
            result.setExceptionCode(frame[2] & 0xFF);
            return result;
        }

        // 提取数据域（去掉地址、功能码、CRC）
        byte[] data = new byte[frame.length - 4];
        System.arraycopy(frame, 2, data, 0, data.length);
        result.setData(data);

        return result;
    }

    /**
     * 从响应帧中提取寄存器值
     * @param frame    Modbus 响应帧
     * @param startAddr 起始地址（用于偏移计算）
     * @param registerConfig 寄存器配置
     * @return 解析后的物理量值
     */
    public static Object extractValue(ModbusFrame frame, int startAddr,
                                       RegisterConfig registerConfig) {
        byte[] data = frame.getData();
        if (data == null) return null;

        int funcCode = frame.getFunctionCode();
        int offset = 0;

        // 功能码 0x01/0x02 响应：1字节数据长度 + N字节位数据
        // 功能码 0x03/0x04 响应：1字节数据长度 + N*2字节寄存器数据
        if (funcCode == 0x01 || funcCode == 0x02) {
            offset = 1; // 跳过数据长度字节
            int byteIndex = (registerConfig.getStartAddr() - startAddr) / 8;
            int bitIndex = (registerConfig.getStartAddr() - startAddr) % 8;
            if (byteIndex + offset < data.length) {
                return ((data[offset + byteIndex] >> bitIndex) & 0x01) == 1;
            }
        } else if (funcCode == 0x03 || funcCode == 0x04) {
            offset = 1; // 跳过数据长度字节
            int byteOffset = (registerConfig.getStartAddr() - startAddr) * 2;
            return parseRegisterValue(data, offset + byteOffset,
                    registerConfig.getDataType(), registerConfig.getByteOrder(),
                    registerConfig.getScale(), registerConfig.getOffset());
        } else if (funcCode == 0x06) {
            // 写单寄存器响应，返回寄存器值
            return parseRegisterValue(data, 0,
                    registerConfig.getDataType(), registerConfig.getByteOrder(),
                    registerConfig.getScale(), registerConfig.getOffset());
        }

        return null;
    }

    /**
     * 将原始字节解析为指定类型的值
     */
    private static Object parseRegisterValue(byte[] data, int offset,
                                              DataType dataType, ByteOrder byteOrder,
                                              double scale, double offset_val) {
        switch (dataType) {
            case INT16: {
                short raw = (short) ((data[offset] << 8) | (data[offset + 1] & 0xFF));
                return raw * scale + offset_val;
            }
            case UINT16: {
                int raw = ((data[offset] & 0xFF) << 8) | (data[offset + 1] & 0xFF);
                return raw * scale + offset_val;
            }
            case INT32: {
                int raw = parseInt32(data, offset, byteOrder);
                return raw * scale + offset_val;
            }
            case UINT32: {
                long raw = parseUInt32(data, offset, byteOrder);
                return raw * scale + offset_val;
            }
            case FLOAT32: {
                int bits = parseInt32(data, offset, byteOrder);
                return Float.intBitsToFloat(bits) * scale + offset_val;
            }
            default:
                return null;
        }
    }

    private static int parseInt32(byte[] data, int offset, ByteOrder order) {
        byte b0 = data[offset], b1 = data[offset + 1];
        byte b2 = data[offset + 2], b3 = data[offset + 3];
        switch (order) {
            case ABCD: return ((b0 & 0xFF) << 24) | ((b1 & 0xFF) << 16) 
                            | ((b2 & 0xFF) << 8) | (b3 & 0xFF);
            case CDAB: return ((b2 & 0xFF) << 24) | ((b3 & 0xFF) << 16) 
                            | ((b0 & 0xFF) << 8) | (b1 & 0xFF);
            case BADC: return ((b1 & 0xFF) << 24) | ((b0 & 0xFF) << 16) 
                            | ((b3 & 0xFF) << 8) | (b2 & 0xFF);
            case DCBA: return ((b3 & 0xFF) << 24) | ((b2 & 0xFF) << 16) 
                            | ((b1 & 0xFF) << 8) | (b0 & 0xFF);
            default:   return ((b0 & 0xFF) << 24) | ((b1 & 0xFF) << 16) 
                            | ((b2 & 0xFF) << 8) | (b3 & 0xFF);
        }
    }

    private static long parseUInt32(byte[] data, int offset, ByteOrder order) {
        return parseInt32(data, offset, order) & 0xFFFFFFFFL;
    }
}
```

### 6.4 ThingModelMapper（物模型映射器）

```java
/**
 * 物模型 ↔ Modbus 帧映射器
 * 
 * 核心职责：
 * 1. 下行：将 ThingComponent 的 Action（PropertySet/PropertyGet/ServiceInvoke）
 *    转换为 Modbus 请求帧
 * 2. 上行：将 Modbus 响应帧解析结果映射为 ThingModelMessage 的属性/事件
 * 3. 轮询：根据物模型定义生成周期性轮询的 Modbus 请求帧列表
 */
public class ThingModelMapper {

    private final Map<String, ThingModelDefinition> modelCache = new ConcurrentHashMap<>();

    /**
     * 属性设置 → Modbus 帧列表
     * 一个属性设置可能对应多个 Modbus 写操作
     */
    public List<ModbusRequest> propertySetToFrames(DeviceInfo device, Map<String, Object> params) {
        ThingModelDefinition model = getModel(device.getModel());
        List<ModbusRequest> requests = new ArrayList<>();

        for (Map.Entry<String, Object> entry : params.entrySet()) {
            PropertyDef prop = model.getProperty(entry.getKey());
            if (prop == null || !"rw".contains(prop.getAccess())) {
                continue;
            }
            RegisterConfig reg = prop.getModbus();
            Object value = entry.getValue();
            byte[] frame = buildWriteFrame(reg, value);
            requests.add(new ModbusRequest(reg.getSlaveAddr(), reg.getFunctionCode(), frame));
        }
        return requests;
    }

    /**
     * 属性获取 → Modbus 帧列表
     * 支持批量读取优化：将连续地址的寄存器合并为一个批量读取帧
     */
    public List<ModbusRequest> propertyGetToFrames(DeviceInfo device, List<String> keys) {
        ThingModelDefinition model = getModel(device.getModel());
        // 按功能码和连续地址分组合并
        Map<String, List<RegisterConfig>> groups = new HashMap<>();

        for (String key : keys) {
            PropertyDef prop = model.getProperty(key);
            if (prop == null) continue;
            RegisterConfig reg = prop.getModbus();
            String groupKey = reg.getSlaveAddr() + "_" + reg.getFunctionCode();
            groups.computeIfAbsent(groupKey, k -> new ArrayList<>()).add(reg);
        }

        List<ModbusRequest> requests = new ArrayList<>();
        for (List<RegisterConfig> regs : groups.values()) {
            // 排序并合并连续寄存器
            regs.sort(Comparator.comparingInt(RegisterConfig::getStartAddr));
            // 这里可实现寄存器合并逻辑
            for (RegisterConfig reg : regs) {
                byte[] frame = buildReadFrame(reg);
                requests.add(new ModbusRequest(reg.getSlaveAddr(), reg.getFunctionCode(), frame));
            }
        }
        return requests;
    }

    /**
     * 服务调用 → Modbus 帧
     */
    public ModbusRequest serviceToFrame(DeviceInfo device, String serviceName, Map<String, Object> params) {
        ThingModelDefinition model = getModel(device.getModel());
        ServiceDef service = model.getService(serviceName);
        if (service == null) return null;

        RegisterConfig reg = service.getModbus();
        byte[] frame;
        if (reg.getValue() != null) {
            frame = ModbusFrameBuilder.buildWriteSingleRegister(
                    reg.getSlaveAddr(), reg.getStartAddr(), reg.getValue());
        } else {
            // 从 params 中取值
            int value = ((Number) params.values().iterator().next()).intValue();
            frame = ModbusFrameBuilder.buildWriteSingleRegister(
                    reg.getSlaveAddr(), reg.getStartAddr(), value);
        }
        return new ModbusRequest(reg.getSlaveAddr(), reg.getFunctionCode(), frame);
    }

    /**
     * Modbus 响应帧 → 属性 Map
     */
    public Map<String, Object> frameToProperties(DeviceInfo device, ModbusFrame frame) {
        ThingModelDefinition model = getModel(device.getModel());
        Map<String, Object> properties = new HashMap<>();

        for (PropertyDef prop : model.getProperties()) {
            RegisterConfig reg = prop.getModbus();
            if (reg.getSlaveAddr() != frame.getSlaveAddr()) continue;

            Object value = ModbusFrameParser.extractValue(frame, reg.getStartAddr(), reg);
            if (value != null) {
                properties.put(prop.getIdentifier(), value);
            }
        }
        return properties;
    }

    /**
     * 生成轮询帧列表（用于周期性采集）
     * 自动将同一从机、同一功能码的连续寄存器合并为批量读取
     */
    public List<ModbusRequest> getPollingFrames(DeviceInfo device) {
        ThingModelDefinition model = getModel(device.getModel());
        if (model.getPolling() == null || !model.getPolling().isEnabled()) {
            return Collections.emptyList();
        }

        List<ModbusRequest> requests = new ArrayList<>();

        // 优先使用物模型预定义的批量读取组
        if (model.getPolling().getBatchRead() != null 
                && model.getPolling().getBatchRead().isEnabled()
                && model.getPolling().getBatchRead().getGroups() != null) {
            
            for (BatchReadGroup group : model.getPolling().getBatchRead().getGroups()) {
                byte[] frame = ModbusFrameBuilder.buildReadHoldingRegisters(
                        group.getSlaveAddr(), group.getStartAddr(), group.getQuantity());
                requests.add(new ModbusRequest(group.getSlaveAddr(), group.getFunctionCode(), frame));
            }
        } else {
            // 自动分组：按 slaveAddr + functionCode 分组
            Map<String, List<PropertyDef>> autoGroups = new HashMap<>();
            for (PropertyDef prop : model.getProperties()) {
                if (!"r".contains(prop.getAccess())) continue;
                RegisterConfig reg = prop.getModbus();
                String key = reg.getSlaveAddr() + "_" + reg.getFunctionCode();
                autoGroups.computeIfAbsent(key, k -> new ArrayList<>()).add(prop);
            }

            for (List<PropertyDef> props : autoGroups.values()) {
                props.sort(Comparator.comparingInt(p -> p.getModbus().getStartAddr()));
                RegisterConfig first = props.get(0).getModbus();
                RegisterConfig last = props.get(props.size() - 1).getModbus();
                int startAddr = first.getStartAddr();
                int quantity = last.getStartAddr() - startAddr + last.getQuantity();

                byte[] frame = ModbusFrameBuilder.buildReadHoldingRegisters(
                        first.getSlaveAddr(), startAddr, quantity);
                requests.add(new ModbusRequest(first.getSlaveAddr(), first.getFunctionCode(), frame));
            }
        }
        return requests;
    }
}
```

---

## 7. 透传组件实现方案

### 7.1 组件结构

```
iot-components/
└── iot-component-ge100d-transparent/        (新增模块)
    ├── pom.xml
    └── src/main/java/com/enjoyiot/eiot/component/ge100d/
        ├── Ge100dStarter.java               (Vertx 启动入口)
        ├── model/
        │   ├── Ge100dConfig.java             (组件配置)
        │   └── RegisterConfig.java           (Modbus 寄存器映射配置)
        ├── modbus/
        │   ├── ModbusFrameBuilder.java       (帧拼接器)
        │   ├── ModbusFrameParser.java        (帧解析器)
        │   ├── ModbusFrame.java              (帧模型)
        │   ├── ModbusRequest.java            (请求封装)
        │   ├── ModbusCRC.java                (CRC 校验)
        │   ├── DataType.java                 (数据类型枚举)
        │   └── ByteOrder.java                (字节序枚举)
        ├── model/
        │   ├── ThingModelDefinition.java     (物模型定义)
        │   ├── PropertyDef.java              (属性定义)
        │   ├── ServiceDef.java               (服务定义)
        │   └── BatchReadGroup.java           (批量读取组)
        └── service/
            ├── Ge100dTransparentComponent.java  (组件主类)
            ├── Ge100dVerticle.java              (MQTT 连接管理)
            ├── ThingModelMapper.java            (物模型映射器)
            └── ModbusPollingScheduler.java      (轮询调度器)
```

### 7.2 Ge100dTransparentComponent（核心组件）

```java
/**
 * GE100D 透传组件 - 核心组件类
 * 
 * 继承 ThingComponent，负责：
 * 1. MQTT 连接管理（通过 Ge100dVerticle）
 * 2. Modbus 轮询调度（通过 ModbusPollingScheduler）
 * 3. 物模型映射（通过 ThingModelMapper）
 * 4. 上下行消息处理
 */
@Slf4j
@Component
public class Ge100dTransparentComponent extends ThingComponent {

    private final Ge100dVerticle verticle;
    private final ThingModelMapper mapper;
    private ModbusPollingScheduler pollingScheduler;
    private Ge100dConfig currentConfig;

    // ============ 组件元信息 ============

    @Override
    public String getType() {
        return "ge100d-transparent";
    }

    @Override
    public String getName() {
        return "GE100D串口服务器透传组件";
    }

    // ============ 组件生命周期 ============

    @Override
    protected boolean stateChange(boolean enable, String config) {
        if (!enable) {
            stopPolling();
            verticle.stopServer();
            return true;
        }

        currentConfig = JsonUtils.parseObject(config, Ge100dConfig.class);
        if (currentConfig == null) return false;

        verticle.setComponent(this);
        verticle.stopServer();
        verticle.startServer(currentConfig);
        return true;
    }

    // ============ 下行指令处理 ============

    @Override
    protected void propertySet(PropertySet action) {
        DeviceInfo device = getDeviceInfo(action.getProductKey(), action.getDeviceName());
        if (device == null) return;

        List<ModbusRequest> frames = mapper.propertySetToFrames(device, action.getParams());
        for (ModbusRequest req : frames) {
            sendModbusFrame(action.getProductKey(), action.getDeviceName(), req.getFrame());
        }
    }

    @Override
    protected void propertyGet(PropertyGet action) {
        DeviceInfo device = getDeviceInfo(action.getProductKey(), action.getDeviceName());
        if (device == null) return;

        List<ModbusRequest> frames = mapper.propertyGetToFrames(device, action.getKeys());
        for (ModbusRequest req : frames) {
            sendModbusFrame(action.getProductKey(), action.getDeviceName(), req.getFrame());
        }
    }

    @Override
    protected void serviceInvoke(ServiceInvoke action) {
        DeviceInfo device = getDeviceInfo(action.getProductKey(), action.getDeviceName());
        if (device == null) return;

        ModbusRequest request = mapper.serviceToFrame(device, action.getName(), action.getParams());
        if (request != null) {
            sendModbusFrame(action.getProductKey(), action.getDeviceName(), request.getFrame());
        }
    }

    @Override
    protected void deviceConfig(DeviceConfig action) {
        // 透传模式下，配置下发通过写寄存器实现
        // 具体映射由物模型定义
    }

    @Override
    protected void deviceOta(DeviceOta action) {
        // GE100D 透传模式暂不支持 OTA
    }

    @Override
    protected void deviceTopoChange(DeviceTopoChange action) {
        // 透传模式下的拓扑变更通常不需要通知设备
    }

    // ============ 上行消息处理（由 Ge100dVerticle 回调） ============

    /**
     * 处理设备上行 Modbus 帧（从 MQTT 收到）
     */
    public void handleUpstreamFrame(String productKey, String deviceName, byte[] frameBytes) {
        // 1. 解析 Modbus 帧
        ModbusFrame frame = ModbusFrameParser.parse(frameBytes);
        if (frame == null) {
            log.warn("Failed to parse Modbus frame from {}/{}", productKey, deviceName);
            return;
        }

        if (frame.isException()) {
            log.error("Modbus exception from slave {}, code: {}", 
                    frame.getSlaveAddr(), frame.getExceptionCode());
            return;
        }

        // 2. 根据 slaveAddr 查找子设备
        DeviceInfo subDevice = findSubDeviceBySlaveAddr(productKey, deviceName, frame.getSlaveAddr());
        if (subDevice == null) {
            log.warn("Unknown slave addr: {} from gateway {}/{}", 
                    frame.getSlaveAddr(), productKey, deviceName);
            return;
        }

        // 3. 映射为物模型属性
        Map<String, Object> properties = mapper.frameToProperties(subDevice, frame);
        if (properties.isEmpty()) return;

        // 4. 上报到平台
        report(PropertyReport.builder()
                .productKey(subDevice.getProductKey())
                .deviceName(subDevice.getDn())
                .params(properties)
                .build());
    }

    /**
     * 处理网关上线
     */
    public void handleGatewayOnline(String productKey, String deviceName) {
        report(DeviceStateChange.builder()
                .productKey(productKey)
                .deviceName(deviceName)
                .state(DeviceState.ONLINE)
                .build());

        // 启动轮询
        startPolling(productKey, deviceName);
    }

    /**
     * 处理网关离线
     */
    public void handleGatewayOffline(String productKey, String deviceName) {
        stopPolling();

        // 将所有子设备标记为离线
        List<DeviceInfo> subDevices = getSubDevices(productKey, deviceName);
        for (DeviceInfo sub : subDevices) {
            report(DeviceStateChange.builder()
                    .productKey(sub.getProductKey())
                    .deviceName(sub.getDn())
                    .state(DeviceState.OFFLINE)
                    .build());
        }

        report(DeviceStateChange.builder()
                .productKey(productKey)
                .deviceName(deviceName)
                .state(DeviceState.OFFLINE)
                .build());
    }

    // ============ 轮询管理 ============

    private void startPolling(String gatewayPk, String gatewayDn) {
        if (pollingScheduler != null) {
            pollingScheduler.stop();
        }

        List<DeviceInfo> subDevices = getSubDevices(gatewayPk, gatewayDn);
        pollingScheduler = new ModbusPollingScheduler(this, mapper, subDevices,
                currentConfig.getPollInterval());
        pollingScheduler.start();
    }

    private void stopPolling() {
        if (pollingScheduler != null) {
            pollingScheduler.stop();
            pollingScheduler = null;
        }
    }

    // ============ MQTT 发送 ============

    public void sendModbusFrame(String productKey, String deviceName, byte[] frame) {
        verticle.publishDownstream(productKey, deviceName, frame);
    }

    // ============ 设备查询 ============

    private DeviceInfo getDeviceInfo(String pk, String dn) {
        return componentServices.getDeviceApi().getDeviceByPkDnByCache(pk, dn);
    }

    private DeviceInfo findSubDeviceBySlaveAddr(String gatewayPk, String gatewayDn, int slaveAddr) {
        // 从该网关的子设备列表中，按 extension.modbus.slaveAddr 查找
        List<DeviceInfo> subs = getSubDevices(gatewayPk, gatewayDn);
        for (DeviceInfo sub : subs) {
            Map<String, Object> ext = sub.getExtension();
            if (ext != null && ext.containsKey("modbus")) {
                Map<String, Object> modbus = (Map<String, Object>) ext.get("modbus");
                Integer addr = (Integer) modbus.get("slaveAddr");
                if (addr != null && addr == slaveAddr) {
                    return sub;
                }
            }
        }
        return null;
    }

    private List<DeviceInfo> getSubDevices(String gatewayPk, String gatewayDn) {
        DeviceInfo gateway = getDeviceInfo(gatewayPk, gatewayDn);
        if (gateway == null) return Collections.emptyList();
        return componentServices.getDeviceApi().getSubDevices(gateway.getId());
    }
}
```

### 7.3 Ge100dVerticle（MQTT 连接管理）

```java
/**
 * GE100D MQTT Verticle
 * 管理 MQTT 连接、订阅/发布透传 Topic
 */
@Slf4j
public class Ge100dVerticle extends AbstractVerticle implements Runnable {

    private Ge100dTransparentComponent component;
    private Ge100dConfig config;
    private MqttClient client;
    private boolean mqttConnected = false;
    private boolean taskStop = false;

    public void startServer(Ge100dConfig config) {
        this.config = config;
        this.taskStop = false;

        MqttClientOptions options = new MqttClientOptions()
                .setClientId("ge100d_server_" + IdUtil.fastSimpleUUID())
                .setUsername(config.getMqttUsername())
                .setPassword(config.getMqttPassword())
                .setCleanSession(true)
                .setKeepAliveInterval(60);

        client = MqttClient.create(vertx, options);

        // 启动定时重连
        ScheduledThreadPoolExecutor executor = ThreadUtil.newScheduled(1, "ge100d_connect");
        executor.scheduleWithFixedDelay(this, 3, 3, TimeUnit.SECONDS);
    }

    @Override
    public void run() {
        if (taskStop) return;
        if (mqttConnected) return;

        try {
            // 订阅上行 Topic 和状态 Topic
            Map<String, Integer> subscribes = new HashMap<>();
            subscribes.put("ge100d/+/+/up", 1);
            subscribes.put("ge100d/+/+/status", 1);

            client.connect(config.getMqttPort(), config.getMqttHost(), s -> {
                if (s.succeeded()) {
                    mqttConnected = true;
                    log.info("GE100D MQTT connected to {}:{}", config.getMqttHost(), config.getMqttPort());

                    client.subscribe(subscribes, e -> {
                        if (e.succeeded()) {
                            log.info("GE100D subscribed topics success");
                        }
                    });
                } else {
                    mqttConnected = false;
                    log.error("GE100D MQTT connect failed: {}", s.cause().getMessage());
                }
            })
            .publishHandler(msg -> {
                String topic = msg.topicName();
                byte[] payload = msg.payload().getBytes();

                // 从 Topic 解析设备标识
                // ge100d/{pk}/{dn}/up  或  ge100d/{pk}/{dn}/status
                String[] parts = topic.split("/");
                if (parts.length < 4) return;
                String pk = parts[1];
                String dn = parts[2];

                if (topic.endsWith("/status")) {
                    // 网关状态消息
                    handleStatusMessage(pk, dn, payload);
                } else if (topic.endsWith("/up")) {
                    // 上行 Modbus 数据
                    component.handleUpstreamFrame(pk, dn, payload);
                }
            })
            .closeHandler(e -> {
                mqttConnected = false;
                component.handleGatewayOffline(null, null); // 需要记录当前网关信息
                log.info("GE100D MQTT connection closed");
            })
            .exceptionHandler(e -> log.error("GE100D MQTT exception", e));

        } catch (Exception e) {
            log.error("GE100D MQTT start failed", e);
        }
    }

    /**
     * 下行发布：发送 Modbus 帧到设备
     */
    public void publishDownstream(String productKey, String deviceName, byte[] frame) {
        if (client == null || !mqttConnected) {
            log.warn("Cannot publish downstream, MQTT not connected");
            return;
        }
        String topic = String.format("ge100d/%s/%s/down", productKey, deviceName);
        client.publish(topic, Buffer.buffer(frame), MqttQoS.AT_LEAST_ONCE, false, false)
                .onSuccess(h -> log.debug("Published Modbus frame to {}", topic))
                .onFailure(e -> log.error("Failed to publish to {}", topic, e));
    }

    public void stopServer() {
        taskStop = true;
        if (client != null) {
            client.disconnect();
            mqttConnected = false;
        }
    }
}
```

### 7.4 ModbusPollingScheduler（轮询调度器）

```java
/**
 * Modbus 轮询调度器
 * 
 * 对每个子设备周期性发送 Modbus 读取指令，采集设备数据。
 * 
 * 设计要点：
 * 1. 同一 RS-485 总线上的设备串行轮询（避免总线冲突）
 * 2. 使用延迟队列实现逐个设备轮询
 * 3. 响应超时自动重试（最多 3 次）
 * 4. 连续失败 N 次后标记设备为离线
 */
@Slf4j
public class ModbusPollingScheduler {

    private final Ge100dTransparentComponent component;
    private final ThingModelMapper mapper;
    private final List<DeviceInfo> devices;
    private final long pollIntervalMs;
    private final ScheduledExecutorService scheduler;
    private final Map<Long, Integer> failureCount = new ConcurrentHashMap<>();
    private static final int MAX_FAILURES = 3;

    public ModbusPollingScheduler(Ge100dTransparentComponent component,
                                   ThingModelMapper mapper,
                                   List<DeviceInfo> devices,
                                   long pollIntervalMs) {
        this.component = component;
        this.mapper = mapper;
        this.devices = devices;
        this.pollIntervalMs = pollIntervalMs;
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
    }

    public void start() {
        // 为每个设备安排轮询任务，错开启动时间避免总线冲突
        long staggerMs = pollIntervalMs / Math.max(devices.size(), 1);
        for (int i = 0; i < devices.size(); i++) {
            DeviceInfo device = devices.get(i);
            long initialDelay = i * staggerMs;
            scheduler.scheduleAtFixedRate(
                    () -> pollDevice(device),
                    initialDelay,
                    pollIntervalMs,
                    TimeUnit.MILLISECONDS
            );
        }
        log.info("Modbus polling started for {} devices, interval={}ms", devices.size(), pollIntervalMs);
    }

    private void pollDevice(DeviceInfo device) {
        try {
            List<ModbusRequest> frames = mapper.getPollingFrames(device);
            for (ModbusRequest req : frames) {
                // 发送 Modbus 读取帧到网关（网关会转发到 RS-485）
                component.sendModbusFrame(
                        getGatewayPk(device),
                        getGatewayDn(device),
                        req.getFrame()
                );
                
                // 注意：响应由 Ge100dVerticle 异步接收后回调 component.handleUpstreamFrame()
                // 这里不需要同步等待响应
            }
            // 成功，清除失败计数
            failureCount.remove(device.getId());
        } catch (Exception e) {
            log.error("Poll device {} failed", device.getDn(), e);
            int failures = failureCount.merge(device.getId(), 1, Integer::sum);
            if (failures >= MAX_FAILURES) {
                log.warn("Device {} consecutive failures >= {}, marking offline", 
                        device.getDn(), MAX_FAILURES);
                component.report(DeviceStateChange.builder()
                        .productKey(device.getProductKey())
                        .deviceName(device.getDn())
                        .state(DeviceState.OFFLINE)
                        .build());
            }
        }
    }

    public void stop() {
        scheduler.shutdown();
        try {
            if (!scheduler.awaitTermination(5, TimeUnit.SECONDS)) {
                scheduler.shutdownNow();
            }
        } catch (InterruptedException e) {
            scheduler.shutdownNow();
            Thread.currentThread().interrupt();
        }
        log.info("Modbus polling stopped");
    }
}
```

---

## 8. 数据库表设计

### 8.1 新增表：`eiot_modbus_thing_model`（物模型定义表）

```sql
CREATE TABLE eiot_modbus_thing_model (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '主键',
    product_key VARCHAR(64) NOT NULL COMMENT '产品Key',
    model_name VARCHAR(128) NOT NULL COMMENT '物模型名称',
    model_definition JSON NOT NULL COMMENT '物模型完整定义 (JSON)',
    version INT DEFAULT 1 COMMENT '版本号',
    status TINYINT DEFAULT 1 COMMENT '状态: 0=停用, 1=启用',
    creator VARCHAR(64) DEFAULT '' COMMENT '创建者',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updater VARCHAR(64) DEFAULT '' COMMENT '更新者',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted TINYINT DEFAULT 0 COMMENT '是否删除',
    UNIQUE KEY uk_product_key (product_key)
) COMMENT 'Modbus物模型定义表';
```

### 8.2 扩展表：`eiot_device` 增加字段

```sql
ALTER TABLE eiot_device 
ADD COLUMN extension JSON COMMENT '设备扩展属性(JSON)，包含modbus从机地址、寄存器映射等配置',
ADD COLUMN parent_id BIGINT DEFAULT NULL COMMENT '父设备ID(网关)';
```

### 8.3 新增表：`eiot_modbus_polling_log`（轮询日志，可选）

```sql
CREATE TABLE eiot_modbus_polling_log (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '主键',
    device_id BIGINT NOT NULL COMMENT '设备ID',
    gateway_id BIGINT NOT NULL COMMENT '网关ID',
    slave_addr INT NOT NULL COMMENT 'Modbus从机地址',
    function_code INT NOT NULL COMMENT '功能码',
    request_hex VARCHAR(512) COMMENT '请求帧(HEX)',
    response_hex VARCHAR(512) COMMENT '响应帧(HEX)',
    success TINYINT DEFAULT 1 COMMENT '是否成功',
    error_msg VARCHAR(256) COMMENT '错误信息',
    duration_ms INT COMMENT '耗时(毫秒)',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_device_time (device_id, create_time)
) COMMENT 'Modbus轮询日志表';
```

---

## 9. 配置示例

### 9.1 application.yaml 配置

```yaml
# GE100D 透传组件配置
ge100d:
  enabled: true
  mqtt:
    host: 127.0.0.1
    port: 1883
    username: ge100d_server
    password: your_password_here
    topics: ge100d/+/+/up,ge100d/+/+/status
  polling:
    default-interval: 5000          # 默认轮询间隔(ms)
    max-failures: 3                  # 连续失败次数阈值
    stagger-delay: 200               # 设备间错开延迟(ms)，避免总线冲突
  modbus:
    timeout: 1000                    # Modbus 响应超时(ms)
    retry-count: 2                   # 重试次数
```

### 9.2 组件配置（数据库 `eiot_component` 表）

```json
{
  "type": "ge100d-transparent",
  "name": "GE100D串口服务器透传组件",
  "status": 1,
  "config": {
    "mqttHost": "192.168.1.100",
    "mqttPort": 1883,
    "mqttUsername": "ge100d_server",
    "mqttPassword": "server_secret_123",
    "pollInterval": 5000,
    "modbusTimeout": 1000,
    "modbusRetry": 2
  }
}
```

### 9.3 GE100D 网关侧配置示例

```
# GE100D 配置（通过 Web 管理页面或 AT 指令）

工作模式: 透传模式 (Transparent Transmission)
MQTT Broker: 192.168.1.100:1883
Client ID: prod_ge100d_gateway_01
用户名: ge100d_prod_ge100d
密码: device_secret_456

上行 Topic: ge100d/prod_ge100d/gateway_01/up
下行 Topic: ge100d/prod_ge100d/gateway_01/down
状态 Topic: ge100d/prod_ge100d/gateway_01/status

串口参数:
  波特率: 9600
  数据位: 8
  停止位: 1
  校验位: None

MQTT QoS: 1
```

### 9.4 物模型完整配置示例

```json
{
  "productKey": "prod_relay_4ch",
  "productName": "4路继电器控制器",
  "model": "RLY-4CH",
  "protocol": "modbus-rtu",
  
  "properties": [
    {
      "identifier": "relay1",
      "name": "继电器1",
      "dataType": "boolean",
      "access": "rw",
      "modbus": {
        "slaveAddr": 3,
        "functionCode": 1,
        "registerType": "COIL",
        "startAddr": 0,
        "quantity": 1,
        "dataType": "BITS"
      }
    },
    {
      "identifier": "relay2",
      "name": "继电器2",
      "dataType": "boolean",
      "access": "rw",
      "modbus": {
        "slaveAddr": 3,
        "functionCode": 1,
        "registerType": "COIL",
        "startAddr": 1,
        "quantity": 1,
        "dataType": "BITS"
      }
    },
    {
      "identifier": "relay3",
      "name": "继电器3",
      "dataType": "boolean",
      "access": "rw",
      "modbus": {
        "slaveAddr": 3,
        "functionCode": 1,
        "registerType": "COIL",
        "startAddr": 2,
        "quantity": 1,
        "dataType": "BITS"
      }
    },
    {
      "identifier": "relay4",
      "name": "继电器4",
      "dataType": "boolean",
      "access": "rw",
      "modbus": {
        "slaveAddr": 3,
        "functionCode": 1,
        "registerType": "COIL",
        "startAddr": 3,
        "quantity": 1,
        "dataType": "BITS"
      }
    }
  ],
  
  "services": [
    {
      "identifier": "turnOnAll",
      "name": "全部打开",
      "callType": "async",
      "modbus": {
        "slaveAddr": 3,
        "functionCode": 15,
        "startAddr": 0,
        "quantity": 4,
        "dataType": "BITS",
        "values": [true, true, true, true]
      }
    },
    {
      "identifier": "turnOffAll",
      "name": "全部关闭",
      "callType": "async",
      "modbus": {
        "slaveAddr": 3,
        "functionCode": 15,
        "startAddr": 0,
        "quantity": 4,
        "dataType": "BITS",
        "values": [false, false, false, false]
      }
    }
  ],
  
  "polling": {
    "enabled": true,
    "interval": 3000,
    "batchRead": {
      "enabled": true,
      "groups": [
        {
          "slaveAddr": 3,
          "startAddr": 0,
          "quantity": 4,
          "functionCode": 1,
          "properties": ["relay1", "relay2", "relay3", "relay4"]
        }
      ]
    }
  }
}
```

---

## 10. 其他关键设计要点

### 10.1 RS-485 总线冲突避免

**问题**: 多个从机共用一条 RS-485 总线，不能同时通信。

**方案**:
1. **串行轮询**: `ModbusPollingScheduler` 采用单线程调度器，逐个设备轮询
2. **错开启动**: 不同设备的首次轮询时间错开 `staggerDelay`（默认 200ms）
3. **超时保护**: Modbus 请求超时时间设为 `timeout`（默认 1000ms），超时后自动发送下一条
4. **请求队列**: 下行控制指令（propertySet/serviceInvoke）排队等待当前轮询完成后再发送

```
轮询时序示意:
  Device1   |====帧1====|  等待  |====帧1====|  等待  |
  Device2   |  等待  |====帧1====|  等待  |====帧1====|
  Device3   |    等待    |====帧1====|  等待  |====帧1=|
            ├─────────────────────────────────────────
            时间轴 →
```

### 10.2 请求-响应匹配

**问题**: 透传模式下，上行 Modbus 响应帧和下行请求帧之间没有消息 ID 关联，需要自行匹配。

**方案**: 使用 `RequestTracker` 维护请求-响应映射：

```java
/**
 * Modbus 请求追踪器
 * 
 * 维护已发送请求的上下文，用于匹配响应帧
 */
public class RequestTracker {
    
    // 设备标识 → 最近一次请求的上下文
    private final Map<String, PendingRequest> pendingRequests = new ConcurrentHashMap<>();
    
    /**
     * 注册一个待响应请求
     * @param gatewayKey 网关标识 (pk:dn)
     * @param slaveAddr  从机地址
     * @param functionCode 功能码
     * @param callback   响应回调
     */
    public void register(String gatewayKey, int slaveAddr, int functionCode, 
                         Consumer<ModbusFrame> callback) {
        String key = gatewayKey + ":" + slaveAddr + ":" + functionCode;
        pendingRequests.put(key, new PendingRequest(callback, System.currentTimeMillis()));
    }
    
    /**
     * 匹配响应帧
     */
    public Consumer<ModbusFrame> match(String gatewayKey, int slaveAddr, int functionCode) {
        String key = gatewayKey + ":" + slaveAddr + ":" + functionCode;
        PendingRequest pending = pendingRequests.remove(key);
        if (pending != null && !pending.isExpired(3000)) {
            return pending.getCallback();
        }
        return null;
    }
    
    /**
     * 清理超时请求
     */
    public void cleanExpired() {
        long now = System.currentTimeMillis();
        pendingRequests.entrySet().removeIf(entry -> entry.getValue().isExpired(3000));
    }
}
```

### 10.3 异常处理策略

| 异常场景 | 处理策略 |
|----------|----------|
| CRC 校验失败 | 丢弃该帧，记录日志 |
| Modbus 异常响应 (功能码 0x80+) | 记录异常码，向上层返回错误 |
| 从机无响应（超时） | 重试 2 次，3 次失败后标记设备离线 |
| MQTT 连接断开 | 定时重连（每 3 秒），重连后恢复轮询 |
| 网关离线 | 停止所有轮询，批量标记子设备离线 |
| 从机地址未知 | 记录告警日志（可选：自动创建设备） |
| 寄存器地址越界 | 记录错误，跳过该属性 |
| 数据类型不匹配 | 记录错误，使用默认值 |

### 10.4 性能优化建议

1. **批量读取优化**: 将同一从机、同一功能码、地址连续的多个寄存器合并为一个批量读取帧
   ```
   优化前: 读寄存器0(1个) + 读寄存器1(1个) + 读寄存器2(1个) = 3次通信
   优化后: 读寄存器0(3个) = 1次通信
   ```

2. **轮询频率自适应**: 根据设备活跃度动态调整轮询频率
   - 高优先级设备（如报警传感器）: 1 秒
   - 普通设备（如温湿度传感器）: 5 秒
   - 低频设备（如电表）: 60 秒

3. **帧缓存**: 对于静态属性的轮询帧，预计算并缓存 Modbus 帧字节数组

4. **连接池**: 如果管理多个 GE100D 网关，考虑使用 MQTT 连接池复用

### 10.5 与现有系统的兼容性

| 现有组件 | 是否冲突 | 说明 |
|----------|----------|------|
| EmqxComponent | 不冲突 | 使用不同 Topic 前缀 (`ge100d/` vs `/sys/`) |
| MqttComponent | 不冲突 | 使用不同 Topic 前缀和组件类型 |
| ModbusComponent | 不冲突 | ModbusComponent 是自定义 TCP 协议，本组件是透传模式 |
| ComponentManager | 完全兼容 | 通过标准的组件发现机制自动注册 |
| DeviceCtrlServiceImpl | 完全兼容 | 通过标准的 sendToDevice() 路由机制 |
| ThingModelMessage | 完全兼容 | 通过 report() 使用标准的 ThingModelMessage 格式 |

### 10.6 部署步骤

```
1. 创建 GE100D 产品（后台管理页面）
   - 节点类型: 网关设备
   - 协议: ge100d-transparent

2. 创建子设备产品（温湿度传感器、电表、继电器等）
   - 节点类型: 子设备
   - 上传物模型 JSON 配置

3. 添加网关设备实例
   - 分配 pk + dn + secret
   - 记录到数据库

4. 添加子设备实例
   - 设置 parentId 指向网关
   - 配置 extension.modbus 参数（slaveAddr、寄存器映射）

5. 配置 EMQX
   - 添加 GE100D 网关的 MQTT 用户认证
   - 配置 ACL 规则

6. 配置 GE100D 网关
   - 工作模式: 透传模式
   - MQTT Broker 地址
   - 串口参数（波特率等）
   - Topic 映射规则

7. 启用 ge100d-transparent 组件（后台管理）
   - status 改为 1
   - 填写组件配置 JSON

8. 启动网关 → 观察日志确认连接成功
```

---

## 附录 A: 系统交互时序图

```
  GE100D网关      EMQX        Ge100dVerticle    Ge100dComponent  ModbusScheduler  ThingModelMapper  ModbusEngine   平台后端
     │             │                │                  │                │                │               │             │
     │ MQTT CONNECT│                │                  │                │                │               │             │
     │────────────>│                │                  │                │                │               │             │
     │             │ 认证回调        │                  │                │                │               │             │
     │             │───────────────>│                  │                │                │               │             │
     │             │                │ handleGatewayOnline               │                │               │             │
     │             │                │─────────────────>│                │                │               │             │
     │             │                │                  │ report(ONLINE) │                │               │             │
     │             │                │                  │────────────────────────────────────────────────────────────>│
     │             │                │                  │ startPolling() │                │               │             │
     │             │                │                  │───────────────>│                │               │             │
     │             │                │                  │                │ getPollingFrames               │             │
     │             │                │                  │                │───────────────>│               │             │
     │             │                │                  │                │<───────────────│               │             │
     │             │                │                  │                │ buildReadFrame │               │             │
     │             │                │                  │                │──────────────────────────────>│             │
     │             │                │                  │                │<──────────────────────────────│             │
     │             │                │                  │<───────────────│                │               │             │
     │             │                │ sendModbusFrame  │                │                │               │             │
     │             │                │<─────────────────│                │                │               │             │
     │             │ publish(down)  │                  │                │                │               │             │
     │             │<───────────────│                  │                │                │               │             │
     │<────────────│                │                  │                │                │               │             │
     │             │                │                  │                │                │               │             │
     │ RS-485 轮询 │                │                  │                │                │               │             │
     │ 从机响应     │                │                  │                │                │               │             │
     │             │                │                  │                │                │               │             │
     │ publish(up) │                │                  │                │                │               │             │
     │────────────>│                │                  │                │                │               │             │
     │             │ publishHandler │                  │                │                │               │             │
     │             │───────────────>│                  │                │                │               │             │
     │             │                │ handleUpstreamFrame               │                │               │             │
     │             │                │─────────────────>│                │                │               │             │
     │             │                │                  │ parse frame    │                │               │             │
     │             │                │                  │──────────────────────────────────────────────>│             │
     │             │                │                  │<──────────────────────────────────────────────│             │
     │             │                │                  │ frameToProperties               │               │             │
     │             │                │                  │────────────────>│                │               │             │
     │             │                │                  │<────────────────│                │               │             │
     │             │                │                  │ report(PROPERTY)│                │               │             │
     │             │                │                  │────────────────────────────────────────────────────────────>│
```

---

## 附录 B: GE100D 透传模式工作原理

```
GE100D 透传模式数据流:

  RS-485 串口数据           GE100D 内部处理            MQTT 网络
  ──────────────           ──────────────            ──────────
                                                      EMQX Broker
  串口接收字节:              透传引擎:                    ↑
  [0x01,0x03,0x04,    →    不做任何解析             publish(topic, payload)
   0x00,0x5A,0x00,          原封不动打包为               │
   0x46,0xXX,0xXX]          MQTT Payload                │
                                                        │
  ← 同样，MQTT 消息                                    │
     直接写入串口               ← subscribe(topic)
     不做任何处理               MQTT Payload → 串口
```

**关键理解**:
- GE100D 在透传模式下**完全不关心** RS-485 上跑的是什么协议
- 可能是 Modbus-RTU、自定义协议、甚至是任意二进制流
- 所有协议层面的工作（拼接帧、CRC 校验、数据解析）都由 Java 服务端完成
- 这也是为什么物模型映射必须配置在平台侧

---

> **文档结束**  
> 如有疑问或需要补充其他设计细节，请随时沟通。
