# GEIO 设备 Topic 改造指南（适配自动注册）

> 适用场景：把**现有 GEIO / GE100D 硬件固件**的 MQTT Topic 改成新平台格式，接入自动注册。
> 依据代码：`GeioConstants.java`、`GeioVerticle.java`、`GeioComponent.java`

---

## 一、一句话结论

**上行/下行 Topic 从 5 段改成 6 段，在 `{dn}` 后面插入一段 `{moduleId}`（模块数字 ID）。**

旧固件发 5 段 Topic 会被服务端**直接丢弃**（不是报错，是静默丢弃），必须升级固件。

---

## 二、Topic 对照

| 方向 | 旧 Topic（5 段） | 新 Topic（6 段） |
|---|---|---|
| 上行（设备→平台） | `geio/{pk}/{dn}/serial/up` | `geio/{pk}/{dn}/{moduleId}/serial/up` |
| 下行（平台→设备） | `geio/{pk}/{dn}/serial/down` | `geio/{pk}/{dn}/{moduleId}/serial/down` |

### 段位定义（新格式）

```
geio/{productKey}/{deviceName}/{moduleId}/serial/up
 [0]      [1]          [2]         [3]        [4]   [5]
```

| 段 | 字段 | 说明 |
|---|---|---|
| 0 | 环境前缀 | 生产 `geio`，测试 `testgeio`（由服务端 `isProd()` 决定） |
| 1 | productKey | 产品 Key |
| 2 | deviceName | 设备名 dn |
| 3 | **moduleId** | **新增段**，模块 ID（`y_module.id` 数字主键，自动注册的关键） |
| 4 | 固定 | `serial` |
| 5 | 方向 | 上行 `up`，下行 `down` |

示例（模块 ID = 123）：
```
上行: geio/apFx3ja3p3nHiSRW/geio_mlxy_test_01_01/123/serial/up
下行: geio/apFx3ja3p3nHiSRW/geio_mlxy_test_01_01/123/serial/down
```

---

## 三、硬件改造清单（改 3 处）

### 1. Publish Topic 加一段 moduleId
```
旧: geio/{pk}/{dn}/serial/up
新: geio/{pk}/{dn}/{moduleId}/serial/up
```

### 2. Subscribe Topic 也加 moduleId
```
旧: geio/{pk}/{dn}/serial/down
新: geio/{pk}/{dn}/{moduleId}/serial/down
```
> 可用通配 `+` 订阅，如 `geio/{pk}/{dn}/+/serial/down`；但建议订阅精确值，避免同网段串扰。

### 3. dn 必须以 `_纯数字` 结尾
命名规则：`geio_{区域}_{用户}_{地址}`

```
geio_mlxy_test_01_01   → addr = 1
geio_mlxy_test_01_02   → addr = 2
```

- 最后一段数字即该设备的**协议地址 addr**
- 不以 `_数字` 结尾 → 服务端**直接报错丢弃，无默认兜底**
- dn 其余段（区域/用户）只是平台命名，不参与协议

---

## 四、moduleId 从哪来

- 平台「模块管理」中模块的**数字 ID**（对应 `y_module.id` 主键，**不是**模块编码 `module_code`）
- 出厂/现场安装时**烧录进设备**，设备每次 publish/subscribe 都要带
- 服务端通过 `moduleApi.getById(moduleId)` 校验模块是否存在

⚠️ **topic 第 3 段必须是纯数字**：非数字会被 `Long.parseLong` 判为 topic 结构不合规，
直接拒绝自动注册（无兜底，便于排查）。

⚠️ **moduleId 只在服务端内存缓存（`moduleIdCache`，key=`pk:dn`），不入库、重启丢失。**
设备重新上报一次即可恢复。

---

## 五、Payload 格式（不变，JSON 协议未改）

### 上行

应答帧（全量 16 路继电器状态）：
```json
{"addr":1,"cmd":"ret","y":[1,1,1,1,1,1,1,1,0,0,1,1,1,1,0,0]}
```
- `y` 固定 16 位，`y[0]` 对应第 1 路（`geio_01`）
- `addr` 必须等于 dn 末段解析出的地址，**不一致直接丢弃**（防串扰）

主动上报帧（无 `cmd` 字段，环境/水质）：
```json
{"id":"10c7ec901419101900","time":"2026-09-05 16:14:13","DO":4.48,"tem":28.6,"PH":8.76}
```

### 下行

控制：
```json
{"addr":1,"cmd":"set","y":[1,null,0]}
```
- `1`=开，`0`=关，`null`=该路不控制；尾部 `null` 会裁剪

轮询：
```json
{"addr":1,"cmd":"get","data":["y"]}
```
- 设备收到后回复 `ret` 全量帧

---

## 六、自动注册触发条件（三条件全满足）

设备上行第一条消息时，服务端自动建设备 + 绑模块：

1. `{pk}` 对应**产品已存在**（且物模型存在）
2. `{moduleId}` 对应**模块已存在**
3. `{dn}` **当前不在设备表**（首次上报）

满足后服务端执行：`registerDevice` → `bindDeviceInternal`，日志打印：
```
geio autoRegister success: pk=..., dn=..., deviceId=..., moduleId=..., tenantId=...
```

---

## 七、常见坑（改造必看）

| 现象 | 原因 |
|---|---|
| 改完没数据、无日志 | 仍是 5 段 Topic，`parts.length < 6` 被静默 `return` 丢弃 |
| 设备建了但控不了 | `moduleIdCache` 为空（设备未上行过），下行直接报错跳过 |
| 服务端重启后控不了 | moduleId 仅内存缓存，重启丢失 → 设备重新上报恢复 |
| 注册失败日志 `moduleId not a number` | topic 第 3 段填了模块编码（非数字），必须是数字 ID |
| 收到数据但 addr 不符被丢 | 上行 `addr` ≠ dn 末段解析值，检查 dn 命名 |
| 测试环境收不到 | 测试环境前缀是 `testgeio` 不是 `geio` |
| 绑定失败但设备已建 | `bindDeviceInternal` 异常，需人工在模块管理补绑 |

---

## 八、改造后自检

1. 设备上电，发一条 6 段 Topic 上行（第 3 段为数字模块 ID）
2. 查日志确认自动注册：`geio autoRegister success`
3. 查设备表：`SELECT * FROM eiot_device_info WHERE dn = '你的dn'`
4. 在平台下发一次开关，看设备是否收到 `cmd":"set"`
5. 设备回复 `ret`，平台物模型 `geio_01~geio_16` 状态更新
