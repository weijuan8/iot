# ModbusComponent 模块完整架构与调用逻辑文档

> 本文档详细描述 ModbusComponent 模块的设计逻辑、业务逻辑、数据流转和调用关系。

---

## 一、系统架构全景图

```
┌────────────────────────────────────────────────────────────────────────────────────┐
│                              Enjoy-IoT 平台                                         │
│                                                                                     │
│  ┌──────────────────┐    ┌──────────────────┐    ┌────────────────────────────────┐│
│  │  后台管理页面      │    │  规则引擎         │    │  时序数据库 / Redis            ││
│  │  (配置组件参数)    │    │  (消费 device_thing│    │  (属性存储 / 设备路由)          ││
│  │                   │    │   topic 消息)      │    │                               ││
│  └────────┬──────────┘    └────────▲──────────┘    └──────────▲─────────────────────┘│
│           │                        │                          │                      │
│           │ eiot_component 表       │ device_thing topic       │ Redis 路由            │
│           ▼                        │                          │                      │
│  ┌────────────────────────────────────────────────────────────────────────────────┐ │
│  │                        ComponentManager（平台管理端）                             │ │
│  │  - 组件发现与注册（COMPONENT_DISCOVER_TOPIC）                                     │ │
│  │  - 消息路由（查 Redis → 发布到 {type}_device_thing）                              │ │
│  └────────────────────────────────────────────────────────────────────────────────┘ │
│                                          │                                           │
│                           {modbus-custom}_device_thing topic                         │
│                                          │                                           │
│  ┌───────────────────────────────────────▼─────────────────────────────────────────┐ │
│  │                        ModbusComponent（本模块核心）                              │ │
│  │                                                                                  │ │
│  │  ┌──────────────────────────────────────────────────────────────────────────┐   │ │
│  │  │                          ThingComponent（父类）                            │   │ │
│  │  │  - config() 每 5 秒轮询 eiot_component 表，获取最新配置                     │   │ │
│  │  │  - report() 上行消息统一入口（Action → ThingModelMessage → device_thing）   │   │ │
│  │  │  - onMessage() 下行消息分发（type → serviceInvoke/propertyGet/...）         │   │ │
│  │  └──────────────────────────────────────────────────────────────────────────┘   │ │
│  │                                         │                                        │ │
│  │  ┌──────────────────────────────────────▼───────────────────────────────────┐   │ │
│  │  │                     AbstractComponent（父类）                              │   │ │
│  │  │  - 组件发现（每 3 秒心跳）                                                 │   │ │
│  │  │  - 消息路由（handler() → Redis 路由匹配 → onMessage()）                    │   │ │
│  │  │  - sendMessage()（Redis 路由缓存 + device_thing 发布）                     │   │ │
│  │  └──────────────────────────────────────────────────────────────────────────┘   │ │
│  │                                         │                                        │ │
│  │  ┌──────────────────────────────────────▼───────────────────────────────────┐   │ │
│  │  │                     ModbusComponent（本类）                                │   │ │
│  │  │                                                                           │   │ │
│  │  │  核心方法：                                                                │   │ │
│  │  │  ┌─ stateChange(enable, config)  配置热更新入口                            │   │ │
│  │  │  ├─ handle(NetSocket)            TCP 连接处理（设备注册/心跳/数据上报）     │   │ │
│  │  │  ├─ readTask()                   定时轮询读取寄存器                        │   │ │
│  │  │  ├─ offlineCheckTask()           离线设备检测                              │   │ │
│  │  │  ├─ online(dn)                   设备上线处理                              │   │ │
│  │  │  └─ sendMsg(dn, msg)            发送消息给指定设备                         │   │ │
│  │  │                                                                           │   │ │
│  │  │  核心数据结构：                                                            │   │ │
│  │  │  ┌─ clientMap:        Map<dn, VertxModbusClient>   设备→TCP连接映射        │   │ │
│  │  │  ├─ dnToDevice:       Map<dn, DeviceInfo>          设备信息缓存            │   │ │
│  │  │  ├─ heartbeatDevice:  Map<dn, Long>                心跳记录（毫秒时间戳）   │   │ │
│  │  │  └─ pkToThingModel:   Map<productKey, ThingModel>  物模型缓存              │   │ │
│  │  └──────────────────────────────────────────────────────────────────────────┘   │ │
│  └────────────────────────────────────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────────────────────────────┘

                                          │
                               TCP 连接（端口 502）
                                          │
┌─────────────────────────────────────────▼──────────────────────────────────────────┐
│                          有人云 USR-G770 数传终端（网关）                            │
│                                                                                     │
│  - 通过 TCP 连接平台 ModbusComponent                                                │
│  - 发送注册包：r_{productKey}_{dn}_{slaveId}                                        │
│  - 发送心跳包：5 字节 ASCII（dn）                                                    │
│  - 透传 Modbus TCP 帧（MBAP Header + PDU）                                          │
└────────────────────────────────────────────────────────────────────────────────────┘
                                          │
                                RS485 / RS232
                                          │
┌─────────────────────────────────────────▼──────────────────────────────────────────┐
│                          Modbus 从机设备（传感器/执行器）                             │
│                                                                                     │
│  例如：温度传感器、湿度传感器、电表、PLC 等                                           │
│  - Slave ID: 1-247（每个设备唯一地址）                                               │
│  - 寄存器类型：线圈(01)、离散输入(02)、保持寄存器(03)、输入寄存器(04)                  │
└────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 二、组件启动与配置热更新流程

```
时间线：

Spring Boot 启动
  │
  ├── ① ModbusStarter.init()（@PostConstruct）
  │     └→ Vertx.vertx().deployVerticle(modbusVerticle)
  │       └→ ModbusVerticle.start() 被调用（此时 TCP Server 未创建）
  │
  ├── ② AbstractComponent 构造函数
  │     └→ 生成 componentId（UUID）
  │     └→ 订阅 COMPONENT_DISCOVER_REPLY_TOPIC
  │     └→ 发送 COMPONENT_DISCOVER_TOPIC（组件发现心跳）
  │
  ├── ③ 每 3 秒：publishDiscover()
  │     └→ ComponentManager 收到 → 入库 eiot_component（首次）→ 回复
  │
  └── ④ 每 5 秒：ThingComponent.config()
         │
         ├─ 调用 ComponentApi.getInfo("modbus-custom")
         │  └→ 从 eiot_component 表读取 status + config JSON
         │
         ├─ 检测配置是否变更
         │  └→ status 变化或 config 变化 → 调用 stateChange()
         │
         └─ ModbusComponent.stateChange(enable, config)
              │
              ├─ enable = false（停用）
              │  ├→ cancelTasks()          停止 readTask + offlineCheckTask
              │  ├→ closeAllClients()      关闭所有 TCP 连接 + 清空缓存
              │  └→ modbusVerticle.stopServer()  停止 TCP Server
              │
              └─ enable = true（启用）
                 ├→ JsonUtils.parseObject(config, ModbusConfig.class)
                 │  └→ ModbusConfig { port: 502, timer: 10 }
                 │
                 ├→ cancelTasks() + closeAllClients() + stopServer()  （先停旧）
                 │
                 ├→ modbusVerticle.startServer(modbusConfig)           （再启新）
                 │  └→ vertx.createNetServer(options)
                 │     └→ server.connectHandler(modbusComponent)  // 设置连接处理器
                 │        └→ server.listen(port)
                 │
                 ├→ taskScheduler.scheduleAtFixedRate(readTask, timer秒)
                 │
                 └→ taskScheduler.scheduleAtFixedRate(offlineCheckTask, 40秒)
```

---

## 三、设备注册完整流程

```
时序图：

网关(USR-G770)          TCP Server           ModbusComponent        DeviceApi         ThingModelApi
    │                      │                      │                    │                  │
    │  ① TCP 连接请求       │                      │                    │                  │
    │─────────────────────>│                      │                    │                  │
    │                      │  ② connectHandler    │                    │                  │
    │                      │─────────────────────>│                    │                  │
    │                      │                      │                    │                  │
    │                      │  ③ handle(socket)    │                    │                  │
    │                      │  创建 VertxModbusClient                   │                  │
    │                      │  设置 Socket 事件处理器                   │                  │
    │                      │                      │                    │                  │
    │  ④ 注册包             │                      │                    │                  │
    │  r_prod_001_A001_1   │                      │                    │                  │
    │─────────────────────>│                      │                    │                  │
    │                      │  bufferConsumer()    │                    │                  │
    │                      │─────────────────────>│                    │                  │
    │                      │                      │                    │                  │
    │                      │         ⑤ DataDecoder.decode(buffer)     │                  │
    │                      │         判断 "r_" 开头 → RegisterDataPackage              │
    │                      │         dn="A001", pk="prod_001", slaveId=1               │
    │                      │                      │                    │                  │
    │                      │         ⑥ client.setDn("A001")          │                  │
    │                      │         clientMap.put("A001", client)    │                  │
    │                      │                      │                    │                  │
    │                      │         ⑦ registerDevice()              │                  │
    │                      │─────────────────────────────────────────>│                  │
    │                      │                      │                    │                  │
    │                      │         ⑧ DeviceInfo(deviceId, pk, dn)  │                  │
    │                      │<─────────────────────────────────────────│                  │
    │                      │                      │                    │                  │
    │                      │         ⑨ dnToDevice.put("A001", device)│                  │
    │                      │                      │                    │                  │
    │                      │         ⑩ findByProductKey("prod_001")  │                  │
    │                      │─────────────────────────────────────────────────────────>│
    │                      │                      │                    │                  │
    │                      │         ⑪ ModbusThingModel（属性列表）   │                  │
    │                      │<─────────────────────────────────────────────────────────│
    │                      │                      │                    │                  │
    │                      │         ⑫ pkToThingModel.put("prod_001", thingModel)     │
    │                      │                      │                    │                  │
    │                      │  设备注册完成 ✓       │                    │                  │
```

**注册包格式详解：**

```
注册包：r_prod_001_A001_1

解析过程：
  "r_prod_001_A001_1".startsWith("r_") → true（判定为注册包）
  "r_prod_001_A001_1".split("_") → ["r", "prod_001", "A001", "1"]
                                    [0]    [1]         [2]     [3]

  结果：
    productKey = "prod_001"   → 产品标识，用于查找物模型
    dn         = "A001"       → 设备序列号，设备在平台中的唯一标识
    slaveId    = 1            → Modbus 从机地址（写入 MBAP Header 的 Unit ID 字段）
```

---

## 四、数据采集完整流程（核心：定时轮询 + 命令发送 + 响应解析）

```
                    ModbusComponent                   网关            Modbus 从机
                         │                             │                  │
  ═══════════════════════╪═════════════════════════════╪══════════════════╪══════════
  定时触发 readTask()     │                             │                  │
  （间隔 = config.timer）  │                             │                  │
                         │                             │                  │
  ① 遍历 clientMap       │                             │                  │
  for each client:       │                             │                  │
                         │                             │                  │
  ② 加载物模型            │                             │                  │
  thingModel =            │                             │                  │
  pkToThingModel          │                             │                  │
  .get(productKey)        │                             │                  │
                         │                             │                  │
  ③ 遍历属性列表          │                             │                  │
  for each property:      │                             │                  │
                         │                             │                  │
  ④ 构造 RequestDataPackage                            │                  │
  {                       │                             │                  │
    transactionId: 5      │                             │                  │
    slaveId: 1            │                             │                  │
    functionCode: 0x03    │                             │                  │
    address: 0            │                             │                  │
    quantity: 2           │                             │                  │
  }                       │                             │                  │
                         │                             │                  │
  ⑤ 建立映射              │                             │                  │
  transactionMap.put(5,   │                             │                  │
    property)             │                             │                  │
                         │                             │                  │
  ⑥ 编码                  │                             │                  │
  DataEncoder.encode()    │                             │                  │
  ┌─────────────────────┐ │                             │                  │
  │ 00 05 │ TX ID = 5   │ │                             │                  │
  │ 00 00 │ Protocol    │ │                             │                  │
  │ 00 06 │ Length = 6  │ │                             │                  │
  │ 01    │ UnitID = 1  │ │                             │                  │
  │ 03    │ FC = 0x03   │ │                             │                  │
  │ 00 00 │ Addr = 0    │ │                             │                  │
  │ 00 02 │ Qty = 2     │ │                             │                  │
  └─────────────────────┘ │                             │                  │
                         │                             │                  │
  ⑦ 发送                  │                             │                  │
  client.sendMessage()    │                             │                  │
  ────────────────────────> ⑧ 收到 Modbus TCP 帧       │                  │
                         │    解析 MBAP Header          │                  │
                         │    提取 PDU                  │                  │
                         │──────────────────────────────> ⑨ 转发 Modbus 命令
                         │                             │  (RS485/RS232)
                         │                             │                  │
                         │                             │  ⑩ 从机处理       │
                         │                             │  读取寄存器 0-1   │
                         │                             │<─────────────────│
                         │                             │  返回 4 字节数据   │
                         │                             │  [0x42,0x48,0,0] │
                         │                             │                  │
                         │  ⑪ 封装为 TCP 响应帧        │                  │
                         │<────────────────────────────│                  │
  ═══════════════════════╪═════════════════════════════╪══════════════════╪══════════
  NetSocket.handler       │                             │                  │
  触发 bufferConsumer     │                             │                  │
                         │                             │                  │
  ⑫ 解码                  │                             │                  │
  DataDecoder.decode()    │                             │                  │
  buffer.length() > 7     │                             │                  │
  → ResponseDataPackage   │                             │                  │
  {                       │                             │                  │
    header: {             │                             │                  │
      transactionId: 5    │                             │                  │
      unitId: 1           │                             │                  │
    }                     │                             │                  │
    pdu: ReadHolding-     │                             │                  │
      RegistersResponse   │                             │                  │
  }                       │                             │                  │
                         │                             │                  │
  ⑬ 匹配属性              │                             │                  │
  property =              │                             │                  │
  transactionMap          │                             │                  │
  .remove(5)              │                             │                  │
  → Property{             │                             │                  │
      identifier:"temp"   │                             │                  │
      regType:"03"        │                             │                  │
      regNum:2            │                             │                  │
      dataType:{          │                             │                  │
        type:"float"      │                             │                  │
      }                   │                             │                  │
      sort:"CD AB"        │                             │                  │
    }                     │                             │                  │
                         │                             │                  │
  ⑭ 解析字节              │                             │                  │
  property.parse(         │                             │                  │
    [0x42,0x48,0,0])      │                             │                  │
  → 字节序重排 "CD AB"    │                             │                  │
  → float 解析            │                             │                  │
  → 结果: 50.0            │                             │                  │
                         │                             │                  │
  ⑮ 上报属性              │                             │                  │
  report(PropertyReport{  │                             │                  │
    pk: "prod_001"        │                             │                  │
    dn: "A001"            │                             │                  │
    params: {"temp":50.0} │                             │                  │
  })                      │                             │                  │
  → sendMessage()         │                             │                  │
  → Redis 路由缓存         │                             │                  │
  → device_thing topic    │                             │                  │
  → 规则引擎消费           │                             │                  │
  → 属性存储到 TSDB        │                             │                  │
                         │                             │                  │
  ⑯ sleep 2 秒           │                             │                  │
  （防止设备并发处理不过来）│                             │                  │
                         │                             │                  │
  ⑰ 处理下一个属性...      │                             │                  │
```

---

## 五、Modbus TCP 帧编解码详解

### 5.1 请求帧编码（DataEncoder.encode()）

```
输入：RequestDataPackage{
  transactionId = 5,
  slaveId = 1,
  functionCode = 0x03,
  address = 0,
  quantity = 2
}

编码过程：

  Buffer buffer = Buffer.buffer();

  ┌─────────────────────────────────────────────────────────────┐
  │ 字节  │ 字段              │ 值         │ 编码方法             │
  ├───────┼──────────────────┼────────────┼──────────────────────┤
  │ 0-1   │ Transaction ID    │ 0x0005     │ appendShort(5)       │
  │ 2-3   │ Protocol ID       │ 0x0000     │ appendShort(0)       │
  │ 4-5   │ Length            │ 0x0006     │ appendShort(6)       │
  │ 6     │ Unit ID           │ 0x01       │ appendByte(1)        │
  │ 7     │ Function Code     │ 0x03       │ appendByte(0x03)     │
  │ 8-9   │ Starting Address  │ 0x0000     │ appendShort(0)       │
  │ 10-11 │ Quantity          │ 0x0002     │ appendShort(2)       │
  └───────┴──────────────────┴────────────┴──────────────────────┘

输出（Hex）：00 05 00 00 00 06 01 03 00 00 00 02

总长度：12 字节（MBAP Header 7 + PDU 5）
```

### 5.2 响应帧解码（DataDecoder.decode()）

```
输入：TCP 原始字节流

解码流程：

  buffer.toString("US-ASCII")
  │
  ├─ startsWith("r_")？ → RegisterDataPackage（注册包）
  │   示例：r_prod_001_A001_1 → productKey="prod_001", dn="A001", slaveId=1
  │
  ├─ length == 5？ → HeartbeatDataPackage（心跳包）
  │   示例：A001 → dn="A001"
  │
  ├─ length > 7？ → ResponseDataPackage（Modbus 响应包）
  │   前 7 字节 → MbapHeader.decode()
  │   ┌───────┬──────────────────┬──────────────────────────────┐
  │   │ 0-1   │ Transaction ID    │ 0x0005（与请求匹配）         │
  │   │ 2-3   │ Protocol ID       │ 0x0000                      │
  │   │ 4-5   │ Length            │ 0x0005（后续 5 字节）        │
  │   │ 6     │ Unit ID           │ 0x01                        │
  │   └───────┴──────────────────┴──────────────────────────────┘
  │   第 8 字节起 → ModbusResponseDecoder.decode()
  │   ┌───────┬──────────────────┬──────────────────────────────┐
  │   │ 7     │ Function Code     │ 0x03（读保持寄存器）         │
  │   │ 8     │ Byte Count        │ 0x04（4 字节数据）           │
  │   │ 9-12  │ Register Values   │ 0x42 0x48 0x00 0x00        │
  │   └───────┴──────────────────┴──────────────────────────────┘
  │
  └─ 其他 → null（无法识别）
```

### 5.3 四种功能码对应的响应类型

```
┌──────────────┬──────┬────────────────────────────────┬──────────────────────────────┐
│ FunctionCode │ 值   │ PDU 类型                        │ 数据提取方法                  │
├──────────────┼──────┼────────────────────────────────┼──────────────────────────────┤
│ ReadCoils    │ 0x01 │ ReadCoilsResponse              │ getCoilStatus().array()       │
│ ReadDiscrete │ 0x02 │ ReadDiscreteInputsResponse     │ getInputStatus().array()      │
│ ReadHolding  │ 0x03 │ ReadHoldingRegistersResponse   │ getRegisters().array()        │
│ ReadInput    │ 0x04 │ ReadInputRegistersResponse     │ getRegisters().array()        │
└──────────────┴──────┴────────────────────────────────┴──────────────────────────────┘

注意：所有响应数据的前 2 字节需要跳过（FunctionCode + ByteCount），
所以使用 Arrays.copyOfRange(array, 2, array.length)。
```

---

## 六、字节数据 → 业务值解析详解（Property.parse()）

### 6.1 完整解析流程

```
原始字节（4 字节）: [0x42, 0x48, 0x00, 0x00]
                         │
                         ▼
  ┌─────────────────────────────────────────────────────┐
  │ 步骤 1：字节序重排（sort）                            │
  │                                                       │
  │ sort = "CD AB" → sort1 = "CDAB"                      │
  │ index = [C→2, D→3, A→0, B→1] = [2, 3, 0, 1]        │
  │                                                       │
  │ 原始:  [A=0x42, B=0x48, C=0x00, D=0x00]             │
  │ 重排:  [C=0x00, D=0x00, A=0x42, B=0x48]             │
  │        = [0x00, 0x00, 0x42, 0x48]                    │
  └───────────────────────┬─────────────────────────────┘
                          │
                          ▼
  ┌─────────────────────────────────────────────────────┐
  │ 步骤 2：数据类型解析（dataType.parse()）              │
  │                                                       │
  │ type = "float"                                       │
  │ bytes.length >= 4 → intValue = ByteUtil.bytesToInt() │
  │   → intValue = 0x00004248 = 16968                    │
  │   → Float.intBitsToFloat(16968)                      │
  │   → 结果: 50.0                                       │
  └─────────────────────────────────────────────────────┘
```

### 6.2 字节序说明

```
Modbus 标准字节序：大端（Big-Endian），高字节在前

但在多寄存器组合时（如 32 位浮点数占 2 个寄存器），不同厂商可能使用不同字节序：

┌──────────┬───────────────────────────────────────────────────────────┐
│ sort     │ 说明                                                        │
├──────────┼───────────────────────────────────────────────────────────┤
│ AB       │ 不重排（2 字节内 AB 顺序）                                  │
│ BA       │ 2 字节内高低字节交换                                        │
│ AB CD    │ 4 字节不重排（寄存器 0 在前，寄存器 1 在后）                │
│ CD AB    │ 4 字节内高低字交换（寄存器 0 和寄存器 1 交换位置）          │
│ DC BA    │ 4 字节内完全反转                                            │
│ BA DC    │ 2 字节内交换 + 高低字交换                                   │
└──────────┴───────────────────────────────────────────────────────────┘

示例：原始 Modbus 数据 [0x42, 0x48, 0x00, 0x00]
  AB CD（不重排）: [0x42, 0x48, 0x00, 0x00] → float = 50.0
  CD AB（字交换）: [0x00, 0x00, 0x42, 0x48] → float = 非常小的数
  DC BA（全反转）: [0x00, 0x00, 0x48, 0x42] → float = 不同的值
```

### 6.3 数据类型转换

```
dataType.parse(bytes) 根据 type 字段进行转换：

┌──────────┬────────────────────────────────────────────────────────────┐
│ type     │ 转换逻辑                                                    │
├──────────┼────────────────────────────────────────────────────────────┤
│ bool     │ bytes 转 int → 0 → specs["0"] 或 "false"                   │
│          │              → 非0 → specs["1"] 或 "true"                  │
├──────────┼────────────────────────────────────────────────────────────┤
│ enum     │ bytes 转 int → specs["{intValue}"] 或 "{intValue}"         │
├──────────┼────────────────────────────────────────────────────────────┤
│ int      │ 2 字节 → ByteUtil.bytesToShort() → intValue                │
├──────────┼────────────────────────────────────────────────────────────┤
│ int32    │ 4 字节 → ByteUtil.bytesToInt() → intValue                  │
├──────────┼────────────────────────────────────────────────────────────┤
│ float    │ 4 字节 → ByteUtil.bytesToInt() → Float.intBitsToFloat()    │
│          │ specs["precision"] → 四舍五入保留小数                       │
├──────────┼────────────────────────────────────────────────────────────┤
│ date     │ ASCII 字符串 → Long.parseLong() → new Date()               │
├──────────┼────────────────────────────────────────────────────────────┤
│ text     │ new String(bytes, US-ASCII)                                │
├──────────┼────────────────────────────────────────────────────────────┤
│ position │ 按 float 处理（暂定）                                       │
└──────────┴────────────────────────────────────────────────────────────┘
```

---

## 七、心跳与离线检测机制

### 7.1 心跳流程

```
网关（USR-G770）                           ModbusComponent
     │                                           │
     │  心跳包（5 字节 ASCII = dn）                │
     │──────────────────────────────────────────>│
     │                                           │
     │                          DataDecoder.decode()
     │                          buffer.length() == 5 → HeartbeatDataPackage
     │                                           │
     │                          online(dn)        │
     │                          ├→ heartbeatDevice.put(dn, now)  // 记录心跳时间
     │                          └→ report(DeviceStateChange{      // 上报 ONLINE
     │                               state: ONLINE,
     │                               dn: "A001"
     │                             })
     │                             → sendMessage()
     │                             → Redis 路由缓存
     │                             → device_thing topic
     │                             → DeviceStateCheckHandler 更新状态
```

### 7.2 离线检测流程

```
offlineCheckTask() 每 40 秒执行

  ┌─────────────────────────────────────────────────────────────┐
  │ 检测 1：Socket 层超时（client.isOnline()）                   │
  │                                                               │
  │ 判断：System.currentTimeMillis() - lastKeepAliveTime         │
  │       > keepAliveTimeoutMs (60秒)                            │
  │                                                               │
  │ 场景：TCP 连接断开、网关断电、网络中断                        │
  │ 动作：client.shutdown() → socket.close()                     │
  └─────────────────────────────────────────────────────────────┘

  ┌─────────────────────────────────────────────────────────────┐
  │ 检测 2：业务层心跳超时（heartbeatDevice）                     │
  │                                                               │
  │ 判断：System.currentTimeMillis() - 最后心跳时间               │
  │       > keepAliveTimeout * 2 (120秒)                         │
  │                                                               │
  │ 场景：网关在线但设备不发送心跳包                              │
  │ 动作：                                                       │
  │   heartbeatDevice.remove(dn)                                 │
  │   report(DeviceStateChange{ state: OFFLINE })                │
  │   → sendMessage() → device_thing topic                       │
  └─────────────────────────────────────────────────────────────┘

时间线示例：

  心跳包          心跳包          心跳包（丢失）    离线检测
  │              │              │              │
  │  t=0         │  t=30        │  t=60        │  t=120
  ▼              ▼              ▼              ▼
  ──●──────────────●──────────────○──────────────●──→ 时间
  正常            正常           心跳丢失        判定离线
                                              (120秒 > 60*2)
```

---

## 八、Transaction ID 机制详解

### 8.1 Transaction ID 的作用

```
Modbus TCP 协议是无状态的请求-响应模型。
Transaction ID 用于在同一个 TCP 连接上区分多个并发请求的响应。

    发送请求 A                 发送请求 B
    (TX ID=5)                 (TX ID=6)
        │                         │
        ▼                         ▼
   ┌─────────────────────────────────────────────┐
   │              TCP 连接                         │
   │                                              │
   │  请求帧(TX=5)→     ←响应帧(TX=5)              │
   │  请求帧(TX=6)→     ←响应帧(TX=6)              │
   └─────────────────────────────────────────────┘

虽然实际代码中每个属性之间 sleep 2 秒（避免并发），
但 Transaction ID 仍然用于匹配请求和对应的属性定义。
```

### 8.2 Transaction ID 的生成与使用

```
生成：
  client.getTransactionId()
    → transactionId.updateAndGet(i -> (i % 999) + 1)
    → 1, 2, 3, ..., 999, 1, 2, ...

发送时：
  client.getTransactionMap().put(transactionId, property)
  // 将 Transaction ID 与物模型属性绑定

响应时：
  short transactionId = header.getTransactionId()
  ModbusThingModel.Property property = client.getTransactionMap().remove(transactionId)
  // 通过 Transaction ID 找回对应的属性定义
  // 调用 property.parse(bytes) 按正确的数据类型和字节序解析数据
```

---

## 九、核心类关系图

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              接口与抽象类层                                   │
│                                                                              │
│  ┌──────────────────┐     ┌──────────────────────┐                           │
│  │   Component      │     │  ConsumerHandler     │                           │
│  │   (接口)          │     │  <ThingModelMessage> │                           │
│  │                  │     │  (接口)               │                           │
│  │ + getId()        │     │ + handler(msg)       │                           │
│  │ + getType()      │     └──────────┬───────────┘                           │
│  │ + getName()      │                │                                       │
│  │ + sendMessage()  │                │                                       │
│  │ + onMessage()    │                │                                       │
│  └────────┬─────────┘                │                                       │
│           │                          │                                       │
│  ┌────────▼──────────────────────────▼──────────┐                            │
│  │         AbstractComponent                    │                            │
│  │  (抽象类 - 消息路由 + 组件发现)               │                            │
│  │                                              │                            │
│  │  核心方法：                                   │                            │
│  │  + handler(msg)     消息路由匹配              │                            │
│  │  + sendMessage(msg) 更新 Redis 路由 + 发布    │                            │
│  │  + publishDiscover() 组件发现心跳 (每3秒)     │                            │
│  │                                              │                            │
│  │  核心字段：                                   │                            │
│  │  - componentId: UUID                         │                            │
│  │  - componentServices: 平台基础设施            │                            │
│  └──────────────────┬───────────────────────────┘                            │
│                     │                                                        │
│  ┌──────────────────▼───────────────────────────┐                            │
│  │         ThingComponent                       │                            │
│  │  (抽象类 - 配置轮询 + 物模型消息分发)          │                            │
│  │                                              │                            │
│  │  核心方法：                                   │                            │
│  │  + config()          配置轮询 (每5秒)         │                            │
│  │  + report(action)    上行消息统一入口          │                            │
│  │  + onMessage(msg)    下行消息分发             │                            │
│  │                                              │                            │
│  │  抽象方法（子类实现）：                        │                            │
│  │  # stateChange()     组件状态变更             │                            │
│  │  # serviceInvoke()   服务调用                 │                            │
│  │  # propertyGet()     属性获取                 │                            │
│  │  # propertySet()     属性设置                 │                            │
│  │  # deviceConfig()    设备配置                 │                            │
│  │  # deviceOta()       OTA 升级                 │                            │
│  │  # deviceTopoChange() 拓扑变更                │                            │
│  └──────────────────┬───────────────────────────┘                            │
│                     │                                                        │
└─────────────────────┼────────────────────────────────────────────────────────┘
                      │
┌─────────────────────▼────────────────────────────────────────────────────────┐
│                            具体实现层                                          │
│                                                                               │
│  ┌───────────────────────────────────────────────────────────────────────┐   │
│  │                    ModbusComponent                                     │   │
│  │  (具体类 - Modbus-TCP 自定义协议组件)                                   │   │
│  │                                                                        │   │
│  │  实现接口：                                                             │   │
│  │  - Handler<NetSocket>  → handle(NetSocket) TCP 连接处理                 │   │
│  │                                                                        │   │
│  │  核心方法：                                                             │   │
│  │  + stateChange(enable, config)  配置热更新                              │   │
│  │  + handle(NetSocket)            TCP 连接处理                            │   │
│  │  - readTask()                   定时轮询                                │   │
│  │  - offlineCheckTask()           离线检测                                │   │
│  │  + online(dn)                   设备上线                                │   │
│  │  + sendMsg(dn, msg)            发送消息                                 │   │
│  │  + getType() → "modbus-custom"                                        │   │
│  │                                                                        │   │
│  │  核心数据结构：                                                         │   │
│  │  - clientMap: Map<dn, VertxModbusClient>                               │   │
│  │  - dnToDevice: Map<dn, DeviceInfo>                                     │   │
│  │  - heartbeatDevice: Map<dn, Long>                                      │   │
│  │  - pkToThingModel: Map<productKey, ModbusThingModel>                   │   │
│  └───────────────────────────────────────────────────────────────────────┘   │
│                                                                               │
│  ┌──────────────────────┐  ┌──────────────────────┐  ┌─────────────────────┐ │
│  │   ModbusStarter      │  │   ModbusVerticle      │  │  TaskConfiguration  │ │
│  │  (启动器)             │  │  (TCP Server 管理)    │  │  (线程池配置)        │ │
│  │                      │  │                      │  │                     │ │
│  │  @PostConstruct      │  │  startServer()       │  │  ModbusTaskScheduler│ │
│  │  → deployVerticle()  │  │  stopServer()        │  │                     │ │
│  └──────────────────────┘  └──────────────────────┘  └─────────────────────┘ │
│                                                                               │
│  ┌──────────────────────┐  ┌────────────────────────────────────────────────┐ │
│  │  VertxModbusClient   │  │  编解码器                                       │ │
│  │  (客户端连接封装)     │  │                                                │ │
│  │                      │  │  DataPackage (抽象)                             │ │
│  │  - setSocket()       │  │    ├── RegisterDataPackage                      │ │
│  │  - sendMessage()     │  │    ├── HeartbeatDataPackage                     │ │
│  │  - shutdown()        │  │    ├── RequestDataPackage                       │ │
│  │  - isOnline()        │  │    └── ResponseDataPackage                      │ │
│  │  - getTransactionId()│  │                                                │ │
│  │  - transactionMap    │  │  DataEncoder.encode(RequestDataPackage)→Buffer │ │
│  │                      │  │  DataDecoder.decode(Buffer)→DataPackage        │ │
│  └──────────────────────┘  └────────────────────────────────────────────────┘ │
│                                                                               │
│  ┌──────────────────────────────────────────────────────────────────────────┐ │
│  │  配置模型                                                                  │ │
│  │                                                                           │ │
│  │  ModbusConfig { port: 502, timer: 10 }                                   │ │
│  │                                                                           │ │
│  │  ModbusThingModel {                                                       │ │
│  │    productKey: "prod_001",                                                │ │
│  │    model: {                                                               │ │
│  │      properties: [                                                        │ │
│  │        Property { identifier, regType, regAddr, regNum, sort, dataType }  │ │
│  │      ]                                                                    │ │
│  │    }                                                                      │ │
│  │  }                                                                        │ │
│  └──────────────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────────────────────┘
```

---

## 十、关键设计决策与注意事项

### 10.1 为什么使用定时轮询而不是事件驱动？

```
Modbus 协议本身是主从架构（Master-Slave）：
  - Master（平台）主动发送读取命令
  - Slave（设备）只能被动响应，不能主动上报

因此 ModbusComponent 采用了与其他协议组件完全不同的设计：
  - MQTT/TCP/HTTP：设备主动连接 → 主动上报数据 → 平台被动接收
  - Modbus：平台主动发送读取命令 → 设备被动响应 → 平台解析响应

这就是 readTask() 定时轮询的根本原因。
```

### 10.2 为什么每个属性之间 sleep 2 秒？

```
Modbus 设备（特别是通过 RS485 总线连接的设备）不支持并发读取：
  - RS485 是半双工通信，同一时间只能有一个设备在总线上发送数据
  - 如果短时间内发送多个读取命令，设备可能：
    a) 只响应第一个命令（后续命令被忽略）
    b) 返回错误数据（命令冲突导致数据混乱）

因此每个属性读取之间 sleep 2 秒，给设备足够的处理时间。
```

### 10.3 为什么需要自定义协议层？

```
"有人云 USR-G770 数传终端"在标准 Modbus TCP 之上增加了：
  1. 注册包（r_ 开头）：携带设备身份信息（pk、dn、slaveId）
  2. 心跳包（5 字节）：设备存活信号

这些不是标准 Modbus TCP 协议的一部分，是 USR-G770 的自定义扩展。
因此需要通过 DataDecoder 的自定义判断逻辑来区分三种包类型。
```

### 10.4 下行消息为何全为空实现？

```
ModbusComponent 的 6 个下行抽象方法（serviceInvoke、propertySet 等）都是空实现。

原因：Modbus 主从模式下，数据采集通过 readTask 定时轮询完成，
不需要额外的"属性获取"命令。而"属性设置"（写寄存器）虽然技术上可行，
但当前业务场景暂不需要。

如需支持写寄存器，可以在 propertySet() 方法中：
  1. 构造 WriteSingleRegister(0x06) 或 WriteMultipleRegisters(0x10) PDU
  2. 编码为 Modbus TCP 帧
  3. 通过 client.sendMessage() 发送
```

---

## 十一、数据流转总结

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         完整数据流转图（端到端）                              │
│                                                                              │
│  ┌──────────┐    ┌──────────┐    ┌───────────────┐    ┌──────────────────┐  │
│  │ Modbus   │    │ USR-G770 │    │ ModbusComponent│    │ Enjoy-IoT 平台    │  │
│  │ 从机设备  │    │ 数传终端  │    │               │    │                  │  │
│  └────┬─────┘    └────┬─────┘    └───────┬───────┘    └────────┬─────────┘  │
│       │               │                 │                      │            │
│       │               │  ① TCP 连接      │                      │            │
│       │               │────────────────>│                      │            │
│       │               │                 │                      │            │
│       │               │  ② 注册包        │                      │            │
│       │               │  r_pk_dn_sid    │                      │            │
│       │               │────────────────>│                      │            │
│       │               │                 │  ③ 设备注册          │            │
│       │               │                 │─────────────────────>│            │
│       │               │                 │  ④ 加载物模型        │            │
│       │               │                 │<─────────────────────│            │
│       │               │                 │                      │            │
│       │               │  ⑤ 心跳包        │                      │            │
│       │               │  (5字节 dn)     │                      │            │
│       │               │────────────────>│  ⑥ 上报 ONLINE      │            │
│       │               │                 │─────────────────────>│            │
│       │               │                 │                      │            │
│       │               │  ⑦ readTask 定时轮询                   │            │
│       │               │                 │                      │            │
│       │               │  ⑧ Modbus 读命令│                      │            │
│       │               │<────────────────│                      │            │
│       │  ⑨ 转发命令    │                 │                      │            │
│       │<──────────────│                 │                      │            │
│       │               │                 │                      │            │
│       │  ⑩ 返回数据    │                 │                      │            │
│       │──────────────>│                 │                      │            │
│       │               │  ⑪ Modbus 响应帧 │                      │            │
│       │               │────────────────>│                      │            │
│       │               │                 │  ⑫ 解析 + 上报属性   │            │
│       │               │                 │─────────────────────>│            │
│       │               │                 │                      │            │
│       │               │  ... (循环 ⑦-⑫)  │                      │            │
│       │               │                 │                      │            │
│       │               │  ⑬ offlineCheckTask (每40秒)           │            │
│       │               │                 │  ⑭ 心跳超时→OFFLINE  │            │
│       │               │                 │─────────────────────>│            │
│       │               │                 │                      │            │
└───────┴───────────────┴─────────────────┴──────────────────────┴────────────┘
```

---

## 十二、文件清单

| # | 文件 | 说明 |
|---|------|------|
| 1 | `ModbusStarter.java` | 启动器，部署 Verticle |
| 2 | `ModbusVerticle.java` | TCP Server 管理（创建/启动/停止） |
| 3 | `ModbusComponent.java` | 核心业务组件（~800 行） |
| 4 | `VertxModbusClient.java` | 客户端连接封装 |
| 5 | `DataPackage.java` | 数据包抽象基类 |
| 6 | `RegisterDataPackage.java` | 设备注册包 |
| 7 | `HeartbeatDataPackage.java` | 心跳包 |
| 8 | `RequestDataPackage.java` | Modbus 读命令请求包 |
| 9 | `ResponseDataPackage.java` | Modbus 响应包 |
| 10 | `DataEncoder.java` | 请求帧编码器 |
| 11 | `DataDecoder.java` | 响应帧解码器 |
| 12 | `ModbusConfig.java` | 配置模型 |
| 13 | `TaskConfiguration.java` | 线程池配置 |
| 14 | `ModbusThingModel.java` | 物模型定义（含 Property.parse()） |
