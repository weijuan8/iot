# IoT 组件框架继承体系设计文档

## 一、完整类继承关系图

```
                                    ┌─────────────────────────────────┐
                                    │     <<interface>>               │
                                    │     ConsumerHandler<T>          │
                                    │  + handler(T msg)               │
                                    └──────────┬──────────────────────┘
                                               │
                    ┌──────────────────────────┼───────────────────────────────┐
                    │                          │                               │
                    ▼                          ▼                               ▼
    ┌───────────────────────┐   ┌─────────────────────────┐   ┌──────────────────────────┐
    │   AbstractComponent   │   │   ComponentManager      │   │   RuleDeviceConsumer     │
    │   (iot-component-core)│   │   (module-eiot-biz)     │   │   (iot-rule-engine)      │
    │  implements Component,│   │  <ComponentMessage>     │   │  <ThingModelMessage>     │
    │  ConsumerHandler      │   └─────────────────────────┘   └──────────────────────────┘
    │  <ThingModelMessage>  │
    └──────┬────────────────┘
           │ extends
           │
┌──────────▼────────────────────────────────────────────┐
│  <<interface>>                                         │
│  Component                                             │
│  + getId()                                             │
│  + getType()                                           │
│  + getName()                                           │
│  + sendMessage(ThingModelMessage)                      │
│  + onMessage(ThingModelMessage)                        │
└──────────────────────┬─────────────────────────────────┘
                       │ implements
           ┌───────────▼───────────────────┐
           │    AbstractComponent           │  ← 消息路由 + 组件发现 + 设备管理
           │  [抽象类]                      │
           │  - handler(msg)               │  ← ConsumerHandler 回调入口
           │  - sendMessage(msg)           │  ← 上行消息发送
           │  - getRouter()/getRouterKey() │  ← Redis 路由
           │  - publishDiscover()          │  ← 组件心跳
           │  + onMessage(msg) abstract ←─ │  ─ 来自 Component 接口，未实现
           └───────────┬───────────────────┘
                       │ extends
           ┌───────────▼───────────────────┐
           │    ThingComponent              │  ← 配置轮询 + 物模型消息分发
           │  [抽象类]                      │
           │  + config() @Scheduled(5s)     │  ← 定时拉取组件配置
           │  + onMessage(msg) 实现         │  ← 按 type 分发到各类方法
           │  + report(action)              │  ← 上行消息统一入口
           │  # doProperty(msg)             │  ← 属性 get/set 分发
           │  # doServiceInvoke(msg)        │  ← 服务调用分发
           │  # doConfig(msg)              │  ← 配置下发分发
           │  # doOta(msg)                 │  ← OTA 分发
           │  # serviceInvoke(action) abs   │  ← 抽象方法，子类实现协议
           │  # propertySet(action) abs     │  ← 抽象方法，子类实现协议
           │  # propertyGet(action) abs     │  ← 抽象方法，子类实现协议
           │  # deviceConfig(action) abs    │  ← 抽象方法，子类实现协议
           │  # deviceOta(action) abs       │  ← 抽象方法，子类实现协议
           │  # deviceTopoChange(action) abs│  ← 抽象方法，子类实现协议
           │  # stateChange(enable,cfg) abs │  ← 抽象方法，子类处理配置变更
           └──┬───┬───┬───┬───┬───┬───┬────┘
              │   │   │   │   │   │   │
     ┌────────┘   │   │   │   │   │   └────────┐
     ▼            ▼   ▼   ▼   ▼   ▼            ▼
┌─────────┐ ┌──────┐ ┌────┐ ┌───┐ ┌──────┐ ┌──────────┐ ┌────────────┐
│ Emqx    │ │Mqtt  │ │Coap│ │Tcp│ │Http  │ │Udp       │ │Modbus      │ │Ge100d     │
│Component│ │Comp  │ │Comp│ │Comp│ │Comp  │ │Component │ │Component   │ │Component  │
│ "emqx"  │ │"mqtt"│ │"coap"│"tcp"│ │"http"│ │"udp"    │ │"modbus-   │ │"ge100d"   │
│         │ │      │ │     │ │    │ │      │ │         │ │ custom"   │ │          │
└─────────┘ └──────┘ └────┘ └───┘ └──────┘ └──────────┘ └────────────┘ └────────────┘
  ↑ 每个子类实现 getType() 返回自己的协议类型标识（用于 topic 隔离和路由）
```

## 二、各层职责详解

### 2.1 Component 接口（顶层契约）

**文件**: `iot-component-core/.../Component.java`

定义了 IoT 组件必须实现的 5 个方法：

| 方法 | 用途 |
|------|------|
| `getId()` | 返回组件实例 UUID（水平扩展时区分不同实例） |
| `getType()` | 返回协议类型标识（如 "mqtt", "ge100d"，用于 topic 隔离） |
| `getName()` | 返回组件可读名称（日志/展示用） |
| `sendMessage(msg)` | 上行消息（设备→平台），写入 Redis 路由 + 发布到 MQ |
| `onMessage(msg)` | 下行消息（平台→设备），被 handler() 路由确认后调用 |

### 2.2 AbstractComponent（核心引擎层）

**文件**: `iot-component-core/.../AbstractComponent.java`

```
public abstract class AbstractComponent implements Component, ConsumerHandler<ThingModelMessage>
```

**实现了两个接口**：

- `Component` → 提供组件基本能力
- `ConsumerHandler<ThingModelMessage>` → 提供 MQ 消息消费能力（handler 回调）

**核心职责**：

| 功能 | 方法 | 说明 |
|------|------|------|
| 组件发现 | `publishDiscover()` | 每 3 秒发送心跳，向 ComponentManager 宣告自身存在 |
| 消息路由 | `handler(msg)` | MQ 回调入口，Redis 二次确认设备归属后调用 `onMessage()` |
| 发送消息 | `sendMessage(msg)` | 更新 Redis 路由缓存 + 发布到 device_thing topic |
| 路由查询 | `getRouter()/getRouterKey()` | Redis key: `str:iot:device:router:{pk}:{dn}` |

### 2.3 ThingComponent（物模型分发层）

**文件**: `iot-component-core/.../ThingComponent.java`

```
public abstract class ThingComponent extends AbstractComponent
```

**扩展了 AbstractComponent，新增三大能力**：

| 能力 | 方法 | 说明 |
|------|------|------|
| 配置热更新 | `config()` @Scheduled 5s | 定时从数据库拉取最新配置，变更时调用 `stateChange()` |
| 下行分发 | `onMessage(msg)` | **实现了 Component 接口的方法**，按 `msg.type` 分发到具体处理方法 |
| 上行转换 | `report(action)` | 将协议层 Action 对象转换为 ThingModelMessage 并发送 |

**onMessage 分发逻辑**：

```
onMessage(ThingModelMessage msg)
  ├── type="service"   → doServiceInvoke() → serviceInvoke(ServiceInvoke)
  ├── type="property"  → doProperty()
  │     ├── identifier="set" → propertySet(PropertySet)
  │     └── identifier="get" → propertyGet(PropertyGet)
  ├── type="config"    → doConfig()        → deviceConfig(DeviceConfig)
  ├── type="ota"       → doOta()           → deviceOta(DeviceOta)
  └── type="topo_change" → topoChange()    → deviceTopoChange(DeviceTopoChange)
```

**6 个抽象方法（由子类实现具体协议交互）**：

```
serviceInvoke()    propertySet()     propertyGet()
deviceConfig()     deviceOta()       deviceTopoChange()
```

### 2.4 具体协议组件（协议实现层）

每个协议组件只需要实现：

1. **3 个标识方法**：`getType()`, `getName()`, `stateChange()`
2. **1~6 个协议方法**：根据协议能力选择性实现

以 `Ge100dComponent` 为例，它只真正实现了 `serviceInvoke()`（透传命令模式），其余方法为空实现或仅打日志：

```java
@Component
public class Ge100dComponent extends ThingComponent {
    @Override public String getType() { return "ge100d"; }
    @Override public String getName() { return "智嵌物联GE100D网关透传组件"; }

    // 配置变更处理
    @Override public boolean stateChange(boolean enable, String cfg) { ... }

    // 下行 - 真正实现的方法
    @Override protected void serviceInvoke(ServiceInvoke action) { ... }

    // 下行 - 空实现（GE100D 不支持属性设置等操作）
    @Override protected void propertySet(PropertySet action) { log.debug(...); }
    @Override protected void propertyGet(PropertyGet action) {}
    @Override protected void deviceConfig(DeviceConfig action) {}
    @Override protected void deviceOta(DeviceOta action) {}
    @Override protected void deviceTopoChange(DeviceTopoChange action) {}
}
```

## 三、ConsumerHandler 接口的并行实现

除了通过 `AbstractComponent` 实现，`ConsumerHandler` 还被另外两个类直接实现：

| 类 | 泛型 | 作用 |
|----|------|------|
| `AbstractComponent` | `<ThingModelMessage>` | 组件侧：接收 `{type}_device_thing` 下行指令 |
| `ComponentManager` | `<ComponentMessage>` | 管理端：接收 `COMPONENT_DISCOVER_TOPIC` 组件心跳 |
| `RuleDeviceConsumer` | `<ThingModelMessage>` | 规则引擎：消费 `device_thing` topic，触发规则匹配 |

## 四、设计模式与目的

### 4.1 模板方法模式（Template Method）

**体现**：`AbstractComponent` 和 `ThingComponent` 定义了算法骨架，具体步骤留给子类。

```
AbstractComponent 定义:
  handler() → [路由判断] → onMessage()

ThingComponent 定义:
  onMessage() → [类型判断] → doXxx() → xxxInvoke()/xxxSet()/...

子类实现:
  serviceInvoke() / propertySet() / deviceConfig() / ...
```

**目的**：复用通用的路由、分发、配置逻辑，新增协议只需实现少数字段和方法。

### 4.2 策略模式（Strategy）

**体现**：`Component` 接口 + 多个实现类。平台通过 `getType()` 区分不同协议策略。

**目的**：一套框架适配多种 IoT 协议（MQTT、TCP、CoAP、HTTP、UDP、Modbus、GE100D），添加新协议不需要修改框架代码。

### 4.3 Observer 模式（消费者回调）

**体现**：`ConsumerHandler<T>` 接口。消息队列作为被观察者，组件作为观察者。

```
MQ Topic → Consumer 拉取消息 → ConsumerHandler.handler() 回调
```

**目的**：将消息路由与业务处理解耦，组件只关心"收到消息后做什么"，不关心"怎么收到消息"。

### 4.4 为什么继承链分三层？

| 层级 | 增加的能力 | 为什么不分在一层 |
|------|-----------|-----------------|
| **Component** 接口 | 组件标识 + 收发消息 | 定义契约，支持其他非标准实现 |
| **AbstractComponent** | 组件发现 + MQ 路由 + Redis 缓存 | 纯基础设施，与"物模型"概念无关 |
| **ThingComponent** | 配置轮询 + 物模型分发 + 上行转换 | 依赖物模型（ThingModelMessage）概念 |

**关键原因**：`AbstractComponent` 处理的是"消息怎么来、去哪里"的问题，`ThingComponent` 处理的是"消息是什么类型、该谁处理"的问题。两者职责完全不同，分开便于：

- 如果未来需要非物模型的组件（如纯透明转发），可以直接继承 `AbstractComponent` 而不携带 `ThingComponent` 的重量
- 如果只有 `AbstractComponent`，那每个协议组件都要自己写类型分发 switch-case，大量重复代码

### 4.5 为什么 `handler()` 能直接调用 `onMessage()`？

`onMessage()` 是 `Component` 接口声明的方法，`AbstractComponent` 实现了 `Component` 但未实现 `onMessage()`（留给子类）。Java 允许抽象类调用自身未实现的抽象方法，因为：

1. `AbstractComponent` 永远不会被直接 `new`
2. 运行时 `this` 一定是具体子类实例（如 `Ge100dComponent`）
3. JVM 会动态绑定到实际实现（`ThingComponent.onMessage()`）

## 五、消息流全景图

```
┌──────────────────────────────────────────────────────────────────────┐
│                           上行（设备 → 平台）                         │
│                                                                      │
│  硬件 ──协议──▶ Ge100dVerticle ──▶ Ge100dComponent.report()          │
│                                         │                            │
│                           ThingModelMessage                          │
│                                         ▼                            │
│                          sendMessage() ──▶ Redis 写路由               │
│                                         └──▶ MQ: device_thing        │
│                                                 │                    │
│                                    ┌────────────┘                    │
│                                    ▼                                  │
│                           RuleDeviceConsumer                          │
│                           (规则引擎处理)                               │
└──────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────┐
│                          下行（平台 → 设备）                          │
│                                                                      │
│  前端/API ──▶ DeviceCtrlServiceImpl.send()                           │
│                     │                                                │
│                     ▼                                                │
│           ComponentManager.sendToDevice()                            │
│             ├── Redis 查路由: str:iot:device:router:{pk}:{dn}        │
│             └── MQ publish: {type}_device_thing                      │
│                                │                                     │
│                ┌───────────────┘                                     │
│                ▼                                                     │
│     AbstractComponent.handler(msg)  ← ConsumerHandler 回调           │
│       ├── Redis 二次路由确认                                         │
│       └── onMessage(msg)                                             │
│              │                                                       │
│              ▼                                                       │
│     ThingComponent.onMessage(msg)                                    │
│       ├── type="service"  → doServiceInvoke() → serviceInvoke()      │
│       ├── type="property" → doProperty() → propertySet/Get()         │
│       ├── type="config"   → doConfig() → deviceConfig()              │
│       ├── type="ota"      → doOta() → deviceOta()                    │
│       └── type="topo_change" → topoChange()                          │
│              │                                                       │
│              ▼ (JVM 多态绑定到具体组件)                               │
│     Ge100dComponent.serviceInvoke()                                  │
│       └── verticle.publishCommand() ── MQTT ──▶ 硬件                 │
└──────────────────────────────────────────────────────────────────────┘
```

## 六、新增协议组件的步骤

基于以上继承体系，新增一个协议组件只需：

1. 新建模块 `iot-component-{name}`
2. 创建类继承 `ThingComponent`
3. 实现 `getType()` 返回协议标识（如 `"lwm2m"`）
4. 实现 `getName()` 返回可读名称
5. 实现 `stateChange(enable, config)` 处理配置启停
6. 选择性覆写 `serviceInvoke()`、`propertySet()` 等 6 个下行方法
7. 添加 `@Component` 注解

**不需要写任何**：组件发现、消息路由、Redis 缓存、配置轮询、类型分发的代码。
