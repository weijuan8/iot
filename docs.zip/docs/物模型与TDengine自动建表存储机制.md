# 物模型与 TDengine 自动建表存储机制

> **版本**: v1.0 | **日期**: 2026-07-17
> **涉及模块**: 物模型管理、时序数据库(TDengine)、规则引擎

---

## 目录

1. [整体流程图](#1-整体流程图)
2. [核心概念：物模型 ThingModel](#2-核心概念物模型-thingmodel)
3. [链路一：管理员配置物模型 → 自动建表](#3-链路一管理员配置物模型--自动建表)
4. [链路二：设备上报数据 → 存储到时序库](#4-链路二设备上报数据--存储到时序库)
5. [TDengine 表结构设计](#5-tdengine-表结构设计)
6. [类型映射表](#6-类型映射表)
7. [常见问题解答](#7-常见问题解答)
8. [产品、设备、物模型的关系](#8-产品设备物模型的关系)
9. [属性 vs 事件 vs 服务 — 存储差异](#9-属性-vs-事件-vs-服务--存储差异)
10. [thing_model_message 消息日志表详解](#10-thing_model_message-消息日志表详解)

---

## 1. 整体流程图

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         两条独立链路                                      │
└─────────────────────────────────────────────────────────────────────────┘

链路一：【管理员创建/修改物模型 → 自动建表/改表】

  后台 PUT /eiot/thing-model/save
    │
    ▼
  ThingModelController.saveThingModel()
    │
    ▼
  ThingModelServiceImpl.saveThingModel()
    │
    ├── 解析 JSON → ThingModel 对象
    ├── 校验：identifier 唯一性、类型合法性
    │
    ├── 首次创建：
    │   ├── dbStructureData.defineThingModel(thingModel)
    │   │     ├── FieldParser.parse(thingModel)    // 属性 → 数据库字段
    │   │     ├── TableManager.getCreateSTableSql() // 生成 CREATE STABLE SQL
    │   │     └── TdRestApi.execSql(sql)            // HTTP POST 到 TDengine
    │   │           → CREATE STABLE product_property_{pk} (...)
    │   └── MySQL: INSERT INTO thing_model
    │
    └── 修改已有：
        ├── dbStructureData.updateThingModel(thingModel)
        │     ├── DESCRIBE product_property_{pk}  // 查当前表结构
        │     ├── 对比新旧字段差异
        │     ├── ADD COLUMN    ← 新增的属性
        │     ├── MODIFY COLUMN ← 类型或长度变化的属性
        │     └── DROP COLUMN   ← 删除的属性
        ├── MySQL: UPDATE thing_model
        └── Redis: 清除该产品的设备属性缓存

────────────────────────────────────────────────────────────────────────────

链路二：【设备上报数据 → 物模型白名单过滤 → 存储】

  GE100D 发布 JSON → MQTT → Ge100dComponent
    │
    ▼
  ThingComponent.report(PropertyReport)
    → ThingModelMessage(type="property", identifier="report", data={batVoltage:10.8})
    → 发布到 MQ topic: "device_thing"
    │
    ▼
  RuleDeviceConsumer.handler()
    │
    ├── Handler #1: DeviceMessageLogHandler    → TDengine thing_model_message_{id} (原始日志)
    │
    ├── Handler #2: DevicePropertyHandler ★核心★
    │     ├── 过滤: type=="property" && identifier=="report"
    │     ├── 查设备 → 获取 productKey
    │     ├── 查物模型 → 获取属性白名单 {batVoltage → {type:float}, ...}
    │     ├── 遍历上报的每个属性:
    │     │   │
    │     │   ├── batVoltage 在物模型中？✅ → DataType.parse("10.8000") → 10.8
    │     │   │                                         float
    │     │   └── 某字段 不在物模型中？❌ → 静默丢弃
    │     │
    │     ├── Redis: savePropertiesCache(deviceId, {batVoltage:{value:10.8, ...}})
    │     │          ↑ 当前属性缓存，Key=iot:deviceProperty:{deviceId}
    │     │
    │     └── TDengine: devicePropertyData.addProperties(deviceId, properties, time)
    │           │
    │           ├── 查此设备已有的属性值（从 Redis 合并）
    │           ├── 生成 INSERT SQL:
    │           │   INSERT INTO device_property_{id} (time,batvoltage)
    │           │   USING product_property_{pk} TAGS ('{id}')
    │           │   VALUES (?,?);
    │           └── TdTemplate.update(sql) → 写入时序库
    │
    ├── Handler #3: DeviceStateCheckHandler    → 设备上下线状态
    ├── Handler #4: DeviceConfigHandler        → 配置回复
    └── Handler #5: RuleMessageHandler         → 用户规则匹配
```

---

## 2. 核心概念：物模型 ThingModel

**物模型** ＝ 对产品"能上报什么数据"的数字化描述。

### 数据结构

```java
ThingModel {
    id, productKey,
    model: {
        properties: [                    // ← 属性列表（核心）
            {
                identifier: "batVoltage",  // 属性标识符（与上报 JSON 的 key 对应）
                name: "电池电压",            // 显示名称
                dataType: {                 // 数据类型定义
                    type: "float",          //   int32/int64/float/double/string/text/bool/enum/date...
                    specs: {}               //   {min:0, max:100} 或 {length:1024} 或 enum映射
                },
                accessMode: "rw"            // r=只读, rw=可读写
            }
        ],
        services: [...],                  // 服务定义（设备可执行的动作）
        events: [...]                     // 事件定义（设备可触发的告警等）
    }
}
```

### 属性 identifier 与数据上报 key 的关系

```
上报 JSON: {"batVoltage": 10.8}
               │
               ▼
物模型属性: identifier = "batVoltage"  ← 必须完全匹配
               │
               ▼
数据类型: type = "float" → 归一化为 10.8 → 存入 TDengine
```

---

## 3. 链路一：管理员配置物模型 → 自动建表

### 3.1 入口

```
PUT /eiot/thing-model/save
Body: {
    "productKey": "apfx3ja3p3nhisrw",
    "model": "{\"properties\":[{\"identifier\":\"batVoltage\",\"dataType\":{\"type\":\"float\"}}]}"
}
```

### 3.2 处理流程（ThingModelServiceImpl.saveThingModel）

```
saveThingModel(ThingModelSaveReqVO)
  │
  ├── 1. 查询旧物模型: getThingModelByProductKey(productKey)
  │
  ├── 2. 解析 JSON: JsonUtils.parseObject(req.model, ThingModel.Model.class)
  │
  ├── 3. 规范化: normalizeThingModel(thingModel)
  │     └── 对所有属性、服务、事件的 dataType 调用 normalizedType()
  │         "int" → "int32", "double" → "double", "str" → "string" ...
  │
  ├── 4. 校验: validateThingModel(thingModel)
  │     ├── identifier 唯一性检查（同一类目下不允许重复）
  │     ├── identifier 合法性检查（只允许字母数字_:.-，字母开头）
  │     ├── 类型规范校验（enum 必须有 specs，object 必须有嵌套属性，array 必须有 itemType）
  │     └── 数值范围校验（min 不能大于 max）
  │
  ├── 5a. 首次创建（oldData == null）
  │     ├── dbStructureData.defineThingModel(thingModel)  ← 建 TDengine 超级表
  │     └── thingModelMapper.insert(...)                   ← MySQL 存记录
  │
  └── 5b. 更新已有（oldData != null）
        ├── dbStructureData.updateThingModel(thingModel)  ← 对比差异，ALTER TABLE
        ├── thingModelMapper.updateById(...)               ← MySQL 更新记录
        └── deviceApi.clearPropertiesCache(productKey)     ← 清除 Redis 属性缓存
```

### 3.3 首次创建：defineThingModel 建表细节

```
DbStructureDataImpl.defineThingModel(thingModel)
  │
  ├── 1. FieldParser.parse(thingModel)
  │     遍历物模型中所有属性，逐一转为 TdField:
  │       batVoltage(float) → TdField{name:"batvoltage", type:"FLOAT", length:-1}
  │
  ├── 2. TableManager.getCreateSTableSql(tbName, fields, tags)
  │     super table 名: product_property_{productKey} (小写)
  │     tag: device_id NCHAR(50)
  │     生成 SQL:
  │     CREATE STABLE IF NOT EXISTS product_property_apfx3ja3p3nhisrw (
  │         time timestamp,
  │         batvoltage FLOAT
  │     ) TAGS (device_id NCHAR(50));
  │
  └── 3. TdRestApi.execSql(sql)
        HTTP POST → http://{td-host}:{port}/rest/sql/{db}
        Body: SQL 语句
        Auth: Basic Auth (spring.td-datasource.username/password)
```

### 3.4 修改物模型：updateThingModel 改表细节

```
DbStructureDataImpl.updateThingModel(thingModel)
  │
  ├── 1. DESCRIBE product_property_{pk} → 获取现有字段列表
  │
  ├── 2. 对比差异:
  │
  │   oldFields                  newFields                  操作
  │   ─────────────────────────────────────────────────────────
  │   batvoltage NCHAR(1024)     batvoltage FLOAT      →  MODIFY COLUMN (类型变了)
  │   (不存在)                    humidity FLOAT         →  ADD COLUMN (新增)
  │   old_field NCHAR(1024)      (不存在)               →  DROP COLUMN (删除)
  │
  ├── 3. 执行 ALTER SQL:
  │     ALTER STABLE product_property_{pk} ADD COLUMN humidity FLOAT;
  │     ALTER STABLE product_property_{pk} MODIFY COLUMN batvoltage FLOAT;
  │     ALTER STABLE product_property_{pk} DROP COLUMN old_field;
  │
  └── 4. 特殊情况：
        └── 表不存在 (code=9731) → 回退到 defineThingModel()
        └── 所有属性都删了 → DROP STABLE IF EXISTS product_property_{pk}
```

### 3.5 TDengine 改类型限制

```
⚠️ TDengine 限制:
  - 只能修改 NCHAR/BINARY/VARBINARY/GEOMETRY 类型的长度
  - 且长度只能增加，不能减少
  - FLOAT 改 DOUBLE、INT 改 BIGINT 等类型变更 → 不支持

  如果遇到这种错误，必须:
  1. DROP STABLE product_property_{pk};  ← 删除旧表
  2. 重新保存物模型 → 自动 CREATE STABLE
```

---

## 4. 链路二：设备上报数据 → 存储到时序库

### 4.1 数据进入系统

```
GE100D 硬件 → MQTT "ge100d/{pk}/{dn}/serial/up"
  payload: {"batVoltage": 10.8000}
    │
    ▼
Ge100dVerticle JSON 解析 → Map{"batVoltage" → 10.8000}
    │
    ▼
Ge100dComponent.handleSerialRead(pk, dn, data)
    │
    ▼
ThingComponent.report(PropertyReport)
  → 构建 ThingModelMessage {
      type: "property",
      identifier: "report",
      deviceId: xxx,
      productKey: "xxx",
      dn: "xxx",
      data: {"batVoltage": 10.8000}
    }
  → sendMessage(message)
    → Redis: 更新设备路由缓存 str:iot:device:router:{pk}:{dn}
    → MQ: 发布到 device_thing topic
```

### 4.2 Handler 链处理

#### Handler #1: DeviceMessageLogHandler（时序库原始日志）

```java
// 执行顺序: @Order(1)，最先执行
// 作用: 把原始消息原封不动写入 TDengine，不做任何过滤

INSERT INTO thing_model_message_{deviceId}
  USING thing_model_message
  TAGS ('{deviceId}')
  VALUES (time, mid, product_key, device_name, type, identifier, data...);

// 所有上报数据都会存在这里，包括物模型中未定义的字段
// 用途: 消息追踪、调试、数据回溯
```

#### Handler #2: DevicePropertyHandler（核心：物模型白名单过滤 + 持久化）

```
DevicePropertyHandler.handle(msg)
  │
  ├── 1. 过滤: type=="property" && identifier=="report" && data instanceof Map
  │
  ├── 2. deviceApi.getDeviceInfoFromCache(deviceId) → 获取设备信息
  │      └── 拿不到 → 直接 return（设备不存在或缓存失效）
  │
  ├── 3. thingModelApi.getThingModelByProductKeyFromCache(productKey) → 获取物模型
  │      └── 拿不到 → 直接 return（产品未配置物模型）
  │      注解 @Cacheable(cacheNames="thing_model", key="#productKey")
  │      首次查 MySQL，后续读 Redis 缓存
  │
  ├── 4. 构建白名单 Map: {属性identifier → DataType}
  │      {batVoltage → {type:"float"}, temperature → {type:"float"}}
  │
  ├── 5. 遍历上报属性，逐一白名单校验:
  │
  │      上报值                        物模型中存在?    处理
  │      ─────────────────────────────────────────────────────
  │      batVoltage: 10.8000          ✅ float       dataType.parse("10.8000") → 10.8
  │      unknown_field: "xxx"         ❌ 不存在       静默丢弃
  │      switch_1: true               ✅ bool        parseBoolean(true) → 1
  │      temperature: null            ✅ float       null → 跳过
  │
  ├── 6. addProperties 为空 → return（没有任何有效属性）
  │
  ├── 7. 持久化:
  │     ├── Redis: savePropertiesCache(deviceId, addProperties)
  │     │           key = iot:deviceProperty:{deviceId}
  │     │           value = JSON({batVoltage:{value:10.8, occurred:...}})
  │     │           用途: 设备当前值实时查询
  │     │
  │     └── TDengine: devicePropertyData.addProperties(deviceId, addProperties, occurred)
  └─────────────────────────────────────────────────────────────
```

### 4.3 TDengine 写入时序数据（DevicePropertyDataImpl）

```
DevicePropertyDataImpl.addProperties(deviceId, properties, time)
  │
  ├── 1. deviceApi.getDeviceInfoFromCache(deviceId) → 获取设备信息（拿 productKey）
  │
  ├── 2. deviceApi.getPropertiesFromCache(deviceId) → 获取 Redis 中已有属性
  │      └── 合并: oldProperties.putAll(newProperties)
  │          作用: TDengine 子表要求 INSERT 时必须提供所有列的值
  │                如果本次只上报了 batVoltage 但上次有 temperature，
  │                需要把 temperature 的上次值也带上
  │
  ├── 3. 构建 INSERT SQL:
  │      INSERT INTO device_property_{deviceId}
  │        (time, batvoltage, temperature)
  │      USING product_property_{productKey}
  │        TAGS ('{deviceId}')
  │      VALUES (?, ?, ?);
  │
  │      ※ 表名和列名都是小写
  │      ※ 嵌套属性如 location.lat → 列名 `location.lat`（反引号包裹）
  │
  └── 4. TdTemplate.update(sql, args) → 写入 TDengine
```

### 4.4 其他 Handler

```
Handler #3: DeviceStateCheckHandler
  → type=="state" → 更新设备在线/离线状态

Handler #4: DeviceConfigHandler
  → type=="config" → 处理设备配置回复

Handler #5: RuleMessageHandler
  → 匹配用户自定义规则 → 触发告警/联动
```

---

## 5. TDengine 表结构设计

```
┌────────────────────────────────────────────────────────────────────┐
│                         超级表 (STable)                            │
│                                                                     │
│  product_property_{productKey}         ← 产品级，定义所有属性字段    │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │ time       TIMESTAMP        ← 时间戳（主键）                  │   │
│  │ batvoltage FLOAT            ← 物模型属性映射来的列             │   │
│  │ temperature FLOAT           ← 物模型属性映射来的列             │   │
│  │ humidity   FLOAT            ← 物模型属性映射来的列             │   │
│  │ switch_1   TINYINT          ← bool 类型映射为 TINYINT         │   │
│  │ remark     NCHAR(1024)      ← string 类型映射为 NCHAR         │   │
│  │ TAG: device_id NCHAR(50)    ← 标签：区分不同设备               │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                            │                                        │
│              ┌─────────────┼─────────────┐                          │
│              ▼             ▼             ▼                          │
│  ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐    │
│  │ 子表 (Table)      │ │ 子表 (Table)      │ │ 子表 (Table)      │   │
│  │ device_property_1 │ │ device_property_2 │ │ device_property_3 │   │
│  │ TAGS('1')        │ │ TAGS('2')        │ │ TAGS('3')        │   │
│  │ 存设备1的历史数据  │ │ 存设备2的历史数据  │ │ 存设备3的历史数据  │   │
│  └──────────────────┘ └──────────────────┘ └──────────────────┘    │
│                                                                     │
└────────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────┐
│                         消息日志超级表                              │
│                                                                     │
│  thing_model_message                   ← 全局级，存所有原始消息     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │ time        TIMESTAMP                                       │   │
│  │ mid         NCHAR(50)     ← 消息 ID                          │   │
│  │ product_key NCHAR(50)                                       │   │
│  │ device_name NCHAR(50)                                       │   │
│  │ type        NCHAR(20)     ← property/service/event...       │   │
│  │ identifier  NCHAR(50)     ← report/set/get...               │   │
│  │ data        NCHAR(1024)   ← 原始数据 JSON 字符串              │   │
│  │ TAG: device_id NCHAR(50)                                    │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                            │                                        │
│              ┌─────────────┼─────────────┐                          │
│              ▼                           ▼                          │
│  ┌──────────────────────────┐ ┌──────────────────────────┐         │
│  │ thing_model_message_1    │ │ thing_model_message_2    │         │
│  │ (设备1的所有原始消息)     │ │ (设备2的所有原始消息)     │         │
│  └──────────────────────────┘ └──────────────────────────┘         │
└────────────────────────────────────────────────────────────────────┘
```

---

## 6. 类型映射表

| 物模型 type | TDengine 类型 | 说明 |
|------------|:---:|------|
| `int` / `int32` | INT | 32 位有符号整数 |
| `long` / `int64` | BIGINT | 64 位有符号整数 |
| `float` | FLOAT | 32 位浮点数 |
| `decimal` / `double` | DOUBLE | 64 位浮点数 |
| `bool` | TINYINT | 0/1 |
| `enum` | TINYINT | 枚举值存为整数 |
| `string` | NCHAR(1024) | 默认 1024 字符，可通过 specs.length 调整 |
| `text` | NCHAR(1024) | 同上 |
| `date` | NCHAR | JSON 字符串 |
| `datetime` | NCHAR | JSON 字符串 |
| `array` | NCHAR | JSON 序列化后存储 |
| `object` | NCHAR | JSON 序列化后存储 |
| `position` | NCHAR | JSON 序列化后存储 |

### DataType.parse() 归一化规则

| 物模型 type | 输入 `"10.8"` | 输入 `10.8` | 输入 `true` |
|------------|-------------|-----------|-----------|
| `float` | 10.8f | 10.8f | null |
| `double` | 10.8 | 10.8 | null |
| `int32` | 10 | 10 | null |
| `bool` | null | 1 (非0即真) | 1 |
| `string` | "10.8" | "10.8" | "true" |

---

## 7. 常见问题解答

### 7.1 数据上报了为什么时序库查不到？

按优先级排查：

```
① 设备是否创建？productKey 配了吗？
   SELECT id, dn, product_key FROM eiot_device_info WHERE dn = '你的dn';

② 产品下是否配置了物模型？
   SELECT * FROM thing_model WHERE product_key = '你的pk';

③ 上报 JSON 中的 key 和物模型中属性的 identifier 是否完全一致？
   上报 {"batVoltage":10.8}  ← 物模型 identifier="batVoltage" ✅
   上报 {"bat_voltage":10.8} ← 物模型 identifier="batVoltage" ❌ 不匹配！

④ 物模型中的 type 能否正确解析上报的值？
   物模型 type="float"  上报 10.8  ✅
   物模型 type="int32"  上报 10.8  → parseInt → 10 ✅
   物模型 type="float"  上报 "abc" → Float.parseFloat("abc") → null → 跳过！
```

### 7.2 修改物模型类型报错"Only varbinary/binary/nchar/geometry column length could be modified"

TDengine 不支持直接改列类型。解决步骤：
```sql
-- 1. 删除旧超级表
DROP STABLE product_property_{你的pk};

-- 2. 在后台重新保存物模型 → 自动重建超级表
```

### 7.3 为什么原始日志表有数据，但属性表没有？

原始日志表 `thing_model_message` 不做任何过滤。属性表有白名单机制。
日志表有数据说明数据进入了系统，属性表没数据说明**物模型不匹配**。

### 7.4 如何查看设备当前属性值？

```sql
-- 方法 1: 通过时序库查最新值
SELECT * FROM device_property_{deviceId} ORDER BY time DESC LIMIT 1;

-- 方法 2: 通过 Redis 缓存（更快）
GET iot:deviceProperty:{deviceId}
```

### 7.5 Redis 缓存和 TDengine 的关系？

```
Redis (当前值)              TDengine (历史值)
┌────────────────┐          ┌────────────────────────┐
│ 只有最新的一条   │  ◄──►  │ 所有时间点的数据          │
│ 用于实时查询    │          │ 用于趋势图、历史分析      │
│ 每次上报覆盖    │          │ 每次上报追加新行          │
└────────────────┘          └────────────────────────┘
```

---

## 8. 产品、设备、物模型的关系

### 8.1 1:1:1:N 模型

```
产品 (Product)
  │ 1:1 — 一个产品只对应一个物模型
  ▼
物模型 (ThingModel)
  │ 1:N — 一个物模型可被多个设备复用
  ▼
设备 (Device)
```

**举例**：

```
产品A "温湿度传感器" (pk=temp_prod)     产品B "继电器" (pk=relay_prod)
  物模型:                                  物模型:
    temperature (float)                      switch_1 (bool)
    humidity (float)                         switch_2 (bool)
    高温告警 (event)                          过载告警 (event)
       │                                        │
       ├── 设备1: 塘1温度 (dn=pond1_temp)         ├── 设备4: 塘1继电器
       ├── 设备2: 塘2温度 (dn=pond2_temp)         ├── 设备5: 塘2继电器
       └── 设备3: 塘3温度 (dn=pond3_temp)         └── 设备6: 塘3继电器

设备1-3 共享物模型A → 上报 {"temperature":25.5,"humidity":60} 都会被认可
设备4-6 共享物模型B → 上报 {"switch_1":1} 会被认可
```

### 8.2 关键约束

| 关系 | 说明 |
|------|------|
| 产品 → 物模型 | 1:1，通过 `thing_model` 表的 `product_key` 关联 |
| 物模型 → 设备 | 1:N，设备通过 `product_key` 找到所属产品的物模型 |
| 属性定义 | 不同产品定义不同属性，互不影响 |
| 事件定义 | 不同产品定义不同事件，互不影响 |

---

## 9. 属性 vs 事件 vs 服务 — 存储差异

### 9.1 一张图看清

```
消息上报 → device_thing topic
  │
  ├── type="property", identifier="report" (属性上报)
  │     ├── ✅ thing_model_message           ← 原始日志，存 JSON 文本
  │     └── ✅ product_property_{pk}         ← 结构化存储，物模型白名单过滤
  │           每产品一张超级表，列名 = 属性 identifier
  │           可做数值查询: SELECT * WHERE temperature > 30
  │
  ├── type="event", identifier="alarm" (事件上报)
  │     └── ✅ thing_model_message           ← 只存原始日志
  │           ❌ 没有独立的"事件时序表"
  │           事件参数在 data 字段中（JSON 文本）
  │           不能直接按数值查，需解析 JSON
  │
  └── type="service" (服务调用/回复)
        └── ✅ thing_model_message           ← 只存原始日志
              ❌ 没有独立的"服务时序表"
```

### 9.2 为什么事件没有专享表？

```
属性:  高频数据（每秒/每分上报），需要时序查询和数值计算
       → 需要结构化存储，每产品独立列

事件:  低频数据（偶尔触发），内容格式不固定
       → 用 JSON 文本存即可，不需要独立表

服务:  请求-回复模式，不是时序数据
       → 消息日志足矣
```

### 9.3 两张表的字段对比

```
thing_model_message（全局，固定列）          product_property_{pk}（每产品，动态列）
─────────────────────────────────────      ─────────────────────────────────────
所有产品、所有设备共用同一超级表             每产品一张独立的超级表
列是固定的（系统预定义）                    列由物模型属性动态决定
用 type 字段区分是属性/事件/服务            只存属性数据
data 字段存 JSON 全文                      每个属性一个独立列，可数值查询

列结构：                                   列结构（以温湿度传感器为例）：
  time TIMESTAMP                             time TIMESTAMP
  mid NCHAR(50)                              temperature FLOAT    ← 物模型定义
  product_key NCHAR(50)                      humidity FLOAT       ← 物模型定义
  device_name NCHAR(50)                      TAG: device_id NCHAR(50)
  type NCHAR(20)
  identifier NCHAR(50)
  data NCHAR(1024)
  TAG: device_id NCHAR(50)
```

### 9.4 Handler 链如何区分处理

```
RuleDeviceConsumer 按 @Order 顺序调度 5 个 Handler:

Handler #1: DeviceMessageLogHandler
  → 不区分 type，所有消息都写入 thing_model_message
  → 属性、事件、服务、状态、配置...全部存入

Handler #2: DevicePropertyHandler
  → 只处理 type="property" && identifier="report"
  → 物模型白名单过滤 → Redis 缓存 + product_property_{pk} 时序表
  → 事件和服务在这里被跳过（type 不匹配）

Handler #3-5:
  → 都不按 type 区分处理
  → 只有 RuleMessageHandler 会按用户规则匹配（可能匹配事件）
```

---

## 10. thing_model_message 消息日志表详解

### 10.1 这张表是什么？

`thing_model_message` 是 TDengine 中的一张**全局超级表（STable）**，用于存储所有设备上报到平台的**原始消息日志**。它是整个 IoT 平台的"消息审计日志"，记录了所有经过 `device_thing` topic 的消息。

**关键特征**：

| 特征 | thing_model_message | product_property_{pk}（对比） |
|------|--------------------|-------------------------------|
| 超级表数量 | 全局 1 张 | 每个产品 1 张 |
| 数据范围 | 所有消息类型 | 仅属性上报 |
| 物模型过滤 | ❌ 不校验，原样存储 | ✅ 白名单校验，未定义属性丢弃 |
| 列结构 | 固定列（系统预定义） | 动态列（由物模型属性决定） |
| 存储内容 | data 字段存完整 JSON 文本 | 每个属性独立一列 |
| 数值查询 | 需解析 JSON | 直接按列查询 |
| 主要用途 | 消息追踪、调试、审计、统计 | 历史趋势、阈值判断、图表展示 |

### 10.2 什么时候创建？

**thing_model_message 超级表在应用启动时创建**，由 `DbStructureDataImpl.initDbStructure()` 方法负责。

```java
// 文件: iot-temporal-serviceimpl-td/.../DbStructureDataImpl.java
@Override
@PostConstruct  // ← 应用启动时自动执行
public void initDbStructure() {
    // 1. 创建数据库（如果不存在）
    tdRestApi.execSql("CREATE DATABASE IF NOT EXISTS eiot KEEP 365 ...");

    // 2. 创建 rule_log 超级表
    // 3. 创建 task_log 超级表

    // 4. 创建 thing_model_message 超级表 ★
    sql = TableManager.getCreateSTableSql("thing_model_message", Arrays.asList(
            new TdField("mid", "NCHAR", 50),           // 消息ID
            new TdField("product_key", "NCHAR", 50),   // 产品Key
            new TdField("device_name", "NCHAR", 50),   // 设备名称
            new TdField("uid", "NCHAR", 50),           // 用户ID（多租户）
            new TdField("type", "NCHAR", 20),          // 消息类型
            new TdField("identifier", "NCHAR", 50),    // 操作标识符
            new TdField("code", "INT", -1),            // 状态码
            new TdField("data", "NCHAR", 1024),        // 数据体(JSON字符串)
            new TdField("report_time", "BIGINT", -1)   // 设备端上报时间戳
    ), new TdField("device_id", "NCHAR", 50));  // TAG: 按设备分子表
    tdRestApi.execSql(sql);

    // 5. 创建 virtual_device_log 超级表
}
```

**执行的实际 SQL**：

```sql
CREATE STABLE IF NOT EXISTS thing_model_message (
    time        TIMESTAMP,
    mid         NCHAR(50),
    product_key NCHAR(50),
    device_name NCHAR(50),
    uid         NCHAR(50),
    type        NCHAR(20),
    identifier  NCHAR(50),
    code        INT,
    data        NCHAR(1024),
    report_time BIGINT
) TAGS (device_id NCHAR(50));
```

> **关键点**：`thing_model_message` 是应用级全局表，**不是**按产品创建的。它通过 `@PostConstruct` 在 Spring 容器启动后执行一次，与物模型配置无关。

### 10.3 子表什么时候创建？

**子表在设备首次上报数据时自动创建**。TDengine 的 `INSERT INTO ... USING ... TAGS(...)` 语法会自动创建子表（如果不存在）。

```java
// 文件: iot-temporal-serviceimpl-td/.../ThingModelMessageDataImpl.java
@Override
public void add(ThingModelMessage msg) {
    // 子表名: thing_model_message_{deviceId}
    // 使用 USING 语法：如果子表不存在，TDengine 自动以超级表为模板创建
    String sql = String.format(
        "INSERT INTO %s (%s) USING %s TAGS ('%s') VALUES (%s);",
        "thing_model_message_" + msg.getDeviceId(),    // 子表名
        "time,mid,product_key,device_name,uid,type,identifier,code,data,report_time",
        "thing_model_message",                          // 超级表名
        msg.getDeviceId(),                              // TAG值
        "?,?,?,?,?,?,?,?,?,?"
    );
    tdTemplate.update(sql, ...);
}
```

**自动建表时序**：

```
设备首次上报数据
  → MQTT → Ge100dVerticle → ThingComponent.report()
  → ThingModelMessage {type:"property", identifier:"report", ...}
  → 发布到 device_thing topic
  → RuleDeviceConsumer.handler()
  → Handler #1: DeviceMessageLogHandler
  → ThingModelMessageDataImpl.add(msg)
  → INSERT INTO thing_model_message_123 USING thing_model_message TAGS('123') VALUES(...)
  → TDengine 检测子表 thing_model_message_123 不存在
  → 以 thing_model_message 超级表为模板，自动创建子表
  → 写入数据
```

> **无需手动建子表**。TDengine 的 `INSERT ... USING` 机制保证了：超级表存在 + 子表不存在 → 自动创建子表。

### 10.4 各字段含义与 ThingModelMessage 的映射

| TDengine 列 | 类型 | ThingModelMessage 字段 | 说明 |
|-------------|------|----------------------|------|
| `time` | TIMESTAMP | `msg.occurred` | 设备端事件发生时间戳 |
| `mid` | NCHAR(50) | `msg.mid` | 消息唯一 ID（UUID），用于去重和追踪 |
| `product_key` | NCHAR(50) | `msg.productKey` | 产品 key |
| `device_name` | NCHAR(50) | `msg.dn` | 设备名称 |
| `uid` | NCHAR(50) | `msg.uid` | 所属用户 ID（多租户隔离） |
| `type` | NCHAR(20) | `msg.type` | 消息类型：property/event/service/state/config/ping/ota/lifetime |
| `identifier` | NCHAR(50) | `msg.identifier` | 标识符：report/set/get/online/offline/事件名... |
| `code` | INT | `msg.code` | 状态码，0=成功 |
| `data` | NCHAR(1024) | `msg.data` | 消息数据体，JSON 字符串（如 `{"batVoltage":10.8}`） |
| `report_time` | BIGINT | `msg.time` | 消息上报到平台的时间戳 |
| `device_id` (TAG) | NCHAR(50) | `msg.deviceId` | 设备 ID（TAG 列，用于分子表） |

### 10.5 写入的数据范围：所有消息类型

与 `product_property_{pk}` 只存属性上报不同，`thing_model_message` **不区分消息类型**，所有经过 Handler 链的消息都会被写入：

```
消息类型                         type="property"  type="event"  type="service"  type="state"  type="config"  ...
                                identifier=       identifier=   identifier=     identifier=   identifier=
                                "report"          "alarm"       "restart"       "online"      "get"
                                   │                 │              │              │             │
                                   ▼                 ▼              ▼              ▼             ▼
                           ┌──────────────────────────────────────────────────────────────────────┐
                           │              thing_model_message（全部写入）                            │
                           │  每条消息一行，data 字段存完整 JSON，不做物模型校验                         │
                           └──────────────────────────────────────────────────────────────────────┘
                                   │
                                   │ 物模型白名单过滤（DevicePropertyHandler）
                                   ▼
                           ┌──────────────────────────────────────┐
                           │  product_property_{pk}（仅属性上报）   │
                           │  只有物模型中定义的属性才会被写入        │
                           └──────────────────────────────────────┘
```

### 10.6 主要用途

| 用途 | 说明 | 典型场景 |
|------|------|---------|
| **消息追踪/调试** | 设备上报了什么、平台收到了什么，全链路可追溯 | "设备说它上报了温度，但为什么图表没显示？" → 先查 thing_model_message 确认数据是否到达 |
| **数据审计** | 完整记录所有消息，不可篡改 | 排查数据丢失、重复上报等问题 |
| **统计分析** | 按用户/时间统计消息量 | 仪表盘上的"设备上报次数"统计 |
| **原始数据回溯** | 当物模型变更后，历史数据仍在消息日志中 | 新增了物模型属性，想回溯之前的上报数据 |
| **问题排查** | 即使物模型配置错误，消息日志仍有记录 | 属性名不匹配导致未入库 → 从消息日志确认实际 key 名 |

### 10.7 查询示例

```sql
-- 查看设备 123 最近 10 条消息（所有类型）
SELECT * FROM thing_model_message
WHERE device_id = '123'
ORDER BY time DESC LIMIT 10;

-- 查看设备 123 的属性上报记录
SELECT time, data FROM thing_model_message
WHERE device_id = '123' AND type = 'property' AND identifier = 'report'
ORDER BY time DESC LIMIT 20;

-- 查看设备 123 的告警事件
SELECT time, data FROM thing_model_message
WHERE device_id = '123' AND type = 'event'
ORDER BY time DESC LIMIT 20;

-- 统计某用户每小时的设备消息量
SELECT TIMETRUNCATE(time, 1h) as time, count(*) as data
FROM thing_model_message
WHERE uid = 'xxx' AND time >= 1718400000000 AND time <= 1718486400000
GROUP BY time ORDER BY time ASC;

-- 查看所有子表
SHOW STABLES LIKE 'thing_model_message_%';
```

### 10.8 如何通过代码查询

```java
// 文件: IThingModelMessageData.java（接口）
// 实现: ThingModelMessageDataImpl.java（TDengine REST API 实现）

// 1. 按设备查询指定类型的消息
PageResult<ThingModelMessage> page = thingModelMessageData
    .findByTypeAndIdentifier(deviceId, "property", "report", 1, 20);

// 2. 按用户统计上报次数
List<TimeData> stats = thingModelMessageData
    .getDeviceMessageStatsWithUid(uid, startTime, endTime);

// 3. 统计上行消息量（属性上报 + 事件）
List<TimeData> upStats = thingModelMessageData
    .getDeviceUpMessageStatsWithUid(uid, startTime, endTime);
```

### 10.9 三种时序表的职责总结

```
┌────────────────────────────────────────────────────────────────────────────┐
│                         TDengine 三种超级表对比                               │
├────────────────────┬────────────────────┬───────────────────────────────────┤
│ thing_model_message│ rule_log           │ product_property_{pk}             │
│ (消息日志)          │ (规则执行日志)       │ (产品属性)                          │
├────────────────────┼────────────────────┼───────────────────────────────────┤
│ 创建时机: 应用启动   │ 创建时机: 应用启动   │ 创建时机: 保存物模型时                 │
│ 数量: 全局1张       │ 数量: 全局1张       │ 数量: 每个产品1张                    │
│ 内容: 所有原始消息   │ 内容: 规则触发记录   │ 内容: 物模型过滤后的属性值              │
│ 过滤: 无            │ 过滤: 规则匹配后    │ 过滤: 物模型白名单                    │
│ 用途: 审计/追踪/统计 │ 用途: 规则执行历史   │ 用途: 趋势/图表/阈值判断               │
│ 列: 固定            │ 列: 固定           │ 列: 动态（由物模型决定）               │
│ TAG: device_id     │ TAG: rule_id       │ TAG: device_id                    │
│ 子表: 每设备1张     │ 子表: 每规则1张     │ 子表: 每设备1张                      │
└────────────────────┴────────────────────┴───────────────────────────────────┘
```
