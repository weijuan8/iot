# Redis 存储与治理文档

> 适用版本：enjoy-iot (v1.0.0-jdk21)
> 涵盖范围：设备、物模型、告警、联动、组件等所有 Redis 缓存的 key 设计、生命周期、治理建议、容量预估

---

## 一、Redis 在本项目中的角色

Redis 在本项目中承担 **"在线设备快照 + 配置缓存 + 联动去重状态"** 三类职责，**不是**持久化存储（业务数据落 MySQL，时序数据落 TDengine）。所有缓存丢失都能从 MySQL 重建，但缓存命中失败会造成**数据库压力飙升**和**链路延迟增加**。

---

## 二、Key 总览

Key 定义集中在 `module-eiot/module-eiot-biz/src/main/java/com/enjoyiot/module/eiot/dal/redis/RedisKeyConstants.java` 及散落的 `StringRedisTemplate.opsForValue()` 调用中。

| # | Key 模式 | 类型 | 数据类型 | 写入方 | 读取方 | 生命周期管理 |
|---|---|---|---|---|---|---|
| 1 | `iot:product:<productKey>` | String (JSON) | `Product` 实体 | `getProductByPkFromCache` 首次回源 MySQL 后回填 | `ProductApi.getProductByPkFromCache` | `@Cacheable` 写、`@CacheEvict` 清（修改/删除产品时） |
| 2 | `iot:device:<pk>:<dn>` | String (JSON) | `DeviceInfo` 实体 | `getDeviceByPkDnByCache` 回源后回填 | 同左 | `@Cacheable`/`@CacheEvict` |
| 3 | `iot:deviceId:<deviceId>` | String (JSON) | `DeviceInfo` 实体（含阈值 JSON、塘口关联等） | `getDeviceInfoFromCache` 回源后回填 | 规则引擎、设备配置、定时任务等多处 | `@Cacheable`/`@CacheEvict` |
| 4 | `iot:deviceLast:<deviceId>` | String | `Long` 时间戳（毫秒） | `DeviceStateCheckHandler` 每次收到上行消息 | `DeviceStateCheckTask` 离线判定 | **无 TTL**，仅依赖 jar 重启或外部清理 |
| 5 | `iot:deviceProperty:<deviceId>` | String (JSON) | `Map<String, DevicePropertyCache{value, occurred}>` | `DevicePropertyHandler`（设备上报） | `DevicePropertyDataImpl`（写时序库拼列）、`YDeviceThresholdCheckHandler`（联动去重）、`YUnitServiceImpl`/`YDataAnalysisServiceImpl` | **无 TTL**，仅 `clearPropertiesCache(productKey)` 主动清 |
| 6 | `iot:deviceConfig:<pk>:<dn>` | String (JSON) | `DeviceConfig` 实体 | `DeviceConfigServiceImpl.findByPkDn` 回源后回填 | 设备下行配置（GE100D 等组件读取） | `@Cacheable`/`@CacheEvict` |
| 7 | `iot:deviceIdConfig:<deviceId>` | String (JSON) | `DeviceConfig` 实体 | `DeviceConfigServiceImpl.findByDeviceId` 回源后回填 | 同左 | `@Cacheable`/`@CacheEvict` |
| 8 | `iot:thing_model:<productKey>` | String (JSON) | `ThingModel`（含 properties/services/events） | `getThingModelByProductKeyFromCache` 回源后回填 | 规则引擎白名单、`YDataAnalysisServiceImpl` 等 | `@Cacheable`/`@CacheEvict` |
| 9 | `iot:productAllKeys` | String (JSON) | `List<String>` 全量 productKey | `getAllProductKeys` 回源后回填 | GE100D / GEIO 组件轮询全产品 | `@Cacheable(...+#10m)` TTL=10 分钟，`@CacheEvict(allEntries=true)` |
| 10 | `eiot:alert:state:<deviceId>:<propKey>` | String | `"alerting"` / `"recovered"` | `YDeviceThresholdCheckHandler.doAlertCheck` / `sendRecoverIfNeeded` | 同左（防重复通知） | **无 TTL**，jar 重启或外清 |

> **建议补充**：第 10 条（告警状态）的 key 模式 `eiot:alert:state:{}:{}` 硬编码在 `YDeviceThresholdCheckHandler.java`（第 77 行附近），未走 `RedisKeyConstants`，建议补到枚举里便于全局治理。

### 2.1 Key 模式拆分

Key 实际形态举例：

```text
iot:product:apfx3ja3p3nhisrw                      # 产品缓存
iot:device:apfx3ja3p3nhisrw:demo-device-001        # 按 pk+dn 索引的设备缓存
iot:deviceId:2086717681535434752                  # 按 deviceId 索引的设备缓存
iot:deviceLast:2086717681535434752                # 设备最后心跳时间
iot:deviceProperty:2086717681535434752             # 设备当前属性快照
iot:deviceConfig:apfx3ja3p3nhisrw:demo-device-001  # 按 pk+dn 的设备配置
iot:deviceIdConfig:2086717681535434752            # 按 deviceId 的设备配置
iot:thing_model:apfx3ja3p3nhisrw                   # 物模型缓存
iot:productAllKeys                                 # 全量 productKey 列表
eiot:alert:state:2086717681535434752:DO           # 阈值告警状态
```

---

## 三、生命周期与治理

### 3.1 总体治理策略

本项目对 Redis 缓存采用 **"读穿透写回 + 增删时主动失效"** 模式，分两类：

| 类别 | 实现 | 代表 key | 失效机制 |
|---|---|---|---|
| **Spring Cache 类** | `@Cacheable` + `@CacheEvict` | 第 1/2/3/6/7/8/9 条 | 增删改时主动 `@CacheEvict`；改用 `@Cacheable(...+#10m)` 时按注解里的 TTL 过期 |
| **直写直读类** | `StringRedisTemplate.opsForValue().set(...)` | 第 4/5/10 条 | **没有 TTL**，需要外部/调用方主动 `DEL` |

### 3.2 各 key 详细生命周期

#### 第 1/2/3 条：产品/设备基础缓存

```17:18:module-eiot/module-eiot-biz/src/main/java/com/enjoyiot/module/eiot/dal/redis/RedisKeyConstants.java
    String DEVICE = "iot:device";
    String DEVICE_ID = "iot:deviceId";
```

**读取链**：

```217:232:module-eiot/module-eiot-biz/src/main/java/com/enjoyiot/module/eiot/service/device/DeviceInfoServiceImpl.java
    @Override
    @Cacheable(cacheNames = RedisKeyConstants.DEVICE, key = "#pk+':'+#dn",
            unless = "#result == null")
    @TenantIgnore
    public DeviceInfo getDeviceByPkDnByCache(String pk, String dn) { ... }

    @Override
    @Cacheable(cacheNames = RedisKeyConstants.DEVICE_ID, key = "#deviceId",
            unless = "#result == null")
    @TenantIgnore
    public DeviceInfo getDeviceInfoFromCache(Long deviceId) { ... }
```

**失效链**：

- `updateDeviceInfo`：双重 `@CacheEvict` 清 DEVICE + DEVICE_ID
- `deleteDeviceInfo`：清 DEVICE_ID + DEVICE
- `updateDeviceState`：清 DEVICE_ID + DEVICE（状态变了缓存也得同步）
- `subDeRegisterDevice`：通过 `clearDeviceCache` 清两个索引
- ⚠️ `deleteByIds(List<Long>)` 有 **TODO: 删除缓存** —— **批量删设备时不清缓存，会持续读到已被删设备信息**（已在第 256 行标注）

#### 第 4 条：设备最后心跳

```55:68:module-eiot/module-eiot-biz/src/main/java/com/enjoyiot/module/eiot/dal/redis/no/EiotRedisDAO.java
    public void setLastTime(Long deviceId, Long lastTime) {
        String key = RedisKeyConstants.DEVICE_LAST + deviceId;
        stringRedisTemplate.opsForValue().set(key, String.valueOf(lastTime));
    }

    public long getLastTime(Long deviceId) {
        String key = RedisKeyConstants.DEVICE_LAST + deviceId;
        String last = stringRedisTemplate.opsForValue().get(key);
        ...
    }
```

- **写入**：设备每条上行消息都会调一次 `DeviceStateCheckHandler.updateDeviceLastTime`（@Order(3)，规则链必经）
- **读取**：`DeviceStateCheckTask.syncState()` 每 10 秒扫一次所有"在线设备"，对照 `keepAliveTime × 1.1` 判定超时
- **失效**：**无 TTL、无删除逻辑** → 设备永久离线后这条 key 会一直留着，**TTL 设为建议加上，例：`keepAliveTime × 3`**（约 30 分钟到 1 小时）

#### 第 5 条：设备当前属性快照

```79:101:module-eiot/module-eiot-biz/src/main/java/com/enjoyiot/module/eiot/dal/redis/no/EiotRedisDAO.java
    public void saveProperties(Long deviceId, Map<String, DevicePropertyCache> properties) {
        Map<String, DevicePropertyCache> old = getProperties(deviceId);
        old.putAll(properties);
        stringRedisTemplate.opsForValue().set(getPropertyCacheKey(deviceId),
                JsonUtils.toJsonString(new PropertyCacheInfo(old))
        );
    }

    public void clearProperties(List<Long> deviceIds) { ... }
```

**写入路径**（按出现频率排序）：

| 调用方 | 时机 | 是否过物模型白名单 |
|---|---|---|
| `DevicePropertyHandler` | 设备上报 | ✅ 是 |
| `YDeviceThresholdCheckHandler.doLinkage` | 联动 setProperty 后乐观回写（**已禁用**，见 #警告） | ❌ 否 |
| `deviceApi.savePropertiesCache` | 业务层主动调用 | ❌ 否 |

**读取路径**：

| 调用方 | 用途 |
|---|---|
| `DevicePropertyDataImpl.addProperties`（TDengine） | **拼 INSERT 列名**（所有 cache key 当作列名）|
| `YDeviceThresholdCheckHandler.propertyEquals` | 联动去重 |
| `YUnitServiceImpl`、`YDataAnalysisServiceImpl`、`YPondAnalysisServiceImpl` | 实时属性查询 |

> ⚠️ **历史 Bug 已记录**：2026-09-15 因 `y_pond.alert_thresholds` 中 `eio_areator_01` 拼写错误，被联动逻辑写入缓存，导致 `DevicePropertyDataImpl` 拼出超级表不存在的列名，TDengine INSERT 报 "column not found"。修复手段：① 在 `YDeviceThresholdCheckHandler` 增加物模型白名单；② `ThingModelServiceImpl.saveThingModel` 已 `deviceApi.clearPropertiesCache(productKey)`；③ `DevicePropertyDataImpl` 在拼列名前可选再过一次物模型。

**失效机制**：**仅**在保存物模型时按产品清（`ThingModelServiceImpl.saveThingModel` → `deviceApi.clearPropertiesCache(productKey)` → `EiotRedisDAO.clearProperties(deviceIds)`）。其余场景**永不失效**。

> **建议**：① 设备下线时清掉对应 key（`DeviceStateCheckTask` 检测到离线 → DEL 该 key）；② 给个 24h 兜底 TTL 防止"幽灵设备"残留。

#### 第 6/7 条：设备配置缓存

```51:80:module-eiot/module-eiot-biz/src/main/java/com/enjoyiot/module/eiot/service/device/DeviceConfigServiceImpl.java
    @Override
    @Cacheable(cacheNames = RedisKeyConstants.DEVICE_ID_CONFIG, key = "#deviceId", unless = "#result == null")
    public DeviceConfig findByDeviceId(Long deviceId) { ... }

    @Override
    @Cacheable(cacheNames = RedisKeyConstants.DEVICE_CONFIG, key = "#productKey+':'+#dn", unless = "#result == null")
    public DeviceConfig findByPkDn(String productKey, String dn) { ... }

    @Override
    @Caching(evict = {
            @CacheEvict(cacheNames = RedisKeyConstants.DEVICE_ID_CONFIG, key = "#config.deviceId", beforeInvocation = true),
            @CacheEvict(cacheNames = RedisKeyConstants.DEVICE_CONFIG, key = "#config.productKey+':'+#config.deviceName", beforeInvocation = true)
    })
    public Boolean saveConfig(DeviceConfig config) { ... }
```

**写后即清**：`saveConfig` 在执行前 `beforeInvocation=true` 先清缓存，确保下次读取回源拿最新。**这是项目里最规范的缓存治理点**。

#### 第 8 条：物模型缓存

```170:175:module-eiot/module-eiot-biz/src/main/java/com/enjoyiot/module/eiot/service/product/ThingModelServiceImpl.java
    @Override
    @TenantIgnore
    @Cacheable(cacheNames = RedisKeyConstants.THING_MODEL, key = "#productKey", unless = "#result == null")
    public ThingModel getThingModelByProductKeyFromCache(String productKey) {
```

- 保存物模型时 `@CacheEvict(cacheNames=THING_MODEL, key=productKey)` 清单产品缓存
- 同时**主动** `deviceApi.clearPropertiesCache(productKey)` 清该产品所有设备的属性缓存（避免旧缓存字段与新超级表结构不一致）
- **修改物模型是高危操作**：改了字段名/类型后需保证下游所有引用了物模型的代码都能容忍。项目中依赖物模型的路径已经过白名单校验（`DevicePropertyHandler` 第 130 行）

#### 第 9 条：全量产品列表

```188:197:module-eiot/module-eiot-biz/src/main/java/com/enjoyiot/module/eiot/service/product/ProductServiceImpl.java
    @Override
    @TenantIgnore
    @Cacheable(cacheNames = RedisKeyConstants.PRODUCT_ALL_KEYS + "#10m",
            unless = "#result == null")
    public List<String> getAllProductKeys() {
```

**唯一带 TTL 的缓存**：`#10m` 由 `TimeoutRedisCacheManager`（位于 `framework/spring-boot-starter-redis/.../TimeoutRedisCacheManager.java`）解析为 10 分钟过期。增删产品时 `allEntries=true` 立即清。

#### 第 10 条：告警状态

```77:180:module-eiot/module-eiot-core/iot-rule-engine/src/main/java/com/enjoyiot/eiot/ruleengine/handler/sys/YDeviceThresholdCheckHandler.java
    private static final String ALERT_STATE_KEY = "eiot:alert:state:{}:{}";
    ...
    stringRedisTemplate.opsForValue().set(stateKey, "alerting");
    ...
    String state = stringRedisTemplate.opsForValue().get(stateKey);
    if (!"alerting".equals(state)) return;
    stringRedisTemplate.opsForValue().set(stateKey, "recovered");
```

- 仅 `alerting` ↔ `recovered` 两态转换，用于"恢复通知只发一次"
- **无 TTL**：一个塘口告警 → `alerting` → 值恢复后 → `recovered` 永久保留
- 不会影响：**（（每**建议**加 24h TTL + `recovered` 状态可以被新告警覆盖即可），目前未对系统功能造成问题，原因是 `recovered` 状态不参与任何业务判断，只用于"避免恢复通知重发"。

### 3.3 治理问题清单

| # | 问题 | 影响 | 建议修复 |
|---|---|---|---|
| 1 | `deleteByIds(List<Long>)` 批量删设备**不清缓存**（TODO 已留） | 已删设备的缓存会一直存在到 jar 重启或 key 自然淘汰 | 在 `deleteByIds` 里加批量 `clearCache` |
| 2 | `DEVICE_LAST` **无 TTL** | 离线设备的 key 永久残留 | 加 TTL = `keepAliveTime × 3`（30min~1h） |
| 3 | `DEVICE_PROPERTY` **无 TTL** | 设备被删后属性缓存仍在 | 设备下线/删除时主动 DEL；加 24h 兜底 TTL |
| 4 | `ALERT_STATE_KEY` **未走 `RedisKeyConstants`** | key 命名散落，难统一治理 | 移到 `RedisKeyConstants`，加 TTL |
| 5 | Spring Cache 类 key 的 TTL **依赖 `CacheProperties.Redis.timeToLive`**，项目里没显式配置 → 默认**永不过期** | 缓存里残留产品/设备配置信息，删除产品/设备后只能依赖显式 `@CacheEvict` 清 | 在 `application.yaml` 给 `spring.cache.redis.time-to-live` 设个上限（如 24h）兜底 |
| 6 | `clearPropertiesCache` 只在保存物模型时按产品清，**联动残留字段**无专门清 | 极小概率发生但难排查 | 见 #2.1 末尾的"拼写错误"案例 |

### 3.4 治理原则（推荐）

1. **TTL 兜底**：所有无显式 `@CacheEvict` 路径的 key 必须有 TTL
2. **失效对称**：每个写操作要清掉所有能由它推导出 stale 的缓存（产品/设备/配置/属性四级）
3. **key 集中**：所有 Redis key 必须从 `RedisKeyConstants` 取，禁止业务代码硬编码字符串
4. **大 key 拆分**：`DEVICE_PROPERTY` 这种 JSON 嵌套结构，如果单设备属性超过 50 个，建议改成 `Redis Hash`（key=propertyKey, field=deviceId, value=JSON），避免单 key > 100KB 时阻塞 Redis
5. **预热**：服务重启后第一次访问会全部回源，**对 MySQL 是 N 次查询**。建议在 jar 启动后异步预热热点（先查产品列表 → 每个产品查一次设备列表 → 写 Redis）

---

## 四、容量预估

### 4.1 单位 Key 大小估算（实测典型值）

| Key | Key 字节数 | Value 字节数 | 单 key 总计 |
|---|---|---|---|
| `iot:product:<pk>` (pk=16字符) | 4 + 8 + 16 = **28 B** | Product 实体（name、category、keepAliveTime、secret 等约 15 字段） ≈ **800 B** | **0.8 KB** |
| `iot:device:<pk>:<dn>` (pk=16, dn=16) | 4 + 8 + 1 + 16 + 1 + 16 = **46 B** | DeviceInfo（含阈值 JSON、塘口关联、tag） ≈ **3 KB** | **3.05 KB** |
| `iot:deviceId:<deviceId>` | 4 + 11 + 19 = **34 B** | DeviceInfo ≈ **3 KB** | **3.05 KB** |
| `iot:deviceLast:<deviceId>` | 4 + 12 + 19 = **35 B** | 时间戳字符串 ≈ **13 B** | **0.05 KB** |
| `iot:deviceProperty:<deviceId>` | 4 + 16 + 19 = **39 B** | `{PH, NH, DO, tem, geio_areator_01, geio_seed_02...}` ≈ **8 属性 × 40B ≈ 320 B** | **0.36 KB** |
| `iot:deviceConfig:<pk>:<dn>` | 4 + 14 + 1 + 16 + 1 + 16 = **52 B** | DeviceConfig（modbus、串口配置等） ≈ **0.8 KB** | **0.85 KB** |
| `iot:deviceIdConfig:<deviceId>` | 4 + 17 + 19 = **40 B** | 同上 ≈ **0.8 KB** | **0.84 KB** |
| `iot:thing_model:<pk>` | 4 + 13 + 16 = **33 B** | ThingModel（properties/services/events 全量） ≈ **3 KB** | **3.0 KB** |
| `iot:productAllKeys` | 4 + 17 = **21 B** | `List<String>` 长度 N×(16+逗号) ≈ 17N B | **17 × 产品数 B** |
| `eiot:alert:state:<id>:<prop>` | 4 + 13 + 19 + 1 + 8 = **45 B** | `"alerting"` 或 `"recovered"` ≈ **10 B** | **0.05 KB** |

**Redis 内部还会加**：每个 key 都有 ~40 B 的 `redisObject`、SDS 字符串头部、链表指针等开销。**实际占用 ≈ 上述 × 1.5~2**。

### 4.2 不同规模容量估算

**假设**：
- 平均每个产品 8 个属性（DO/NH/PH/tem/4 路开关类）
- 99% 设备在线（离线设备残留会少一些）
- 产品数 = 设备数 / 100（一般 1 产品对应 100 台设备）

#### 单设备总开销（不含产品/物模型）

| 项 | 数量 | 单 key | 总计 |
|---|---|---|---|
| DEVICE_ID（DeviceInfo 完整） | 1 | 3.05 KB | **3.05 KB** |
| DEVICE（pk+dn 索引副本） | 1 | 3.05 KB | **3.05 KB** |
| DEVICE_LAST | 1 | 0.05 KB | **0.05 KB** |
| DEVICE_PROPERTY | 1 | 0.36 KB | **0.36 KB** |
| DEVICE_ID_CONFIG（有配置时） | 0.3 | 0.84 KB | **0.25 KB** |
| ALERT_STATE（启用阈值告警的设备） | 0.5 × 设备数 | 0.05 KB | **0.025 KB** |
| **单设备合计** | | | **≈ 6.7 KB** |

#### 容量估算表（含 ~1.7 倍 Redis 内部开销）

| 设备规模 | 产品数 | 设备缓存 | 产品+物模型缓存 | productAllKeys | **Redis 内存（合计）** | 建议规格 |
|---|---|---|---|---|---|---|
| **1,000** | 10 | 6.7 × 1,000 = 6.7 MB | 10 × 4 KB = 40 KB | 170 B | **≈ 12 MB** | 512 MB（极宽裕） |
| **10,000** | 100 | 6.7 × 10,000 = 67 MB | 100 × 4 KB = 400 KB | 1.7 KB | **≈ 120 MB** | 1 GB |
| **100,000** | 1,000 | 6.7 × 100,000 = 670 MB | 1,000 × 4 KB = 4 MB | 17 KB | **≈ 1.2 GB** | 2 GB |
| **1,000,000** | 10,000 | 6.7 × 1,000,000 = 6.7 GB | 10,000 × 4 KB = 40 MB | 170 KB | **≈ 12 GB** | 16 GB（**单机到顶**，建议 Redis Cluster） |

> 📌 **1 万台 ≈ 120 MB**、**10 万台 ≈ 1.2 GB**——这是**全量热缓存**的预估。如果按建议加上 TTL（24h 兜底），部分长期不活跃设备的 DEVICE_PROPERTY 等会被自然淘汰，实际占用通常 **比理论值低 30%-50%**。

### 4.3 大规模下的注意事项

超过 10 万台设备时：

1. **单 key 100 KB 限制**：TDengine 上一帧属性可能很多（>30 字段），单 key 的 JSON 序列化结果可能 > 10 KB，超过这个量级建议拆 `Redis Hash`
2. **设备分库分片**：可按 `deviceId % N` 分片到 N 个 Redis 实例，每个实例独立承担 1/N 流量
3. **DEVICE_PROPERTY 拆分**：改成 `Redis Hash`（`HSET iot:deviceProperty:{id} field value`）后单 key 总大小可控，散列均匀
4. **避免 `KEYS *`**：所有 SCAN 类操作必须带 `MATCH iot:deviceProperty:*` + `COUNT 100`，`redis-scan-batch-size` 已配 30（`EnjoyCacheProperties.redisScanBatchSize`）
5. **`EXPIREAT` 兜底**：建议给 DEVICE_LAST 加 `EXPIREAT keepAliveTime × 3`，给 DEVICE_PROPERTY 加 `EXPIREAT lastTime + 24h`，避免幽灵 key 堆积
6. **慢命令监控**：开启 `slowlog-log-slower-than 10ms`，定期审计

---

## 五、运维命令速查

```bash
# 1. 总占用
docker exec -it iot-redis redis-cli INFO memory | grep used_human

# 2. 各 Key 数量
docker exec -it iot-redis redis-cli --scan --pattern 'iot:*' | wc -l
docker exec -it iot-redis redis-cli --scan --pattern 'iot:deviceProperty:*' | wc -l

# 3. 单设备属性缓存大小
docker exec -it iot-redis redis-cli --scan --pattern 'iot:deviceProperty:2086717681535434752' | head
docker exec -it iot-redis redis-cli MEMORY USAGE iot:deviceProperty:2086717681535434752

# 4. 精准清某设备属性缓存（清残留字段时的标准操作）
docker exec -it iot-redis redis-cli -n 8 DEL "iot:deviceProperty:2086717681535434752"

# 5. 批量清某产品下所有设备属性缓存（保存物模型时已自动做）
docker exec -it iot-redis redis-cli --scan --pattern 'iot:deviceProperty:*' | \
  xargs docker exec -it iot-redis redis-cli -n 8 DEL

# 6. 看告警状态分布
docker exec -it iot-redis redis-cli --scan --pattern 'eiot:alert:state:*' | \
  xargs -I {} docker exec -it iot-redis redis-cli -n 8 GET {} | sort | uniq -c

# 7. 找"幽灵设备"（缓存里在但 MySQL 里不在）
docker exec -it iot-redis redis-cli --scan --pattern 'iot:deviceProperty:*' | \
  sed 's|iot:deviceProperty:||' > /tmp/redis_device_ids.txt
mysql -h<host> -P<port> -u<user> -p<pwd> -e \
  "SELECT id FROM eiot_device_info" <db> | tail -n+2 > /tmp/db_device_ids.txt
comm -23 <(sort /tmp/redis_device_ids.txt) <(sort /tmp/db_device_ids.txt)
```

---

## 六、相关源码索引

| 关注点 | 文件 | 行 |
|---|---|---|
| Key 枚举 | `module-eiot/.../dal/redis/RedisKeyConstants.java` | 全文 |
| 直接读写 | `module-eiot/.../dal/redis/no/EiotRedisDAO.java` | 55-101 |
| Spring Cache TTL 解析 | `framework/spring-boot-starter-redis/.../core/TimeoutRedisCacheManager.java` | 全文 |
| 产品缓存 | `module-eiot/.../service/product/ProductServiceImpl.java` | 76/94/110/171/190 |
| 物模型缓存 | `module-eiot/.../service/product/ThingModelServiceImpl.java` | 110/144/172 |
| 设备缓存 | `module-eiot/.../service/device/DeviceInfoServiceImpl.java` | 130/150/218/227/425 |
| 设备配置缓存 | `module-eiot/.../service/device/DeviceConfigServiceImpl.java` | 51/68/78 |
| 属性缓存生命周期 | `module-eiot/.../service/device/DeviceInfoServiceImpl.java` | 446-456 |
| 阈值告警状态 | `module-eiot/.../ruleengine/handler/sys/YDeviceThresholdCheckHandler.java` | 76/174-179/296-302 |
| 最后心跳生命周期 | `module-eiot/.../ruleengine/handler/sys/DeviceStateCheckHandler.java` | 401-410 |
