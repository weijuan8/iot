# 首页数据来源对照表

> 首页 `/ai/analysis/home-page` 的数据分两类来源：
> **AI 分析落库**（直接读 `y_daily_analysis_result.analysis_output`）与 **实时查询**（查 TDengine / MySQL）。

## 一、AI 分析落库（直接读取）

| 模块 | 字段 | 说明 |
|---|---|---|
| `safety` | `score`、`level` | 安全指数与等级 |
| `aiConclusions` | 3 条结论文案 | 依次对应 饲喂 / 溶氧 / 水质 |
| `feed` | `adjust`、`data[]`（label/val/unit/note/infer/cls）、`ai` | 投喂增减% 与**指标卡（含数值，全部 AI 生成）** |
| `oxy` | `tag`、`cols`（label/val/unit/cls）、`aeroPlan`、`ai` | 溶氧状态与增氧方案文案 |
| `wq` | `tag`、`data[]`（label/val/unit/note/infer/cls）、`ai` | 水质研判与**指标卡（含数值，全部 AI 生成）** |
| `review` | `items`（执行状态）、`ai` | 昨日建议复盘结论 |

> **feed/wq 的指标（含数值）是 AI 在分析过程中总结的"昨日指标"，非实时数据**。
> 指标自选、数量不限，只要符合格式即可，不限于水温/pH/溶氧/氨氮。
> `val` 为纯数值（不带单位）、`unit` 单独返回，前端分别渲染。
> **传感器约束**：投喂 AI 时会附带"本塘口实际可用传感器参数"清单；后端返回前还会按设备真实上报属性过滤一次，
> 未安装的传感器指标（如无氨氮传感器时的"氨氮/亚硝酸盐"）不会出现。

## 二、实时查询（不走 AI，每次打开首页实时查）

| 模块 | 字段 | 存储 | 查询方式 |
|---|---|---|---|
| `oxy` | `chart.data`（24h 溶氧曲线 25 点） | TDengine | **昨天 0 点 ~ 今天 0 点** 原始点按小时分桶平均（多设备取平均） |
| `oxy` | `critical`（溶氧临界值） | MySQL | 塘口固定参数表 |
| `feed` | `adjust` 基准（昨日投喂量） | MySQL | 昨日分析结果记录 |
| `profile` | `stats`（分析天数/采纳率/累计建议/沉淀规律） | MySQL | 分析结果 / 规律库 / 习惯库 count 统计 |

> 首页查询日聚合数据的回退窗口为 3 天（`HOME_STAT_LOOKBACK_DAYS`），仅在 feed/wq 无 AI 指标兜底时使用。

## 三、兜底逻辑（AI 未输出时）

- `feed.data` / `wq.data`：AI 未输出指标时，兜底查实时日聚合数据，**仅取本塘口实际安装的传感器**（如水温/溶氧，装了氨氮才有氨氮）。
- `oxy.cols`（临界值/跌破时间/最低溶氧）：不取 AI 输出，始终由后端按 24h 曲线计算，保证与 `chart.data[]` 一致（曲线未跌破则跌破时间为"无"）。
- `safety` / `aiConclusions` / `review`：缺失时按风险等级或昨日记录兜底占位。
- 24h 曲线、`profile`、`critical` 始终实时查询，不依赖 AI。

## 四、划分原则

- 需要 **AI 生成**的内容（建议、结论、标签、指标数值）→ 直接读 `analysis_output`，不重复计算。
- 需要 **实时准确**的值（24h 溶氧曲线、画像统计、临界值）→ 单独查库，不依赖 AI 分析时点的历史快照。
- AI 分析用的 24 小时数据序列只是喂给 AI 的输入，**不直接用于首页展示**。
