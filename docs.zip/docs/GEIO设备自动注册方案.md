# GEIO 设备自动注册方案

> 适用于 `iot-component-geio`，解决 GEIO 网关类产品"上线即建设备、自动绑模块"的需求。
>
> 文档版本：2026-10-14

---

## 一、背景与目标

GEIO 网关类产品（用于继电器控制 + 环境/水质传感器透传）历史上需要平台管理员手工完成两件事：

1. 在 **设备管理** 里手动创建一条 `eiot_device_info`，填 `productKey` / `dn` / `deptId` 等；
2. 在 **模块管理** 里手动绑定设备到 `y_module`。

运维和首装机流程繁琐，特别是同型号网关批量铺货场景下工作量大。

**目标**：硬件只需要填好 MQTT topic 中的"模块 ID"段位，上电后**自动**完成：

- 在 `eiot_device_info` 创建设备（`productKey`、`dn`、物模型随产品走）；
- 写入 `y_module_device`，绑定到对应 `y_module`，自动产生租户归属。

> **设计原则**：自动注册路径不新增数据库字段，仅依赖现有 `y_module` / `y_module_device` / `eiot_device_info` / `eiot_product` 表；所有新增类名以 `Y` 开头（项目命名规则），结构必须符合规则，否则日志中报错方便排查。

---

## 二、设计思路

### 2.1 把"模块"作为 Topic 一段

GEIO 上下行 MQTT topic 由 5 段升级为 6 段：

| 段号 | 字段 |
|---|---|
| 0 | 前缀：`geio`（生产） / `testgeio`（测试） |
| 1 | `productKey` |
| 2 | `deviceName` / `dn` |
| **3** | **新增：`moduleId`（模块 ID）** |
| 4 | `serial` |
| 5 | `up` / `down` |

完整示例：

```
上行: geio/apFx3ja3p3nHiSRW/geio_test_01/123/serial/up
下行: geio/apFx3ja3p3nHiSRW/geio_test_01/123/serial/down
```

硬件侧在 publish 时多填一段 `moduleId`（固件升级成本极低：topic 模板拼接改一次）。

### 2.2 moduleId 的来源与缓存

**来源**：由设备上行 MQTT topic 携带（`parts[3]`），不经 payload/设备名解析。

**缓存**：组件内存缓存 `GeioComponent.moduleIdCache`，按 `pk:dn` 索引。

```java
// GeioComponent.java
private final Map<String, String> moduleIdCache = new ConcurrentHashMap<>();
```

**为什么是缓存而不是数据库字段**：

| 维度 | 缓存（当前） | DB 字段（已废弃） |
|---|---|---|
| 是否新增字段 | 否 | 是（已被回滚） |
| 重启是否丢失 | 是（设备重新上报即刷新） | 否 |
| 适用场景 | 设备频繁上报、Server 启动后由设备首次上报触发刷新 | 不适用 |

**缓存为空**：说明该设备从未上报过，**不允许下兜底包**——直接 `log.error` 跳过（结构必须符合规则，日志报错方便排查）。

### 2.3 自动注册三条件（缺一不可）

`GeioComponent.lookupOrRegister` 收到帧时（缓存未命中 + DB 也查不到设备）触发自动注册，**任一不满足都拒绝凭空创建**：

1. `pk` 对应的 **产品已定义**（物模型必须有，rule engine 才能匹配）；
2. `moduleId` 对应的 **模块已存在**（`YModuleApi.getById(moduleId)`，模块归属的租户上下文也必须有）；
3. `dn` 当前不在 `eiot_device_info`（首次上报）。

### 2.4 极简绑定（跳过超管校验）

`y_module_device` 表本身：

```sql
CREATE TABLE y_module_device (
  module_id  BIGINT NOT NULL,
  device_id  BIGINT NOT NULL,
  farm_id    BIGINT NULL,
  pond_id    BIGINT NULL,
  owner_tenant_id BIGINT NULL,
  creator/updater/create_time/update_time,
  PRIMARY KEY (id),
  UNIQUE KEY uk_device_id (device_id)
) ENGINE=InnoDB COMMENT='模块-设备关联表，一个设备只能属于一个模块';
```

类注释里写得**明确**：此关联表**无 `tenant_id`、不走 MyBatis-Plus 拦截器、物理删除**。

因此新增 `YModuleApi.bindDeviceInternal(moduleId, deviceId)`：**只做**：

1. 平台租户上下文内 select 模块（绕开拦截器）；
2. 直接 `INSERT INTO y_module_device`（不继承 `BaseDO`，无拦截器、无触发器、无外键），冗余写入 `farm_id` / `pond_id` / `owner_tenant_id`；
3. `creator` / `updater` 设为 `"system"`。

不校验超管、不检查当前登录用户、不查当前设备是否存在——因为 GEIO 自动注册路径下的调用方拿不到登录态，但所有参数均已在前置步骤校验过。

---

## 三、改造清单

### 3.1 SQL DDL（_sql/mysql/shihe.sql）

**无新增字段**。`module_code` 字段方案已回滚。

自动注册路径涉及的全部表都是项目已有的：

| 表 | 作用 |
|---|---|
| `eiot_device_info` | 创建设备 |
| `eiot_product` | 校验产品/物模型存在 |
| `y_module` | 通过 `moduleId` 查模块（项目已有 "塘口管理→模块" 的实体） |
| `y_module_device` | 设备绑定到模块（项目已有结构，冗余 `farm_id` / `pond_id` / `owner_tenant_id`） |

### 3.2 API 层（module-eiot-api）

#### 新增 `YModuleInfo`（模块 DTO，避免直接暴露 DO）

```
module-eiot-api/.../api/module/YModuleInfo.java
```

#### 扩展 `YModuleApi` 接口

```
module-eiot-api/.../api/module/YModuleApi.java
```

| 方法 | 说明 |
|---|---|
| `YModuleInfo getById(Long moduleId)` | 按模块 ID查模块，内部走平台租户上下文 + `@TenantIgnore` |
| `void bindDeviceInternal(Long moduleId, Long deviceId)` | 系统内部绑定，跳过租户和超管权限校验，仅插入一行 `y_module_device` |

### 3.3 BIZ 层（module-eiot-biz）

#### 新增 `YModuleApiImpl`

```
module-eiot-biz/.../api/module/YModuleApiImpl.java
```

- `getById(moduleId)`：`TenantUtils.execute(PLATFORM_TENANT_ID, () -> moduleMapper.selectById(moduleId))`
- `bindDeviceInternal(moduleId, deviceId)`：平台租户上下文查模块 → 直接 `moduleDeviceMapper.insert`

### 3.4 组件核心（iot-component-core）

#### 修改 `ComponentServices`

```
iot-component-core/.../component/core/ComponentServices.java
```

新增 `@Resource private YModuleApi moduleApi;`（由 lombok `@Data` 自动生成 getter）。

### 3.5 GEIO 组件（iot-component-geio）

#### `GeioConstants`

```
iot-component-geio/.../constant/GeioConstants.java
```

- `TOPIC_UP`：5 段 → **6 段**（`geio/+/+/+/serial/up`）
- `TOPIC_PART_COUNT`：5 → **6**

#### `GeioVerticle`

```
iot-component-geio/.../service/GeioVerticle.java
```

| 改动 | 说明 |
|---|---|
| `publishHandler` topic 解析 | `pk=parts[1], dn=parts[2], moduleId=parts[3]` |
| `handleSerialRead(pk, gwId, moduleId, payloadStr)` | 新增 `moduleId` 形参，透传给 ret/handleReportFrame |
| `handleRetFrame(pk, gwId, moduleId, json, payloadStr)` | 透传 moduleId → `geioComponent.handleRet` |
| `handleReportFrame(pk, gwId, moduleId, json)` | 透传 moduleId → `geioComponent.handleSerialRead` |
| `publishCommand(pk, gwId, moduleId, cmd)` | 下行 topic 加 `moduleId` 段；**null/空时 `log.error` 返回，不下占位包**（缓存为空说明设备从未上报过，不下拼错的 topic） |

#### `GeioComponent`

```
iot-component-geio/.../service/GeioComponent.java
```

| 改动 | 说明 |
|---|---|
| `gatewayCache` key | `dn` → **`pk:dn`**（避免不同 pk 同 dn 冲突） |
| `moduleIdCache` | 新增 `Map<String, String>`，按 `pk:dn` 缓存 `moduleId`，仅内存 |
| `gatewayCacheLocks` | 新增同 key 串行化锁，自动注册路径并发帧防重入 |
| `lookupGateway` → **`lookupOrRegister(pk, dn, moduleId)`** | 缓存 → DB → 三条件自动注册；每次都把 `moduleId` 写入 `moduleIdCache` |
| `autoRegister(pk, dn, moduleId)` | 产品/模块校验 → `DeviceApi.registerDevice` → `YModuleApi.bindDeviceInternal`（不传 moduleId 入库） |
| `handleRet(pk, dn, moduleId, states)` | 新增 moduleId 形参 |
| `handleSerialRead(pk, dn, moduleId, data)` | 新增 moduleId 形参 |
| `propertySet(action)` | 调 `lookupOrRegister(pk, dn, null)`，下行 topic 从 `moduleIdCache` 取；缓存空 → `log.error` 返回 |
| `pollSwitchStatus` 下行 | 从 `moduleIdCache` 取 moduleId 拼下行 topic；缓存空 → `log.error` 跳过本轮轮询 |

---

## 四、数据流（自动注册路径）

```
硬件 GEIO publish
  │
  │ topic: geio/{pk}/{dn}/{moduleId}/serial/up
  │ payload: {JSON...}
  ▼
GeioVerticle.publishHandler
  │ parts[1]=pk, parts[2]=dn, parts[3]=moduleId
  │ executeBlocking(worker)
  ▼
GeioComponent.lookupOrRegister(pk, dn, moduleId)
  │
  │ └─ moduleIdCache.put(pk:dn, moduleId)  // 每次上报都刷新
  │
  ├─ 缓存命中 (pn:dn → DeviceInfo) → 返回
  │
  ├─ DB 命中 (getDeviceByPkDnByCache) → 写缓存 + 返回
  │
  └─ DB 未命中:
       │
       ├─ moduleId 缺失 → warn + 丢弃（行为兼容老逻辑）
       │
       └─ 同 (pn,dn) 串行化锁:
            │
            ├─ 1. ThingModelApi.getThingModelByProductKeyFromCache(pk) → 物模型不存在 → warn 丢弃
            ├─ 2. YModuleApi.getById(moduleId) → 模块不存在 → warn 丢弃
            ├─ 3. DeviceApi.registerDevice(RegisterDevice(pn, dn)) → 拿到 deviceId（不传 moduleId）
            └─ 4. YModuleApi.bindDeviceInternal(module.getId(), deviceId)
                   │
                   ├─ 平台租户上下文 select Module(拿到 farmId/pondId/tenantId)
                   └─ INSERT INTO y_module_device(... farm_id, pond_id, owner_tenant_id ...)
            ▼
       写 gatewayCache + 返回 DeviceInfo
后续帧走正路径
```

---

## 五、兼容性 & 部署

### 5.1 硬件升级

GEIO 固件升级一次即可：拼接 publish topic 时多带一段 `moduleId`。**老设备固件不升级**，其 5 段 topic 在新版本上会被 `TOPIC_PART_COUNT=6` 校验直接丢弃，不影响其他设备。

### 5.2 下行兼容

`publishCommand` 在 moduleId 为空时**直接 log.error 返回**，不下占位包（与 `module_code` 字段方案不同——后者会下 `geio/.../_/serial/down`）。

理由：缓存为空说明设备从未上报过，**结构不合法**（缺少 moduleId 段位），不应下发拼错的 topic，方便排障（设计原则："结构必须符合规则"）。

### 5.3 数据库

**无 DDL 改动**。`module_code` 字段已回滚。

部署时无需执行 ALTER TABLE。

### 5.4 前端

无前端改动（`module_code` 表单字段已移除）。

---

## 六、注意点

1. **不能凭空造产品/模块**：自动注册**拒绝**在产品/模块不存在时自动建。物模型必须有；模块归属的租户上下文也必须有。
2. **同 (pn,dn) 并发帧串行化**：用 `gatewayCacheLocks` 同 key 加锁，避免同一新设备多帧并发触发重复 `registerDevice` + `bindDeviceInternal`。
3. **唯一索引兜底**：`y_module_device.uk_device_id(device_id)` 保证一设备一模块。若因竞态导致重复插入，`bindDeviceInternal` 抛 `DuplicateKeyException` → `autoRegister` 捕获 → log.error + return device（已注册的设备仍然可用，绑定失败留给人工补绑）。
4. **租户归属从模块带**：`y_module_device.owner_tenant_id` 是 `module.tenant_id` 的冗余字段，通过 `bindDeviceInternal` 一次性写入，不依赖当前线程登录态。
5. **极简插入无副作用**：`y_module_device` 不继承 `BaseDO`，不软删除，不走拦截器，**物理删除**。`bindDeviceInternal` 直接 `insert` 没有副作用。
6. **moduleId 缓存生命周期**：进程级，重启后丢失。设备首次上报即刷新，对存量设备无影响（设备本来就在 `eiot_device_info` 里，不走自动注册路径）。
7. **命名规则**：所有新增类（`YModuleInfo` / `YModuleApi`）以 `Y` 开头，与项目 §0.4 命名规则保持一致。
8. **日志可观测**：自动注册成功/失败的日志均包含 `pk` / `dn` / `moduleId` / `deviceId` / `moduleId` / `tenantId`，便于排障。

---

## 七、回滚

| 维度 | 操作 |
|---|---|
| 代码 | `git revert <commit>`，恢复 5 段 topic 解析 |
| DB | **无 DDL 回滚**（未新增字段） |
| 硬件 | 无需切回（firmware 兼容性：subscribe 仍是通配） |
